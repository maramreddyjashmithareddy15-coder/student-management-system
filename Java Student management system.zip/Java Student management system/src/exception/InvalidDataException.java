package exception;

/**
 * Thrown when student details provided fail validation checks.
 */
public class InvalidDataException extends Exception {
    public InvalidDataException(String message) {
        super(message);
    }
}
