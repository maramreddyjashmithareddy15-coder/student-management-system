package exception;

/**
 * Thrown when trying to add a student with a Roll Number that already exists.
 */
public class DuplicateStudentException extends Exception {
    public DuplicateStudentException(String message) {
        super(message);
    }
}
