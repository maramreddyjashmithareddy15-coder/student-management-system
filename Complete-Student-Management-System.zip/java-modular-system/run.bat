@echo off
title Student Management System (Advanced Java & DSA)
echo ========================================================
echo   Compiling Student Management System Java Files...
echo ========================================================

if not exist bin mkdir bin

javac -encoding UTF-8 -d bin src\model\*.java src\exception\*.java src\dsa\*.java src\util\*.java src\service\*.java src\ui\*.java src\Main.java

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Compilation failed! Please check Java JDK installation.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [SUCCESS] Compilation complete! Launching application...
echo ========================================================
echo.

java -cp bin Main

echo.
pause
