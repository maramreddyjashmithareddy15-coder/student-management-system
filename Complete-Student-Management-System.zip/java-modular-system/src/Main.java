import service.StudentManager;
import ui.ConsoleUI;
import util.AutoSaveWorker;

/**
 * Entry point for the Student Management System application.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println(" Starting Student Management System (Java & DSA)");
        System.out.println("=================================================");

        // 1. Initialize Student Manager (loads CSV persistence & DSA memory structures)
        StudentManager manager = new StudentManager("students.csv");

        // 2. Start Background Auto-Save Daemon Thread (saves every 30 seconds)
        AutoSaveWorker autoSaveTask = new AutoSaveWorker(manager, 30);
        Thread autoSaveThread = new Thread(autoSaveTask, "AutoSave-Thread");
        autoSaveThread.setDaemon(true); // Daemon thread exits when main app exits
        autoSaveThread.start();
        System.out.println("[Main] Started background AutoSave daemon thread.");

        // 3. Register Shutdown Hook for clean data saving on exit
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\n[Shutdown] Persisting remaining data to students.csv...");
            manager.saveData();
            autoSaveTask.stopWorker();
            System.out.println("[Shutdown] Data persisted successfully.");
        }));

        // 4. Launch Console UI Interface
        ConsoleUI ui = new ConsoleUI(manager);
        ui.start();
    }
}
