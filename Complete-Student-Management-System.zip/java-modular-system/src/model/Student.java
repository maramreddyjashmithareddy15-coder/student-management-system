package model;

/**
 * Model class representing a Student entity in the system.
 * Demonstrates OOP concepts: Encapsulation, Data Hiding, Constructor Overloading, and Override.
 */
public class Student {
    private int rollNo;
    private String name;
    private String department;
    private double gpa;
    private String email;

    // Constructor
    public Student(int rollNo, String name, String department, double gpa, String email) {
        this.rollNo = rollNo;
        this.name = name;
        this.department = department;
        this.gpa = gpa;
        this.email = email;
    }

    // Getters and Setters
    public int getRollNo() {
        return rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Converts student data to a CSV line for file storage.
     */
    public String toCSV() {
        return rollNo + "," + escapeCSV(name) + "," + escapeCSV(department) + "," + gpa + "," + escapeCSV(email);
    }

    /**
     * Helper to escape commas in CSV data.
     */
    private String escapeCSV(String data) {
        if (data.contains(",")) {
            return "\"" + data + "\"";
        }
        return data;
    }

    /**
     * Parses a CSV formatted line into a Student object.
     */
    public static Student fromCSV(String csvLine) {
        String[] parts = csvLine.split(",");
        if (parts.length < 5) return null;
        try {
            int rollNo = Integer.parseInt(parts[0].trim());
            String name = parts[1].trim().replace("\"", "");
            String dept = parts[2].trim().replace("\"", "");
            double gpa = Double.parseDouble(parts[3].trim());
            String email = parts[4].trim().replace("\"", "");
            return new Student(rollNo, name, dept, gpa, email);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return String.format("Roll No: %-5d | Name: %-18s | Dept: %-10s | GPA: %-4.2f | Email: %s",
                rollNo, name, department, gpa, email);
    }
}
