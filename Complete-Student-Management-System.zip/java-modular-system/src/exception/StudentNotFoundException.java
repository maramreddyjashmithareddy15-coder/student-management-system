package exception;

/**
 * Thrown when a student with a specified Roll Number is not found.
 */
public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String message) {
        super(message);
    }
}
