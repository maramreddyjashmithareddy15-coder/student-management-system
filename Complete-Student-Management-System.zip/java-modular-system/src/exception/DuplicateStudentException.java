package exception;

/**
 * Thrown when trying to add a student with a Roll Number that already exists.
 */
public class DuplicateStudentException extends Exception {
    private static final long serialVersionUID = 1L;

    public DuplicateStudentException(String message) {
        super(message);
    }
}
