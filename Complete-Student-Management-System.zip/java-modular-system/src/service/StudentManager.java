package service;

import model.Student;
import dsa.CustomLinkedList;
import dsa.CustomBST;
import dsa.CustomHashMap;
import dsa.StudentSorter;
import exception.DuplicateStudentException;
import exception.InvalidDataException;
import exception.StudentNotFoundException;
import util.FileHandler;
import util.DatabaseHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Main Controller Service coordinating Data Structures, Persistence, and Business Logic.
 */
public class StudentManager {

    private final CustomLinkedList linkedList;
    private final CustomBST bst;
    private final CustomHashMap hashMap;
    private final String filePath;
    private boolean isDatabaseAvailable;

    public StudentManager(String filePath) {
        this.linkedList = new CustomLinkedList();
        this.bst = new CustomBST();
        this.hashMap = new CustomHashMap();
        this.filePath = (filePath != null) ? filePath : "students.csv";

        // Initialize JDBC Database (optional integration)
        this.isDatabaseAvailable = DatabaseHandler.initDatabase("jdbc:sqlite:students.db");

        // Load existing records from persistent CSV storage
        loadInitialData();
    }

    /**
     * Loads initial records into all three custom data structures (LinkedList, BST, HashMap).
     */
    private void loadInitialData() {
        List<Student> loaded = FileHandler.loadStudents(filePath);
        for (Student s : loaded) {
            try {
                addStudentInternal(s);
            } catch (Exception ignored) {
            }
        }
        
        // If file was empty, insert default sample students to make demo ready
        if (linkedList.isEmpty()) {
            insertSampleData();
        }
    }

    private void insertSampleData() {
        try {
            addStudent(new Student(101, "Alice Smith", "Computer Science", 3.90, "alice@univ.edu"));
            addStudent(new Student(102, "Bob Johnson", "Electrical Eng", 3.45, "bob@univ.edu"));
            addStudent(new Student(103, "Charlie Brown", "Mechanical Eng", 3.80, "charlie@univ.edu"));
            addStudent(new Student(104, "Diana Prince", "Computer Science", 4.00, "diana@univ.edu"));
            addStudent(new Student(105, "Evan Wright", "Civil Eng", 3.20, "evan@univ.edu"));
            saveData();
            System.out.println("[StudentManager] Populated 5 sample student records.");
        } catch (Exception e) {
            System.err.println("[StudentManager Error] " + e.getMessage());
        }
    }

    private void addStudentInternal(Student student) {
        linkedList.add(student);
        bst.insert(student);
        hashMap.put(student.getRollNo(), student);
    }

    /**
     * Adds a student with validation and updates all custom data structures.
     */
    public void addStudent(Student student) throws DuplicateStudentException, InvalidDataException {
        // Validation
        if (student.getRollNo() <= 0) {
            throw new InvalidDataException("Roll Number must be a positive integer.");
        }
        if (student.getName() == null || student.getName().trim().isEmpty()) {
            throw new InvalidDataException("Student Name cannot be empty.");
        }
        if (student.getGpa() < 0.0 || student.getGpa() > 4.0) {
            throw new InvalidDataException("GPA must be between 0.0 and 4.0.");
        }

        // Check duplicate using O(1) Hash Map
        if (hashMap.get(student.getRollNo()) != null) {
            throw new DuplicateStudentException("Student with Roll No " + student.getRollNo() + " already exists.");
        }

        addStudentInternal(student);
        
        if (isDatabaseAvailable) {
            DatabaseHandler.insertStudent(student, "jdbc:sqlite:students.db");
        }
    }

    /**
     * Searches for a student by Roll Number in O(1) using Custom Hash Map.
     */
    public Student searchByRollNoHashMap(int rollNo) throws StudentNotFoundException {
        Student s = hashMap.get(rollNo);
        if (s == null) {
            throw new StudentNotFoundException("No student found with Roll Number: " + rollNo);
        }
        return s;
    }

    /**
     * Searches for a student by Roll Number in O(log N) using Custom BST.
     */
    public Student searchByRollNoBST(int rollNo) throws StudentNotFoundException {
        Student s = bst.search(rollNo);
        if (s == null) {
            throw new StudentNotFoundException("No student found with Roll Number: " + rollNo);
        }
        return s;
    }

    /**
     * Removes a student by Roll Number across all data structures.
     */
    public void removeStudent(int rollNo) throws StudentNotFoundException {
        Student existing = hashMap.get(rollNo);
        if (existing == null) {
            throw new StudentNotFoundException("Cannot delete. Student Roll No " + rollNo + " does not exist.");
        }

        // Remove from LinkedList and HashMap
        linkedList.remove(rollNo);
        hashMap.remove(rollNo);

        // Rebuild BST from current LinkedList to maintain tree balance
        rebuildBST();
        saveData();
    }

    /**
     * Updates an existing student record.
     */
    public void updateStudent(int rollNo, String name, String dept, double gpa, String email)
            throws StudentNotFoundException, InvalidDataException {
        Student student = hashMap.get(rollNo);
        if (student == null) {
            throw new StudentNotFoundException("Student Roll No " + rollNo + " not found.");
        }
        if (gpa < 0.0 || gpa > 4.0) {
            throw new InvalidDataException("GPA must be between 0.0 and 4.0.");
        }

        if (name != null && !name.trim().isEmpty()) student.setName(name);
        if (dept != null && !dept.trim().isEmpty()) student.setDepartment(dept);
        student.setGpa(gpa);
        if (email != null && !email.trim().isEmpty()) student.setEmail(email);

        rebuildBST();
        saveData();
    }

    private void rebuildBST() {
        bst.clear();
        for (Student s : linkedList.getAll()) {
            bst.insert(s);
        }
    }

    /**
     * Returns all students.
     */
    public List<Student> getAllStudents() {
        return linkedList.getAll();
    }

    /**
     * Returns students sorted by Roll Number using In-Order Traversal on Custom BST.
     */
    public List<Student> getStudentsSortedByRollNo() {
        return bst.inOrderTraversal();
    }

    /**
     * Returns students sorted by GPA descending using Custom Merge Sort.
     */
    public List<Student> getStudentsSortedByGPA() {
        return StudentSorter.sortByGpaDescending(linkedList.getAll());
    }

    /**
     * Returns students sorted by Name ascending using Custom Merge Sort.
     */
    public List<Student> getStudentsSortedByName() {
        return StudentSorter.sortByNameAscending(linkedList.getAll());
    }

    /**
     * Calculates class average GPA.
     */
    public double getAverageGPA() {
        List<Student> students = linkedList.getAll();
        if (students.isEmpty()) return 0.0;
        double total = 0.0;
        for (Student s : students) {
            total += s.getGpa();
        }
        return total / students.size();
    }

    /**
     * Finds highest GPA student.
     */
    public Student getTopScorer() {
        List<Student> sorted = getStudentsSortedByGPA();
        return sorted.isEmpty() ? null : sorted.get(0);
    }

    /**
     * Saves data to persistent disk file.
     */
    public synchronized void saveData() {
        FileHandler.saveStudents(linkedList.getAll(), filePath);
    }

    public int getTotalCount() {
        return linkedList.getSize();
    }
}
