package util;

import service.StudentManager;

/**
 * Background Daemon Thread demonstrating Advanced Java Multithreading & Concurrency.
 * Automatically persists student records to disk every X seconds.
 */
public class AutoSaveWorker implements Runnable {

    private final StudentManager manager;
    private final int intervalSeconds;
    private volatile boolean running;

    public AutoSaveWorker(StudentManager manager, int intervalSeconds) {
        this.manager = manager;
        this.intervalSeconds = intervalSeconds;
        this.running = true;
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(intervalSeconds * 1000L);
                if (running) {
                    manager.saveData();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void stopWorker() {
        this.running = false;
    }
}
