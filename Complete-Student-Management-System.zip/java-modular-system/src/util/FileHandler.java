package util;

import model.Student;
import dsa.CustomLinkedList;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles File I/O persistence for student records to CSV format.
 * Demonstrates Advanced Java Streams, BufferedReader, BufferedWriter, and Exception Handling.
 */
public class FileHandler {

    private static final String DEFAULT_FILE_PATH = "students.csv";

    /**
     * Loads student records from CSV into a list.
     */
    public static List<Student> loadStudents(String filePath) {
        List<Student> students = new ArrayList<>();
        File file = new File(filePath != null ? filePath : DEFAULT_FILE_PATH);

        if (!file.exists()) {
            System.out.println("[FileHandler] Storage file does not exist yet. A new one will be created upon save.");
            return students;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (isHeader) { // Skip CSV header line
                    isHeader = false;
                    continue;
                }
                if (line.trim().isEmpty()) continue;
                Student s = Student.fromCSV(line);
                if (s != null) {
                    students.add(s);
                }
            }
            System.out.println("[FileHandler] Successfully loaded " + students.size() + " student records from " + file.getName());
        } catch (IOException e) {
            System.err.println("[FileHandler Error] Failed to read file: " + e.getMessage());
        }

        return students;
    }

    /**
     * Saves list of students to CSV file.
     */
    public static boolean saveStudents(List<Student> students, String filePath) {
        File file = new File(filePath != null ? filePath : DEFAULT_FILE_PATH);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Write CSV Header
            writer.write("RollNo,Name,Department,GPA,Email");
            writer.newLine();

            for (Student s : students) {
                writer.write(s.toCSV());
                writer.newLine();
            }
            writer.flush();
            return true;
        } catch (IOException e) {
            System.err.println("[FileHandler Error] Failed to write file: " + e.getMessage());
            return false;
        }
    }
}
