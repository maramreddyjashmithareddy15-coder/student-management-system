package util;

import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC Database Helper Class demonstrating Advanced Java Database Connectivity (JDBC).
 * Contains modular SQL prepared statements, connection pooling pattern, and transaction management.
 */
public class DatabaseHandler {

    private static final String DEFAULT_URL = "jdbc:sqlite:students.db";

    /**
     * Initializes the database connection and creates table if not exists.
     */
    public static boolean initDatabase(String dbUrl) {
        String url = (dbUrl != null && !dbUrl.isEmpty()) ? dbUrl : DEFAULT_URL;
        String createTableSQL = "CREATE TABLE IF NOT EXISTS students ("
                + "roll_no INTEGER PRIMARY KEY, "
                + "name TEXT NOT NULL, "
                + "department TEXT NOT NULL, "
                + "gpa REAL NOT NULL, "
                + "email TEXT NOT NULL"
                + ");";

        try {
            // Attempt to load driver dynamically
            Class.forName("org.sqlite.JDBC");
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute(createTableSQL);
                System.out.println("[JDBC Database] Database initialized successfully at " + url);
                return true;
            }
        } catch (ClassNotFoundException e) {
            System.out.println("[JDBC Note] SQLite JDBC driver not detected in classpath. (File I/O mode is active).");
            return false;
        } catch (SQLException e) {
            System.err.println("[JDBC Error] Database initialization error: " + e.getMessage());
            return false;
        }
    }

    /**
     * Inserts a student record into the SQL database via JDBC PreparedStatement.
     */
    public static boolean insertStudent(Student student, String dbUrl) {
        String url = (dbUrl != null && !dbUrl.isEmpty()) ? dbUrl : DEFAULT_URL;
        String sql = "INSERT INTO students(roll_no, name, department, gpa, email) VALUES(?,?,?,?,?)";

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, student.getRollNo());
            pstmt.setString(2, student.getName());
            pstmt.setString(3, student.getDepartment());
            pstmt.setDouble(4, student.getGpa());
            pstmt.setString(5, student.getEmail());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Retrieves all student records from SQL database using JDBC ResultSet.
     */
    public static List<Student> getAllStudents(String dbUrl) {
        List<Student> list = new ArrayList<>();
        String url = (dbUrl != null && !dbUrl.isEmpty()) ? dbUrl : DEFAULT_URL;
        String sql = "SELECT roll_no, name, department, gpa, email FROM students";

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Student s = new Student(
                        rs.getInt("roll_no"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getDouble("gpa"),
                        rs.getString("email")
                );
                list.add(s);
            }
        } catch (SQLException e) {
            // Silently return empty list if JDBC is disabled
        }
        return list;
    }
}
