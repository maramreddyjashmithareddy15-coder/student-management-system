package ui;

import model.Student;
import service.StudentManager;
import exception.DuplicateStudentException;
import exception.InvalidDataException;
import exception.StudentNotFoundException;

import java.util.List;
import java.util.Scanner;

/**
 * Interactive Console User Interface (CLI) for the Student Management System.
 * Features ASCII box tables, structured menu system, and user input validation.
 */
public class ConsoleUI {

    private final StudentManager manager;
    private final Scanner scanner;

    public ConsoleUI(StudentManager manager) {
        this.manager = manager;
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            printHeader();
            printMenu();
            System.out.print("Enter choice (1-9): ");
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1":
                    handleAddStudent();
                    break;
                case "2":
                    handleDisplayAll();
                    break;
                case "3":
                    handleSearchHashMap();
                    break;
                case "4":
                    handleSearchBST();
                    break;
                case "5":
                    handleSortByGPA();
                    break;
                case "6":
                    handleSortByName();
                    break;
                case "7":
                    handleUpdateStudent();
                    break;
                case "8":
                    handleDeleteStudent();
                    break;
                case "9":
                    printAnalytics();
                    break;
                case "0":
                    exit = true;
                    manager.saveData();
                    System.out.println("\n=======================================================");
                    System.out.println("   Data auto-saved. Thank you for using SMS! Goodbye.  ");
                    System.out.println("=======================================================\n");
                    break;
                default:
                    System.out.println("\n[!] Invalid selection. Please enter a number between 0 and 9.");
            }
            if (!exit) {
                System.out.print("\nPress Enter to return to main menu...");
                scanner.nextLine();
            }
        }
    }

    private void printHeader() {
        System.out.println("\n==================================================================================");
        System.out.println("                   STUDENT MANAGEMENT SYSTEM (Advanced Java & DSA)                 ");
        System.out.println("==================================================================================");
    }

    private void printMenu() {
        System.out.println(" [1] Add New Student              [6] Sort Students by Name (MergeSort)");
        System.out.println(" [2] Display All Students         [7] Update Student Record");
        System.out.println(" [3] Quick Search O(1) [HashMap]  [8] Delete Student Record");
        System.out.println(" [4] Binary Search O(log N) [BST] [9] View Class Analytics & Top Scorer");
        System.out.println(" [0] Exit Application");
        System.out.println("----------------------------------------------------------------------------------");
    }

    private void handleAddStudent() {
        System.out.println("\n--- Add New Student Record ---");
        try {
            System.out.print("Enter Roll Number (Integer): ");
            int rollNo = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Enter Student Full Name: ");
            String name = scanner.nextLine().trim();

            System.out.print("Enter Department (e.g. CS, IT, ECE): ");
            String dept = scanner.nextLine().trim();

            System.out.print("Enter GPA (0.0 to 4.0): ");
            double gpa = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Enter Email Address: ");
            String email = scanner.nextLine().trim();

            Student student = new Student(rollNo, name, dept, gpa, email);
            manager.addStudent(student);
            System.out.println("\n[SUCCESS] Student record added successfully!");
        } catch (NumberFormatException e) {
            System.out.println("\n[ERROR] Invalid number format entered.");
        } catch (DuplicateStudentException | InvalidDataException e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void handleDisplayAll() {
        System.out.println("\n--- All Student Records (BST In-Order Sorted by Roll No) ---");
        List<Student> students = manager.getStudentsSortedByRollNo();
        printTable(students);
    }

    private void handleSearchHashMap() {
        System.out.println("\n--- Fast O(1) Hash Map Search ---");
        try {
            System.out.print("Enter Roll Number to search: ");
            int rollNo = Integer.parseInt(scanner.nextLine().trim());
            long start = System.nanoTime();
            Student s = manager.searchByRollNoHashMap(rollNo);
            long end = System.nanoTime();

            System.out.println("\n[FOUND in " + (end - start) + " ns using Hash Table]");
            printSingleStudent(s);
        } catch (NumberFormatException e) {
            System.out.println("\n[ERROR] Roll number must be an integer.");
        } catch (StudentNotFoundException e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void handleSearchBST() {
        System.out.println("\n--- Binary Search Tree O(log N) Search ---");
        try {
            System.out.print("Enter Roll Number to search: ");
            int rollNo = Integer.parseInt(scanner.nextLine().trim());
            long start = System.nanoTime();
            Student s = manager.searchByRollNoBST(rollNo);
            long end = System.nanoTime();

            System.out.println("\n[FOUND in " + (end - start) + " ns using Custom BST Tree]");
            printSingleStudent(s);
        } catch (NumberFormatException e) {
            System.out.println("\n[ERROR] Roll number must be an integer.");
        } catch (StudentNotFoundException e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void handleSortByGPA() {
        System.out.println("\n--- Students Sorted by GPA Descending (Custom Merge Sort O(N log N)) ---");
        List<Student> sorted = manager.getStudentsSortedByGPA();
        printTable(sorted);
    }

    private void handleSortByName() {
        System.out.println("\n--- Students Sorted Alphabetically by Name (Custom Merge Sort O(N log N)) ---");
        List<Student> sorted = manager.getStudentsSortedByName();
        printTable(sorted);
    }

    private void handleUpdateStudent() {
        System.out.println("\n--- Update Student Record ---");
        try {
            System.out.print("Enter Roll Number of student to update: ");
            int rollNo = Integer.parseInt(scanner.nextLine().trim());

            Student existing = manager.searchByRollNoHashMap(rollNo);
            System.out.println("Current details: " + existing);

            System.out.print("Enter New Name (leave blank to keep '" + existing.getName() + "'): ");
            String name = scanner.nextLine().trim();

            System.out.print("Enter New Department (leave blank to keep '" + existing.getDepartment() + "'): ");
            String dept = scanner.nextLine().trim();

            System.out.print("Enter New GPA (leave blank to keep '" + existing.getGpa() + "'): ");
            String gpaStr = scanner.nextLine().trim();
            double gpa = gpaStr.isEmpty() ? existing.getGpa() : Double.parseDouble(gpaStr);

            System.out.print("Enter New Email (leave blank to keep '" + existing.getEmail() + "'): ");
            String email = scanner.nextLine().trim();

            manager.updateStudent(rollNo, name, dept, gpa, email);
            System.out.println("\n[SUCCESS] Student record updated successfully!");

        } catch (NumberFormatException e) {
            System.out.println("\n[ERROR] Invalid numerical format.");
        } catch (StudentNotFoundException | InvalidDataException e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void handleDeleteStudent() {
        System.out.println("\n--- Delete Student Record ---");
        try {
            System.out.print("Enter Roll Number to delete: ");
            int rollNo = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Are you sure you want to delete Roll No " + rollNo + "? (y/n): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            if (confirm.equals("y") || confirm.equals("yes")) {
                manager.removeStudent(rollNo);
                System.out.println("\n[SUCCESS] Student Roll No " + rollNo + " deleted!");
            } else {
                System.out.println("\n[INFO] Deletion canceled.");
            }
        } catch (NumberFormatException e) {
            System.out.println("\n[ERROR] Roll number must be an integer.");
        } catch (StudentNotFoundException e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void printAnalytics() {
        System.out.println("\n==================================================================================");
        System.out.println("                            CLASS ANALYTICS & SUMMARY                            ");
        System.out.println("==================================================================================");
        System.out.printf(" Total Registered Students : %d%n", manager.getTotalCount());
        System.out.printf(" Class Average GPA        : %.2f / 4.00%n", manager.getAverageGPA());

        Student top = manager.getTopScorer();
        if (top != null) {
            System.out.printf(" Top Scoring Student       : %s (Roll No: %d) with GPA: %.2f%n",
                    top.getName(), top.getRollNo(), top.getGpa());
        }
        System.out.println("==================================================================================");
    }

    private void printTable(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.println("+---------+--------------------+--------------------+------+------------------------------+");
        System.out.println("| Roll No | Name               | Department         | GPA  | Email                        |");
        System.out.println("+---------+--------------------+--------------------+------+------------------------------+");
        for (Student s : students) {
            System.out.printf("| %-7d | %-18s | %-18s | %-4.2f | %-28s |%n",
                    s.getRollNo(),
                    truncate(s.getName(), 18),
                    truncate(s.getDepartment(), 18),
                    s.getGpa(),
                    truncate(s.getEmail(), 28));
        }
        System.out.println("+---------+--------------------+--------------------+------+------------------------------+");
    }

    private void printSingleStudent(Student s) {
        List<Student> list = List.of(s);
        printTable(list);
    }

    private String truncate(String text, int length) {
        if (text == null) return "";
        if (text.length() <= length) return text;
        return text.substring(0, length - 3) + "...";
    }
}
