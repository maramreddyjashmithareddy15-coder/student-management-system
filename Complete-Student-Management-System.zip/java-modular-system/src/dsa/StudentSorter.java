package dsa;

import model.Student;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom Sorting Algorithm (Merge Sort) implementation for Student Data.
 * Demonstrates Divide and Conquer strategy with O(N log N) Time Complexity.
 */
public class StudentSorter {

    /**
     * Sorts student list by GPA descending using Merge Sort algorithm.
     */
    public static List<Student> sortByGpaDescending(List<Student> students) {
        if (students.size() <= 1) return students;
        
        List<Student> list = new ArrayList<>(students);
        mergeSortGpa(list, 0, list.size() - 1);
        return list;
    }

    private static void mergeSortGpa(List<Student> list, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSortGpa(list, left, mid);
            mergeSortGpa(list, mid + 1, right);
            mergeGpa(list, left, mid, right);
        }
    }

    private static void mergeGpa(List<Student> list, int left, int mid, int right) {
        List<Student> temp = new ArrayList<>();
        int i = left;
        int j = mid + 1;

        while (i <= mid && j <= right) {
            // High GPA comes first (descending)
            if (list.get(i).getGpa() >= list.get(j).getGpa()) {
                temp.add(list.get(i++));
            } else {
                temp.add(list.get(j++));
            }
        }

        while (i <= mid) temp.add(list.get(i++));
        while (j <= right) temp.add(list.get(j++));

        for (int k = 0; k < temp.size(); k++) {
            list.set(left + k, temp.get(k));
        }
    }

    /**
     * Sorts student list alphabetically by Name using Merge Sort.
     */
    public static List<Student> sortByNameAscending(List<Student> students) {
        if (students.size() <= 1) return students;

        List<Student> list = new ArrayList<>(students);
        mergeSortName(list, 0, list.size() - 1);
        return list;
    }

    private static void mergeSortName(List<Student> list, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSortName(list, left, mid);
            mergeSortName(list, mid + 1, right);
            mergeName(list, left, mid, right);
        }
    }

    private static void mergeName(List<Student> list, int left, int mid, int right) {
        List<Student> temp = new ArrayList<>();
        int i = left;
        int j = mid + 1;

        while (i <= mid && j <= right) {
            if (list.get(i).getName().compareToIgnoreCase(list.get(j).getName()) <= 0) {
                temp.add(list.get(i++));
            } else {
                temp.add(list.get(j++));
            }
        }

        while (i <= mid) temp.add(list.get(i++));
        while (j <= right) temp.add(list.get(j++));

        for (int k = 0; k < temp.size(); k++) {
            list.set(left + k, temp.get(k));
        }
    }
}
