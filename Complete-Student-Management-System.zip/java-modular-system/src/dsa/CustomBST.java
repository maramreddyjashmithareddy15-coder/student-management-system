package dsa;

import model.Student;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom Binary Search Tree (BST) indexed by Student Roll Number.
 * Demonstrates tree node hierarchy, recursion, O(log N) search, and In-Order Traversal.
 */
public class CustomBST {

    public static class BSTNode {
        public Student data;
        public BSTNode left;
        public BSTNode right;

        public BSTNode(Student data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private BSTNode root;

    public CustomBST() {
        this.root = null;
    }

    /**
     * Inserts a student into the BST by Roll Number.
     */
    public void insert(Student student) {
        root = insertRecursive(root, student);
    }

    private BSTNode insertRecursive(BSTNode node, Student student) {
        if (node == null) {
            return new BSTNode(student);
        }
        if (student.getRollNo() < node.data.getRollNo()) {
            node.left = insertRecursive(node.left, student);
        } else if (student.getRollNo() > node.data.getRollNo()) {
            node.right = insertRecursive(node.right, student);
        } else {
            // Roll number exists, update student record
            node.data = student;
        }
        return node;
    }

    /**
     * Searches for a student by Roll Number in O(log N) average time.
     */
    public Student search(int rollNo) {
        return searchRecursive(root, rollNo);
    }

    private Student searchRecursive(BSTNode node, int rollNo) {
        if (node == null) return null;
        if (rollNo == node.data.getRollNo()) return node.data;
        if (rollNo < node.data.getRollNo()) return searchRecursive(node.left, rollNo);
        return searchRecursive(node.right, rollNo);
    }

    /**
     * In-Order Traversal returns students sorted by Roll Number automatically.
     */
    public List<Student> inOrderTraversal() {
        List<Student> result = new ArrayList<>();
        inOrderRecursive(root, result);
        return result;
    }

    private void inOrderRecursive(BSTNode node, List<Student> result) {
        if (node != null) {
            inOrderRecursive(node.left, result);
            result.add(node.data);
            inOrderRecursive(node.right, result);
        }
    }

    public void clear() {
        root = null;
    }
}
