package dsa;

import model.Student;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom Doubly Linked List implementation for dynamic student records.
 * Demonstrates pointer manipulation (head, tail, prev, next) in Data Structures.
 */
public class CustomLinkedList {

    // Node inner class
    public static class Node {
        public Student data;
        public Node next;
        public Node prev;

        public Node(Student data) {
            this.data = data;
            this.next = null;
            this.prev = null;
        }
    }

    private Node head;
    private Node tail;
    private int size;

    public CustomLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    /**
     * Adds a new student to the end of the list. Time Complexity: O(1)
     */
    public void add(Student student) {
        Node newNode = new Node(student);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    /**
     * Removes a student by roll number. Time Complexity: O(N)
     */
    public boolean remove(int rollNo) {
        Node current = head;
        while (current != null) {
            if (current.data.getRollNo() == rollNo) {
                if (current == head && current == tail) {
                    head = tail = null;
                } else if (current == head) {
                    head = head.next;
                    head.prev = null;
                } else if (current == tail) {
                    tail = tail.prev;
                    tail.next = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                size--;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    /**
     * Linear search by roll number. Time Complexity: O(N)
     */
    public Student findByRollNo(int rollNo) {
        Node current = head;
        while (current != null) {
            if (current.data.getRollNo() == rollNo) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    /**
     * Converts linked list to a Standard List for sorting/display operations.
     */
    public List<Student> getAll() {
        List<Student> list = new ArrayList<>();
        Node current = head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }
        return list;
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        head = tail = null;
        size = 0;
    }
}
