package dsa;

import model.Student;

/**
 * Custom Hash Map using Separate Chaining for O(1) average lookup time.
 * Demonstrates Hashing Function, Bucket Arrays, and Collision Resolution.
 */
public class CustomHashMap {

    private static class HashNode {
        int key; // Roll Number
        Student value;
        HashNode next;

        public HashNode(int key, Student value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }
    }

    private static final int INITIAL_CAPACITY = 16;
    private HashNode[] buckets;
    private int size;

    public CustomHashMap() {
        this.buckets = new HashNode[INITIAL_CAPACITY];
        this.size = 0;
    }

    /**
     * Simple hash function mapping integer key to bucket index.
     */
    private int getBucketIndex(int key) {
        return Math.abs(key) % buckets.length;
    }

    /**
     * Inserts or updates a student in the hash table. O(1) average complexity.
     */
    public void put(int rollNo, Student student) {
        int index = getBucketIndex(rollNo);
        HashNode head = buckets[index];

        // Check if key exists
        while (head != null) {
            if (head.key == rollNo) {
                head.value = student;
                return;
            }
            head = head.next;
        }

        // Insert new node at bucket head
        HashNode newNode = new HashNode(rollNo, student);
        newNode.next = buckets[index];
        buckets[index] = newNode;
        size++;
    }

    /**
     * Gets a student by Roll Number in O(1) average time complexity.
     */
    public Student get(int rollNo) {
        int index = getBucketIndex(rollNo);
        HashNode head = buckets[index];
        while (head != null) {
            if (head.key == rollNo) {
                return head.value;
            }
            head = head.next;
        }
        return null;
    }

    /**
     * Removes a student by Roll Number.
     */
    public boolean remove(int rollNo) {
        int index = getBucketIndex(rollNo);
        HashNode head = buckets[index];
        HashNode prev = null;

        while (head != null) {
            if (head.key == rollNo) {
                if (prev != null) {
                    prev.next = head.next;
                } else {
                    buckets[index] = head.next;
                }
                size--;
                return true;
            }
            prev = head;
            head = head.next;
        }
        return false;
    }

    public int getSize() {
        return size;
    }

    public void clear() {
        buckets = new HashNode[INITIAL_CAPACITY];
        size = 0;
    }
}
