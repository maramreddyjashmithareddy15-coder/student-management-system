# Student Management System (Advanced Java & DSA Mini Project)

A complete, zero-dependency Student Management System written in **Advanced Java** with custom **Data Structures & Algorithms (DSA)** implementation.

---

## Features At A Glance
- **Custom Doubly Linked List**: Dynamic list insertion and deletion (`CustomLinkedList.java`).
- **Custom Binary Search Tree (BST)**: $O(\log N)$ tree lookup and sorted roll number traversal (`CustomBST.java`).
- **Custom Hash Map**: $O(1)$ constant time lookup with separate chaining collision resolution (`CustomHashMap.java`).
- **Custom Merge Sort**: $O(N \log N)$ divide-and-conquer sorting algorithm by GPA and Name (`StudentSorter.java`).
- **File I/O Data Persistence**: Auto-saves and restores student data to `students.csv`.
- **JDBC Database Component**: Modular JDBC support for database storage (`DatabaseHandler.java`).
- **Multithreading**: Background daemon thread (`AutoSaveWorker.java`) for period automatic disk synchronization.
- **Custom Exception Handling**: Clean exception propagation (`StudentNotFoundException`, `DuplicateStudentException`, `InvalidDataException`).
- **ASCII CLI Interface**: Interactive menu with formatted tables and input validation (`ConsoleUI.java`).

---

## Documentation Links
- 📘 [PROJECT_EXPLANATION.md](file:///c:/Users/HP/Downloads/Java%20Student%20management%20system/PROJECT_EXPLANATION.md) - Complete technical breakdown, architecture explanation, class details, and DSA complexity analysis.
- 🚀 [HOW_TO_RUN.md](file:///c:/Users/HP/Downloads/Java%20Student%20management%20system/HOW_TO_RUN.md) - Simple step-by-step guide to run the project on Windows, macOS, Linux, VS Code, Eclipse, or IntelliJ IDEA.

---

## Quick Start (Windows)
Double click [`run.bat`](file:///c:/Users/HP/Downloads/Java%20Student%20management%20system/run.bat) or execute:
```cmd
run.bat
```

## Quick Start (macOS / Linux)
```bash
chmod +x run.sh
./run.sh
```
