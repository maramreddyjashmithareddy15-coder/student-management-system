# Project Explanation - Student Management System (Advanced Java & DSA)

## 1. Overview
The **Student Management System (SMS)** is a high-performance, console-based Java application built specifically as a mini-project for students learning **Advanced Java Programming** and **Data Structures & Algorithms (DSA)**.

Instead of relying solely on built-in Java library collections or framework abstractions, this project implements custom core data structures from scratch (Doubly Linked List, Binary Search Tree, Hash Map with Chaining, Merge Sort) while integrating enterprise-grade Advanced Java patterns like **File I/O Persistence**, **JDBC Database connectivity**, **Multithreaded Background Auto-Saving**, and **Custom Exception Handling**.

---

## 2. System Architecture & Package Hierarchy

The project follows a clean **Layered Architecture Pattern**:

```
c:\Users\HP\Downloads\Java Student management system\
│
├── run.bat                         <-- Windows 1-click execution script
├── run.sh                          <-- Linux/macOS execution script
├── students.csv                    <-- Auto-generated persistent data file
│
├── PROJECT_EXPLANATION.md          <-- Detailed Project Explanation (This file)
├── HOW_TO_RUN.md                   <-- How-to-run instructions
└── README.md                       <-- Overview guide
│
└── src/
    ├── Main.java                   <-- Application entry point & Shutdown hooks
    │
    ├── model/                      <-- Data Domain Layer
    │   └── Student.java            <-- Encapsulated Student object model
    │
    ├── dsa/                        <-- Data Structures & Algorithms Layer
    │   ├── CustomLinkedList.java   <-- Doubly Linked List implementation
    │   ├── CustomBST.java          <-- Binary Search Tree (BST)
    │   ├── CustomHashMap.java      <-- Hash Map with Chaining
    │   └── StudentSorter.java      <-- Merge Sort algorithm implementation
    │
    ├── service/                    <-- Business Logic Layer
    │   └── StudentManager.java     <-- Coordinates DSA, persistence & validation
    │
    ├── util/                       <-- Utilities & Infrastructure Layer
    │   ├── FileHandler.java        <-- CSV File I/O reader & writer
    │   ├── DatabaseHandler.java    <-- JDBC SQL Database helper
    │   └── AutoSaveWorker.java     <-- Background Daemon Thread for periodic auto-save
    │
    ├── exception/                  <-- Custom Exception Layer
    │   ├── StudentNotFoundException.java
    │   ├── DuplicateStudentException.java
    │   └── InvalidDataException.java
    │
    └── ui/                         <-- User Interface Layer
        └── ConsoleUI.java          <-- Interactive CLI with ASCII formatting & validation
```

---

## 3. Data Structures & Algorithms (DSA) Explained

This project demonstrates 4 fundamental Data Structures and Algorithms:

### A. Custom Doubly Linked List (`CustomLinkedList.java`)
- **What it is**: A linear data structure where each element (Node) contains data and two pointers: `prev` (pointing to previous node) and `next` (pointing to next node).
- **Why we use it**: Allows dynamic addition and deletion of students without needing a fixed array capacity.
- **Operations**:
  - `add(Student)`: Appends to `tail` in $O(1)$ time.
  - `remove(rollNo)`: Re-links `prev.next` and `next.prev` pointers in $O(N)$ time.

### B. Custom Binary Search Tree (`CustomBST.java`)
- **What it is**: A hierarchical tree where for every node:
  - Left subtree contains nodes with **smaller** Roll Numbers.
  - Right subtree contains nodes with **larger** Roll Numbers.
- **Why we use it**: Enables logarithmic searching $O(\log N)$ by Roll Number and natural sorted traversal.
- **Key Concepts**:
  - `search(rollNo)`: Recursively navigates left or right branch in $O(\log N)$ average time.
  - `inOrderTraversal()`: Visits `Left -> Node -> Right` to produce students sorted by Roll Number automatically!

### C. Custom Hash Map with Chaining (`CustomHashMap.java`)
- **What it is**: A key-value hash table where keys (Roll Numbers) are mapped to array buckets using a Hash Function `Math.abs(key) % capacity`.
- **Collision Handling**: Uses **Separate Chaining** (linked list inside each bucket) if two roll numbers hash to the same bucket.
- **Why we use it**: Provides instantaneous $O(1)$ constant time lookup for checking student existence or retrieving student data.

### D. Custom Merge Sort (`StudentSorter.java`)
- **What it is**: A **Divide and Conquer** sorting algorithm.
  1. **Divide**: Splitting student array into left and right halves.
  2. **Conquer**: Recursively sorting sub-arrays.
  3. **Combine**: Merging sorted sub-arrays back together.
- **Why we use it**: Guaranteed $O(N \log N)$ time complexity across all cases (best, worst, average) for sorting students by **GPA** or **Name**.

---

## 4. Advanced Java Concepts Explained

### 1. Object-Oriented Programming (OOP)
- **Encapsulation**: Private fields (`rollNo`, `name`, `gpa`, `email`) in [`Student.java`](file:///c:/Users/HP/Downloads/Java%20Student%20management%20system/src/model/Student.java) accessed via public getters and setters.
- **Polymorphism & Method Overriding**: Overriding `toString()` for clean formatted console printing.

### 2. Multithreading & Concurrency (`AutoSaveWorker.java`)
- Implements `java.lang.Runnable`.
- Runs as a **Daemon Thread** in the background, automatically invoking `saveData()` every 30 seconds without freezing the main menu thread.
- Uses `Runtime.getRuntime().addShutdownHook()` to guarantee data is saved safely when the user exits the program or presses Ctrl+C.

### 3. Persistent File I/O (`FileHandler.java`)
- Uses `BufferedReader` and `BufferedWriter` to read/write comma-separated values (`students.csv`).
- Data persists on disk across program restarts.

### 4. JDBC Database Connectivity (`DatabaseHandler.java`)
- Demonstrates standard Java Database Connectivity (JDBC) using `Connection`, `PreparedStatement`, `Statement`, and `ResultSet`.
- Prepared statements prevent SQL Injection attacks.
- Gracefully falls back to File I/O if no external SQLite database driver is provided.

### 5. Custom Exception Handling (`exception/`)
- User-defined exceptions (`StudentNotFoundException`, `DuplicateStudentException`, `InvalidDataException`) provide descriptive error handling when invalid actions occur.

---

## 5. DSA Complexity Analysis Table

| Operation | Custom Structure | Time Complexity (Average) | Time Complexity (Worst) | Space Complexity |
| :--- | :--- | :--- | :--- | :--- |
| **Add Student** | `CustomLinkedList` | $O(1)$ | $O(1)$ | $O(1)$ |
| **Delete Student** | `CustomLinkedList` | $O(N)$ | $O(N)$ | $O(1)$ |
| **Roll No Search** | `CustomHashMap` | $O(1)$ | $O(N)$ | $O(N)$ |
| **BST Search** | `CustomBST` | $O(\log N)$ | $O(N)$ | $O(N)$ |
| **In-Order Sort** | `CustomBST` | $O(N)$ | $O(N)$ | $O(N)$ |
| **Merge Sort (GPA/Name)** | `StudentSorter` | $O(N \log N)$ | $O(N \log N)$ | $O(N)$ |
