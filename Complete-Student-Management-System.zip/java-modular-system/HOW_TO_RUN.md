# How to Run the Student Management System

This document provides simple step-by-step instructions to compile and run the **Student Management System** across different operating systems and IDEs.

---

## Prerequisites
- **Java Development Kit (JDK 8 or higher)** installed on your machine.
- Verify Java installation by opening Command Prompt or Terminal and running:
  ```bash
  java -version
  javac -version
  ```

---

## Method 1: Using 1-Click Execution Scripts (Recommended)

### On Windows
1. Open the project folder: `c:\Users\HP\Downloads\Java Student management system\`
2. Double-click **`run.bat`** (or right-click -> Open).
3. The script will automatically compile all Java files into the `bin/` directory and launch the console application!

### On Linux or macOS
1. Open Terminal and navigate to the project directory:
   ```bash
   cd "Java Student management system"
   ```
2. Make the script executable:
   ```bash
   chmod +x run.sh
   ```
3. Run the script:
   ```bash
   ./run.sh
   ```

---

## Method 2: Manual Command Prompt / Terminal Execution

If you prefer compiling manually via command line:

### Step 1: Open Terminal in the project root directory
```bash
cd "c:\Users\HP\Downloads\Java Student management system"
```

### Step 2: Compile all Java files into `bin/` directory
- **On Windows (Command Prompt)**:
  ```cmd
  if not exist bin mkdir bin
  javac -d bin src\model\*.java src\exception\*.java src\dsa\*.java src\util\*.java src\service\*.java src\ui\*.java src\Main.java
  ```

- **On macOS / Linux**:
  ```bash
  mkdir -p bin
  javac -d bin src/model/*.java src/exception/*.java src/dsa/*.java src/util/*.java src/service/*.java src/ui/*.java src/Main.java
  ```

### Step 3: Run the compiled application
```bash
java -cp bin Main
```

---

## Method 3: Running in IDEs (VS Code, Eclipse, IntelliJ IDEA)

### VS Code
1. Open VS Code -> Click **File** -> **Open Folder...** -> Select the `Java Student management system` folder.
2. Open `src/Main.java`.
3. Click the **Run** button at the top right (or press `F5` / `Ctrl + F5`).

### Eclipse IDE
1. Open Eclipse -> **File** -> **Import...** -> **Existing Projects into Workspace**.
2. Select root directory `Java Student management system`.
3. Right-click `Main.java` -> **Run As** -> **Java Application**.

### IntelliJ IDEA
1. Open IntelliJ IDEA -> **File** -> **Open** -> Select `Java Student management system`.
2. Ensure `src` is marked as **Sources Root** (Right click `src` folder -> Mark Directory as -> Sources Root).
3. Open `Main.java` and click the green **Play** button next to `public static void main`.

---

## What to Expect Upon Running
1. The app automatically creates a default file `students.csv` and populates 5 sample student records if none exist.
2. An interactive ASCII menu will open in your terminal:
   ```
   ==================================================================================
                      STUDENT MANAGEMENT SYSTEM (Advanced Java & DSA)                 
   ==================================================================================
    [1] Add New Student              [6] Sort Students by Name (MergeSort)
    [2] Display All Students         [7] Update Student Record
    [3] Quick Search O(1) [HashMap]  [8] Delete Student Record
    [4] Binary Search O(log N) [BST] [9] View Class Analytics & Top Scorer
    [0] Exit Application
   ----------------------------------------------------------------------------------
   Enter choice (1-9):
   ```
3. When you exit option `0`, data is auto-saved to `students.csv` on disk so all updates persist for next time!
