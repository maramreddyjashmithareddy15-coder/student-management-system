#!/bin/bash
echo "========================================================"
echo "  Compiling Student Management System Java Files..."
echo "========================================================"

mkdir -p bin

javac -encoding UTF-8 -d bin src/model/*.java src/exception/*.java src/dsa/*.java src/util/*.java src/service/*.java src/ui/*.java src/Main.java

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] Compilation failed! Please check Java JDK installation."
    exit 1
fi

echo ""
echo "[SUCCESS] Compilation complete! Launching application..."
echo "========================================================"
echo ""

java -cp bin Main
