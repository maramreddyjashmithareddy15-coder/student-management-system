import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String DATA_FILE = "data/students.txt";
    private static final StudentManager manager = new StudentManager();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Auto-load data on startup
        System.out.println("==========================================================");
        System.out.println("          Loading student data, please wait...           ");
        System.out.println("==========================================================");
        try {
            manager.loadStudents(DATA_FILE);
            System.out.println("✔ Data loaded successfully from " + DATA_FILE);
            System.out.println("  Total loaded students: " + manager.getStudentsList().size());
        } catch (IOException e) {
            System.out.println("⚠ No existing database found or error reading data. Starting fresh.");
        }

        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = InputValidator.readInt(scanner, "Enter your choice: ", 1, 14);
            switch (choice) {
                case 1:
                    handleAddStudent();
                    break;
                case 2:
                    handleViewAllStudents();
                    break;
                case 3:
                    handleSearchMenu();
                    break;
                case 4:
                    handleUpdateStudent();
                    break;
                case 5:
                    handleDeleteStudent();
                    break;
                case 6:
                    handleUndoDelete();
                    break;
                case 7:
                    handleSortStudents();
                    break;
                case 8:
                    handleBinarySearchDirect();
                    break;
                case 9:
                    handleAdmissionQueueMenu();
                    break;
                case 10:
                    handleViewRecentlyDeleted();
                    break;
                case 11:
                    manager.displayStatistics();
                    break;
                case 12:
                    handleSaveData();
                    break;
                case 13:
                    handleLoadData();
                    break;
                case 14:
                    handleExit();
                    running = false;
                    break;
            }
            if (running) {
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("\n=========================================");
        System.out.println("        STUDENT MANAGEMENT SYSTEM        ");
        System.out.println("=========================================");
        System.out.println(" 1. Add Student");
        System.out.println(" 2. View All Students");
        System.out.println(" 3. Search Student");
        System.out.println(" 4. Update Student");
        System.out.println(" 5. Delete Student");
        System.out.println(" 6. Undo Delete");
        System.out.println(" 7. Sort Students");
        System.out.println(" 8. Binary Search");
        System.out.println(" 9. Admission Queue");
        System.out.println(" 10. Recently Deleted Students (Stack)");
        System.out.println(" 11. Student Statistics");
        System.out.println(" 12. Save Data");
        System.out.println(" 13. Load Data");
        System.out.println(" 14. Exit");
        System.out.println("=========================================");
    }

    private static void handleAddStudent() {
        System.out.println("\n--- Add Student ---");
        int id = InputValidator.readInt(scanner, "Enter Student ID (positive integer): ", 1, Integer.MAX_VALUE);
        if (manager.getStudentById(id) != null) {
            System.out.println("Error: Student ID " + id + " already exists in the system.");
            return;
        }

        String name = InputValidator.readValidatedString(scanner, 
                "Enter Name: ", 
                "Name cannot be empty and should contain only letters/spaces (2-50 chars).",
                InputValidator::isValidName);

        int age = InputValidator.readInt(scanner, "Enter Age (17 - 100): ", 17, 100);

        String gender = InputValidator.readValidatedString(scanner, 
                "Enter Gender (Male/Female/Other): ", 
                "Gender must be 'Male', 'Female', or 'Other'.",
                InputValidator::isValidGender);

        String branch = InputValidator.readValidatedString(scanner, 
                "Enter Branch (e.g. CSE, ECE, ME): ", 
                "Branch cannot be empty.",
                InputValidator::isValidBranch);

        int year = InputValidator.readInt(scanner, "Enter Study Year (1 - 4): ", 1, 4);

        String email = InputValidator.readValidatedString(scanner, 
                "Enter Email: ", 
                "Invalid email format.",
                InputValidator::isValidEmail);

        String phone = InputValidator.readValidatedString(scanner, 
                "Enter 10-digit Phone Number: ", 
                "Phone number must contain exactly 10 digits.",
                InputValidator::isValidPhone);

        double marks = InputValidator.readDouble(scanner, "Enter Marks (0.0 - 100.0): ", 0.0, 100.0);
        double attendance = InputValidator.readDouble(scanner, "Enter Attendance % (0.0 - 100.0): ", 0.0, 100.0);

        Student s = new Student(id, name, age, gender, branch, year, email, phone, marks, attendance);
        if (manager.addStudent(s)) {
            System.out.println("\n✔ Student added successfully!");
            System.out.println(Student.getTabularHeader());
            System.out.println(s.getTabularRow());
            System.out.println(Student.getTabularDivider());
        } else {
            System.out.println("Error adding student.");
        }
    }

    private static void handleViewAllStudents() {
        System.out.println("\n--- View All Students ---");
        System.out.println("1. View via Custom Doubly Linked List (Dynamic Traversal)");
        System.out.println("2. View via ArrayList (Default Order)");
        int viewChoice = InputValidator.readInt(scanner, "Choose view option: ", 1, 2);

        if (viewChoice == 1) {
            System.out.println("\n[Custom Doubly Linked List Traversal]");
            manager.getCustomLinkedList().display();
        } else {
            System.out.println("\n[ArrayList Direct Display]");
            ArrayList<Student> list = manager.getStudentsList();
            if (list.isEmpty()) {
                System.out.println("No student records found.");
                return;
            }
            System.out.println(Student.getTabularHeader());
            for (Student s : list) {
                System.out.println(s.getTabularRow());
            }
            System.out.println(Student.getTabularDivider());
        }
    }

    private static void handleSearchMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n=========================================");
            System.out.println("              SEARCH MENU                ");
            System.out.println("=========================================");
            System.out.println(" 1. Search by Student ID (Linear Search)");
            System.out.println(" 2. Search by Name (Linear Search)");
            System.out.println(" 3. Search by Branch (Linear Search)");
            System.out.println(" 4. Binary Search by ID (Recursive, Logarithmic)");
            System.out.println(" 5. Back to Main Menu");
            System.out.println("=========================================");

            int choice = InputValidator.readInt(scanner, "Enter search type: ", 1, 5);
            switch (choice) {
                case 1:
                    int searchId = InputValidator.readInt(scanner, "Enter Student ID to search: ", 1, Integer.MAX_VALUE);
                    Student foundId = SearchAlgorithms.linearSearchById(manager.getStudentsList(), searchId);
                    displaySearchResult(foundId);
                    break;
                case 2:
                    System.out.print("Enter Name (or partial query) to search: ");
                    String searchName = scanner.nextLine().trim();
                    List<Student> foundNames = SearchAlgorithms.linearSearchByName(manager.getStudentsList(), searchName);
                    displaySearchResultsList(foundNames);
                    break;
                case 3:
                    System.out.print("Enter Branch to search: ");
                    String searchBranch = scanner.nextLine().trim();
                    List<Student> foundBranch = SearchAlgorithms.linearSearchByBranch(manager.getStudentsList(), searchBranch);
                    displaySearchResultsList(foundBranch);
                    break;
                case 4:
                    int binSearchId = InputValidator.readInt(scanner, "Enter Student ID to binary search: ", 1, Integer.MAX_VALUE);
                    Student foundBin = SearchAlgorithms.binarySearchById(manager.getStudentsList(), binSearchId);
                    displaySearchResult(foundBin);
                    break;
                case 5:
                    back = true;
                    break;
            }
            if (!back) {
                System.out.println("\nPress Enter to return to search menu...");
                scanner.nextLine();
            }
        }
    }

    private static void displaySearchResult(Student s) {
        if (s == null) {
            System.out.println("\n❌ Student not found.");
        } else {
            System.out.println("\n✔ Student Record Found:");
            System.out.println(Student.getTabularHeader());
            System.out.println(s.getTabularRow());
            System.out.println(Student.getTabularDivider());
        }
    }

    private static void displaySearchResultsList(List<Student> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("\n❌ No student records matched the criteria.");
        } else {
            System.out.println("\n✔ Matching Student Records Found:");
            System.out.println(Student.getTabularHeader());
            for (Student s : list) {
                System.out.println(s.getTabularRow());
            }
            System.out.println(Student.getTabularDivider());
        }
    }

    private static void handleUpdateStudent() {
        System.out.println("\n--- Update Student ---");
        int id = InputValidator.readInt(scanner, "Enter Student ID to update: ", 1, Integer.MAX_VALUE);
        Student s = manager.getStudentById(id);
        if (s == null) {
            System.out.println("❌ Error: Student ID " + id + " does not exist.");
            return;
        }

        System.out.println("\nExisting student details:");
        System.out.println(Student.getTabularHeader());
        System.out.println(s.getTabularRow());
        System.out.println(Student.getTabularDivider());

        System.out.println("\nEnter new details (to keep previous value, press Enter without typing anything):");

        System.out.print("Enter Name [" + s.getName() + "]: ");
        String nameInput = scanner.nextLine().trim();
        String name = nameInput.isEmpty() ? s.getName() : nameInput;
        while (!nameInput.isEmpty() && !InputValidator.isValidName(name)) {
            System.out.println("Invalid name format. Letters and spaces only.");
            System.out.print("Enter Name [" + s.getName() + "]: ");
            nameInput = scanner.nextLine().trim();
            name = nameInput.isEmpty() ? s.getName() : nameInput;
        }

        System.out.print("Enter Branch [" + s.getBranch() + "]: ");
        String branchInput = scanner.nextLine().trim();
        String branch = branchInput.isEmpty() ? s.getBranch() : branchInput;

        System.out.print("Enter Email [" + s.getEmail() + "]: ");
        String emailInput = scanner.nextLine().trim();
        String email = emailInput.isEmpty() ? s.getEmail() : emailInput;
        while (!emailInput.isEmpty() && !InputValidator.isValidEmail(email)) {
            System.out.println("Invalid email format.");
            System.out.print("Enter Email [" + s.getEmail() + "]: ");
            emailInput = scanner.nextLine().trim();
            email = emailInput.isEmpty() ? s.getEmail() : emailInput;
        }

        System.out.print("Enter Phone [" + s.getPhone() + "]: ");
        String phoneInput = scanner.nextLine().trim();
        String phone = phoneInput.isEmpty() ? s.getPhone() : phoneInput;
        while (!phoneInput.isEmpty() && !InputValidator.isValidPhone(phone)) {
            System.out.println("Phone must be exactly 10 digits.");
            System.out.print("Enter Phone [" + s.getPhone() + "]: ");
            phoneInput = scanner.nextLine().trim();
            phone = phoneInput.isEmpty() ? s.getPhone() : phoneInput;
        }

        System.out.print("Enter Marks [" + s.getMarks() + "] (0.0 - 100.0): ");
        String marksInput = scanner.nextLine().trim();
        double marks = s.getMarks();
        if (!marksInput.isEmpty()) {
            try {
                double temp = Double.parseDouble(marksInput);
                if (InputValidator.isValidMarks(temp)) {
                    marks = temp;
                } else {
                    System.out.println("Invalid marks range. Keeping previous.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Keeping previous.");
            }
        }

        System.out.print("Enter Attendance [" + s.getAttendance() + "] (0.0 - 100.0): ");
        String attInput = scanner.nextLine().trim();
        double attendance = s.getAttendance();
        if (!attInput.isEmpty()) {
            try {
                double temp = Double.parseDouble(attInput);
                if (InputValidator.isValidAttendance(temp)) {
                    attendance = temp;
                } else {
                    System.out.println("Invalid attendance range. Keeping previous.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid number format. Keeping previous.");
            }
        }

        if (manager.updateStudent(id, name, email, phone, branch, marks, attendance)) {
            System.out.println("\n✔ Student record updated successfully!");
            Student updated = manager.getStudentById(id);
            System.out.println(Student.getTabularHeader());
            System.out.println(updated.getTabularRow());
            System.out.println(Student.getTabularDivider());
        } else {
            System.out.println("❌ Error updating student.");
        }
    }

    private static void handleDeleteStudent() {
        System.out.println("\n--- Delete Student ---");
        int id = InputValidator.readInt(scanner, "Enter Student ID to delete: ", 1, Integer.MAX_VALUE);
        Student s = manager.getStudentById(id);
        if (s == null) {
            System.out.println("❌ Error: Student ID " + id + " not found.");
            return;
        }

        System.out.println("Student found: " + s.getName() + " (" + s.getBranch() + ")");
        System.out.print("Are you sure you want to delete this student? (Y/N): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();
        if (confirmation.equals("y") || confirmation.equals("yes")) {
            if (manager.deleteStudent(id)) {
                System.out.println("✔ Student deleted successfully. Record moved to Undo Stack.");
            } else {
                System.out.println("❌ Error executing deletion.");
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    private static void handleUndoDelete() {
        System.out.println("\n--- Undo Delete Student ---");
        Student restored = manager.undoDelete();
        if (restored != null) {
            System.out.println("✔ Student restored successfully!");
            System.out.println(Student.getTabularHeader());
            System.out.println(restored.getTabularRow());
            System.out.println(Student.getTabularDivider());
        } else {
            System.out.println("❌ Undo Stack is empty. No recently deleted students to restore.");
        }
    }

    private static void handleSortStudents() {
        ArrayList<Student> list = manager.getStudentsList();
        if (list.isEmpty()) {
            System.out.println("\n❌ No students registered. Cannot perform sorting.");
            return;
        }

        System.out.println("\n--- Sort Students ---");
        System.out.println("Select Sorting Algorithm:");
        System.out.println(" 1. Bubble Sort       - O(n^2)");
        System.out.println(" 2. Selection Sort    - O(n^2)");
        System.out.println(" 3. Insertion Sort    - O(n^2)");
        System.out.println(" 4. Merge Sort        - O(n log n) [Recursive, Stable]");
        System.out.println(" 5. Quick Sort        - O(n log n) average [Recursive, In-place]");
        int algoChoice = InputValidator.readInt(scanner, "Choose algorithm: ", 1, 5);

        System.out.println("Select Sort Key:");
        System.out.println(" 1. Student ID");
        System.out.println(" 2. Name");
        System.out.println(" 3. Marks");
        System.out.println(" 4. Attendance");
        int keyChoice = InputValidator.readInt(scanner, "Choose sort attribute: ", 1, 4);

        System.out.println("Select Order:");
        System.out.println(" 1. Ascending");
        System.out.println(" 2. Descending");
        int orderChoice = InputValidator.readInt(scanner, "Choose sort direction: ", 1, 2);

        String sortBy = "";
        switch (keyChoice) {
            case 1: sortBy = "id"; break;
            case 2: sortBy = "name"; break;
            case 3: sortBy = "marks"; break;
            case 4: sortBy = "attendance"; break;
        }

        boolean ascending = (orderChoice == 1);

        // Sort on a copy to preview
        ArrayList<Student> previewList = new ArrayList<>(list);
        long startTime = System.nanoTime();

        String algoName = "";
        switch (algoChoice) {
            case 1:
                SortingAlgorithms.bubbleSort(previewList, sortBy, ascending);
                algoName = "Bubble Sort";
                break;
            case 2:
                SortingAlgorithms.selectionSort(previewList, sortBy, ascending);
                algoName = "Selection Sort";
                break;
            case 3:
                SortingAlgorithms.insertionSort(previewList, sortBy, ascending);
                algoName = "Insertion Sort";
                break;
            case 4:
                SortingAlgorithms.mergeSort(previewList, sortBy, ascending);
                algoName = "Merge Sort";
                break;
            case 5:
                SortingAlgorithms.quickSort(previewList, sortBy, ascending);
                algoName = "Quick Sort";
                break;
        }

        long duration = System.nanoTime() - startTime;

        System.out.println("\nPreview of Sorted Records (Algorithm: " + algoName + "):");
        System.out.println("Sorting time: " + (duration / 1_000_000.0) + " ms");
        System.out.println(Student.getTabularHeader());
        for (Student s : previewList) {
            System.out.println(s.getTabularRow());
        }
        System.out.println(Student.getTabularDivider());

        System.out.print("Do you want to save this sorted order permanently? (Y/N): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        if (confirm.equals("y") || confirm.equals("yes")) {
            manager.syncFromSortedList(previewList);
            System.out.println("✔ Sorted database applied permanently.");
        } else {
            System.out.println("Sorting preview discarded. Original records order maintained.");
        }
    }

    private static void handleBinarySearchDirect() {
        ArrayList<Student> list = manager.getStudentsList();
        if (list.isEmpty()) {
            System.out.println("❌ Student directory is empty.");
            return;
        }
        int searchId = InputValidator.readInt(scanner, "Enter Student ID to binary search: ", 1, Integer.MAX_VALUE);
        Student s = SearchAlgorithms.binarySearchById(list, searchId);
        displaySearchResult(s);
    }

    private static void handleAdmissionQueueMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\n=========================================");
            System.out.println("           ADMISSION QUEUE MENU          ");
            System.out.println("=========================================");
            System.out.println(" 1. Add Student to Admission Queue (Enqueue)");
            System.out.println(" 2. Process Next Student (Dequeue to System)");
            System.out.println(" 3. View Next Student in Queue (Peek)");
            System.out.println(" 4. Display Complete Queue");
            System.out.println(" 5. Back to Main Menu");
            System.out.println("=========================================");

            int choice = InputValidator.readInt(scanner, "Enter choice: ", 1, 5);
            switch (choice) {
                case 1:
                    handleAddStudentToQueue();
                    break;
                case 2:
                    handleProcessQueueStudent();
                    break;
                case 3:
                    Student next = manager.getAdmissionQueue().peek();
                    if (next == null) {
                        System.out.println("\n❌ Admission queue is currently empty.");
                    } else {
                        System.out.println("\n✔ Next Student in Queue:");
                        System.out.println(Student.getTabularHeader());
                        System.out.println(next.getTabularRow());
                        System.out.println(Student.getTabularDivider());
                    }
                    break;
                case 4:
                    System.out.println("\n[Admission Queue Directory]");
                    manager.getAdmissionQueue().display();
                    break;
                case 5:
                    back = true;
                    break;
            }
            if (!back) {
                System.out.println("\nPress Enter to return to admission queue menu...");
                scanner.nextLine();
            }
        }
    }

    private static void handleAddStudentToQueue() {
        System.out.println("\n--- Enter Details of Applicant for Queue ---");
        int id = InputValidator.readInt(scanner, "Enter Student ID: ", 1, Integer.MAX_VALUE);
        if (manager.getStudentById(id) != null) {
            System.out.println("Warning: A student with ID " + id + " already exists in the system.");
            System.out.print("Do you want to proceed adding them to the queue anyway? (Y/N): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            if (!confirm.equals("y") && !confirm.equals("yes")) {
                return;
            }
        }

        String name = InputValidator.readValidatedString(scanner, 
                "Enter Name: ", 
                "Name cannot be empty and should contain only letters/spaces.",
                InputValidator::isValidName);

        int age = InputValidator.readInt(scanner, "Enter Age (17 - 100): ", 17, 100);

        String gender = InputValidator.readValidatedString(scanner, 
                "Enter Gender (Male/Female/Other): ", 
                "Gender must be Male, Female, or Other.",
                InputValidator::isValidGender);

        String branch = InputValidator.readValidatedString(scanner, 
                "Enter Branch (e.g. CSE, ECE): ", 
                "Branch cannot be empty.",
                InputValidator::isValidBranch);

        int year = InputValidator.readInt(scanner, "Enter Study Year (1 - 4): ", 1, 4);

        String email = InputValidator.readValidatedString(scanner, 
                "Enter Email: ", 
                "Invalid email format.",
                InputValidator::isValidEmail);

        String phone = InputValidator.readValidatedString(scanner, 
                "Enter 10-digit Phone: ", 
                "Must be 10 digits.",
                InputValidator::isValidPhone);

        double marks = InputValidator.readDouble(scanner, "Enter Marks (0.0 - 100.0): ", 0.0, 100.0);
        double attendance = InputValidator.readDouble(scanner, "Enter Attendance % (0.0 - 100.0): ", 0.0, 100.0);

        Student s = new Student(id, name, age, gender, branch, year, email, phone, marks, attendance);
        manager.getAdmissionQueue().enqueue(s);
        System.out.println("✔ Student applicant " + name + " (ID: " + id + ") successfully added to admission queue.");
    }

    private static void handleProcessQueueStudent() {
        System.out.println("\n--- Process Next Student from Admission Queue ---");
        Student next = manager.getAdmissionQueue().peek();
        if (next == null) {
            System.out.println("❌ Admission queue is empty.");
            return;
        }

        System.out.println("Reviewing applicant details:");
        System.out.println(Student.getTabularHeader());
        System.out.println(next.getTabularRow());
        System.out.println(Student.getTabularDivider());

        if (manager.getStudentById(next.getStudentId()) != null) {
            System.out.println("❌ Cannot process student: ID " + next.getStudentId() + " already exists in the system database!");
            System.out.println("1. Dequeue and discard this duplicate ID applicant");
            System.out.println("2. Keep applicant in queue and abort processing");
            int discardChoice = InputValidator.readInt(scanner, "Enter option: ", 1, 2);
            if (discardChoice == 1) {
                manager.getAdmissionQueue().dequeue();
                System.out.println("✔ Duplicate ID applicant discarded from queue.");
            }
            return;
        }

        System.out.print("Approve admission and add student to database? (Y/N): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        if (confirm.equals("y") || confirm.equals("yes")) {
            Student processed = manager.getAdmissionQueue().dequeue();
            if (processed != null) {
                if (manager.addStudent(processed)) {
                    System.out.println("✔ Student admission approved. Registered in database successfully!");
                } else {
                    System.out.println("❌ Error: ID collision occurred during registration.");
                }
            }
        } else {
            System.out.println("Admission processing deferred.");
        }
    }

    private static void handleViewRecentlyDeleted() {
        System.out.println("\n--- Recently Deleted Students (Undo Stack) ---");
        System.out.println("Stack size (available undo entries): " + manager.getUndoStack().size());
        manager.getUndoStack().display();
    }

    private static void handleSaveData() {
        System.out.println("\nSaving database...");
        try {
            manager.saveStudents(DATA_FILE);
            System.out.println("✔ Data saved successfully to " + DATA_FILE);
        } catch (IOException e) {
            System.out.println("❌ Error saving student records: " + e.getMessage());
        }
    }

    private static void handleLoadData() {
        System.out.println("\nLoading database from file...");
        try {
            manager.loadStudents(DATA_FILE);
            System.out.println("✔ Data loaded successfully from " + DATA_FILE);
            System.out.println("Total loaded students: " + manager.getStudentsList().size());
        } catch (IOException e) {
            System.out.println("❌ Error loading student records: " + e.getMessage());
        }
    }

    private static void handleExit() {
        System.out.println("\n=========================================");
        System.out.println("      Saving data before exiting...      ");
        System.out.println("=========================================");
        try {
            manager.saveStudents(DATA_FILE);
            System.out.println("✔ Data safely saved. Goodbye!");
        } catch (IOException e) {
            System.out.println("❌ Error saving data during shutdown: " + e.getMessage());
        }
        System.out.println("=========================================");
    }
}
