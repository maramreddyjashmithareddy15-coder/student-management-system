import java.util.ArrayList;
import java.util.List;

public class SearchAlgorithms {

    // Linear Search by Student ID: O(N)
    public static Student linearSearchById(List<Student> students, int targetId) {
        System.out.println("\n[Search Diagnostic]");
        System.out.println("Algorithm: Linear Search by Student ID");
        System.out.println("Time Complexity: O(n)");
        System.out.println("Space Complexity: O(1)");

        int comparisons = 0;
        for (Student student : students) {
            comparisons++;
            if (student.getStudentId() == targetId) {
                System.out.println("Comparisons executed: " + comparisons);
                return student;
            }
        }
        System.out.println("Comparisons executed: " + comparisons + " (Student not found)");
        return null;
    }

    // Linear Search by Student Name (partial/case-insensitive match): O(N)
    public static List<Student> linearSearchByName(List<Student> students, String targetName) {
        System.out.println("\n[Search Diagnostic]");
        System.out.println("Algorithm: Linear Search by Name");
        System.out.println("Time Complexity: O(n)");
        System.out.println("Space Complexity: O(k) where k is the number of matches");

        List<Student> results = new ArrayList<>();
        int comparisons = 0;
        String query = targetName.toLowerCase();
        
        for (Student student : students) {
            comparisons++;
            if (student.getName().toLowerCase().contains(query)) {
                results.add(student);
            }
        }
        System.out.println("Comparisons executed: " + comparisons);
        System.out.println("Matches found: " + results.size());
        return results;
    }

    // Linear Search by Branch: O(N)
    public static List<Student> linearSearchByBranch(List<Student> students, String branch) {
        System.out.println("\n[Search Diagnostic]");
        System.out.println("Algorithm: Linear Search by Branch");
        System.out.println("Time Complexity: O(n)");
        System.out.println("Space Complexity: O(k) where k is the number of matches");

        List<Student> results = new ArrayList<>();
        int comparisons = 0;
        String query = branch.toLowerCase();

        for (Student student : students) {
            comparisons++;
            if (student.getBranch().toLowerCase().equalsIgnoreCase(query)) {
                results.add(student);
            }
        }
        System.out.println("Comparisons executed: " + comparisons);
        System.out.println("Matches found: " + results.size());
        return results;
    }

    // Binary Search by Student ID (Recursive): O(log n)
    // Assumes the input list is pre-sorted by Student ID.
    public static Student binarySearchById(List<Student> students, int targetId) {
        System.out.println("\n[Search Diagnostic]");
        System.out.println("Algorithm: Recursive Binary Search by Student ID");
        System.out.println("Time Complexity: O(log n)");
        System.out.println("Space Complexity: O(log n) due to call stack recursion");

        // Verify if list is sorted, and if not, sort it first.
        // We will make sure the manager handles sorting or we check it here.
        boolean isSorted = true;
        for (int i = 0; i < students.size() - 1; i++) {
            if (students.get(i).getStudentId() > students.get(i + 1).getStudentId()) {
                isSorted = false;
                break;
            }
        }

        List<Student> searchList = students;
        if (!isSorted) {
            System.out.println("Note: The data was not sorted by ID. We are sorting it using Merge Sort first...");
            searchList = new ArrayList<>(students);
            SortingAlgorithms.mergeSort(searchList, "id", true); // Sort ascending
        }

        int[] comparisons = {0}; // Use array to pass by reference for tracking comparisons in recursion
        Student result = binarySearchHelper(searchList, targetId, 0, searchList.size() - 1, comparisons);
        System.out.println("Comparisons executed: " + comparisons[0]);
        return result;
    }

    private static Student binarySearchHelper(List<Student> students, int targetId, int low, int high, int[] comparisons) {
        if (low > high) {
            return null;
        }

        comparisons[0]++;
        int mid = low + (high - low) / 2;
        Student midStudent = students.get(mid);

        if (midStudent.getStudentId() == targetId) {
            return midStudent;
        } else if (midStudent.getStudentId() > targetId) {
            return binarySearchHelper(students, targetId, low, mid - 1, comparisons);
        } else {
            return binarySearchHelper(students, targetId, mid + 1, high, comparisons);
        }
    }
}
