import java.util.ArrayList;
import java.util.List;

public class SortingAlgorithms {

    // Helper comparator to compare students by attribute
    private static int compare(Student s1, Student s2, String sortBy, boolean ascending) {
        int comparison = 0;
        switch (sortBy.toLowerCase()) {
            case "id":
                comparison = Integer.compare(s1.getStudentId(), s2.getStudentId());
                break;
            case "name":
                comparison = s1.getName().compareToIgnoreCase(s2.getName());
                break;
            case "marks":
                comparison = Double.compare(s1.getMarks(), s2.getMarks());
                break;
            case "attendance":
                comparison = Double.compare(s1.getAttendance(), s2.getAttendance());
                break;
            default:
                comparison = 0;
        }
        return ascending ? comparison : -comparison;
    }

    // 1. Bubble Sort: O(n^2)
    public static void bubbleSort(List<Student> list, String sortBy, boolean ascending) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (compare(list.get(j), list.get(j + 1), sortBy, ascending) > 0) {
                    // Swap
                    Student temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                    swapped = true;
                }
            }
            if (!swapped) break; // Optimization if already sorted
        }
    }

    // 2. Selection Sort: O(n^2)
    public static void selectionSort(List<Student> list, String sortBy, boolean ascending) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (compare(list.get(j), list.get(minIdx), sortBy, ascending) < 0) {
                    minIdx = j;
                }
            }
            // Swap minIdx with i
            Student temp = list.get(minIdx);
            list.set(minIdx, list.get(i));
            list.set(i, temp);
        }
    }

    // 3. Insertion Sort: O(n^2)
    public static void insertionSort(List<Student> list, String sortBy, boolean ascending) {
        int n = list.size();
        for (int i = 1; i < n; i++) {
            Student key = list.get(i);
            int j = i - 1;
            while (j >= 0 && compare(list.get(j), key, sortBy, ascending) > 0) {
                list.set(j + 1, list.get(j));
                j = j - 1;
            }
            list.set(j + 1, key);
        }
    }

    // 4. Merge Sort: O(n log n)
    public static void mergeSort(List<Student> list, String sortBy, boolean ascending) {
        if (list.size() <= 1) return;
        mergeSortHelper(list, 0, list.size() - 1, sortBy, ascending);
    }

    private static void mergeSortHelper(List<Student> list, int l, int r, String sortBy, boolean ascending) {
        if (l < r) {
            int m = l + (r - l) / 2;
            mergeSortHelper(list, l, m, sortBy, ascending);
            mergeSortHelper(list, m + 1, r, sortBy, ascending);
            merge(list, l, m, r, sortBy, ascending);
        }
    }

    private static void merge(List<Student> list, int l, int m, int r, String sortBy, boolean ascending) {
        int n1 = m - l + 1;
        int n2 = r - m;

        List<Student> L = new ArrayList<>(n1);
        List<Student> R = new ArrayList<>(n2);

        for (int i = 0; i < n1; ++i) L.add(list.get(l + i));
        for (int j = 0; j < n2; ++j) R.add(list.get(m + 1 + j));

        int i = 0, j = 0;
        int k = l;

        while (i < n1 && j < n2) {
            if (compare(L.get(i), R.get(j), sortBy, ascending) <= 0) {
                list.set(k, L.get(i));
                i++;
            } else {
                list.set(k, R.get(j));
                j++;
            }
            k++;
        }

        while (i < n1) {
            list.set(k, L.get(i));
            i++;
            k++;
        }

        while (j < n2) {
            list.set(k, R.get(j));
            j++;
            k++;
        }
    }

    // 5. Quick Sort: O(n log n) average, O(n^2) worst case
    public static void quickSort(List<Student> list, String sortBy, boolean ascending) {
        if (list.size() <= 1) return;
        quickSortHelper(list, 0, list.size() - 1, sortBy, ascending);
    }

    private static void quickSortHelper(List<Student> list, int low, int high, String sortBy, boolean ascending) {
        if (low < high) {
            int pi = partition(list, low, high, sortBy, ascending);
            quickSortHelper(list, low, pi - 1, sortBy, ascending);
            quickSortHelper(list, pi + 1, high, sortBy, ascending);
        }
    }

    private static int partition(List<Student> list, int low, int high, String sortBy, boolean ascending) {
        Student pivot = list.get(high);
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (compare(list.get(j), pivot, sortBy, ascending) < 0) {
                i++;
                // Swap list[i] and list[j]
                Student temp = list.get(i);
                list.set(i, list.get(j));
                list.set(j, temp);
            }
        }
        // Swap list[i+1] and list[high] (pivot)
        Student temp = list.get(i + 1);
        list.set(i + 1, list.get(high));
        list.set(high, temp);

        return i + 1;
    }
}
