public class StudentStack {
    private static class Node {
        Student student;
        Node next;

        Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node top;
    private int size;

    public StudentStack() {
        this.top = null;
        this.size = 0;
    }

    // Push: O(1)
    public void push(Student student) {
        Node newNode = new Node(student);
        newNode.next = top;
        top = newNode;
        size++;
    }

    // Pop: O(1)
    public Student pop() {
        if (isEmpty()) {
            return null;
        }
        Student student = top.student;
        top = top.next;
        size--;
        return student;
    }

    // Peek: O(1)
    public Student peek() {
        if (isEmpty()) {
            return null;
        }
        return top.student;
    }

    // Check if stack is empty
    public boolean isEmpty() {
        return top == null;
    }

    // Get size
    public int size() {
        return size;
    }

    // Clear stack
    public void clear() {
        top = null;
        size = 0;
    }

    // Display stack contents (from top to bottom)
    public void display() {
        if (isEmpty()) {
            System.out.println("No recently deleted students in stack.");
            return;
        }
        System.out.println(Student.getTabularHeader());
        Node current = top;
        while (current != null) {
            System.out.println(current.student.getTabularRow());
            current = current.next;
        }
        System.out.println(Student.getTabularDivider());
    }
}
