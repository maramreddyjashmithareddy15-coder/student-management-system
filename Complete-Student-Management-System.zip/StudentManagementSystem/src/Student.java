public class Student {
    private int studentId;
    private String name;
    private int age;
    private String gender;
    private String branch;
    private int year;
    private String email;
    private String phone;
    private double marks;
    private double attendance;
    private String grade;

    // Parameterized constructor
    public Student(int studentId, String name, int age, String gender, String branch, int year, 
                   String email, String phone, double marks, double attendance) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.branch = branch;
        this.year = year;
        this.email = email;
        this.phone = phone;
        this.marks = marks;
        this.attendance = attendance;
        this.grade = calculateGrade(marks);
    }

    // Default constructor
    public Student() {
    }

    // Helper to calculate grade based on marks
    public static String calculateGrade(double marks) {
        if (marks >= 90) return "A+";
        else if (marks >= 80) return "A";
        else if (marks >= 70) return "B";
        else if (marks >= 60) return "C";
        else if (marks >= 50) return "D";
        else return "F";
    }

    // Getters and Setters
    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
        this.grade = calculateGrade(marks); // Recalculate grade when marks change
    }

    public double getAttendance() {
        return attendance;
    }

    public void setAttendance(double attendance) {
        this.attendance = attendance;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student{" +
                "ID=" + studentId +
                ", Name='" + name + '\'' +
                ", Branch='" + branch + '\'' +
                ", Grade='" + grade + '\'' +
                '}';
    }

    // Returns a tabular row formatting of the student
    public String getTabularRow() {
        return String.format("| %-8d | %-20s | %-3d | %-8s | %-10s | %-4d | %-25s | %-12s | %-6.1f | %-10.1f | %-5s |",
                studentId, name, age, gender, branch, year, email, phone, marks, attendance, grade);
    }

    // Header for tabular printing
    public static String getTabularHeader() {
        StringBuilder sb = new StringBuilder();
        sb.append("+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+\n");
        sb.append(String.format("| %-8s | %-20s | %-3s | %-8s | %-10s | %-4s | %-25s | %-12s | %-6s | %-10s | %-5s |\n",
                "ID", "Name", "Age", "Gender", "Branch", "Year", "Email Address", "Phone No", "Marks", "Attendance", "Grade"));
        sb.append("+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+");
        return sb.toString();
    }

    public static String getTabularDivider() {
        return "+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+";
    }
}
