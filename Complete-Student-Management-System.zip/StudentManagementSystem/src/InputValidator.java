import java.util.Scanner;
import java.util.regex.Pattern;

public class InputValidator {

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\d{10}$");
    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z\\s]{2,50}$");

    // Field Validators
    public static boolean isValidId(int id) {
        return id > 0;
    }

    public static boolean isValidName(String name) {
        return name != null && NAME_PATTERN.matcher(name.trim()).matches();
    }

    public static boolean isValidAge(int age) {
        return age >= 17 && age <= 100;
    }

    public static boolean isValidGender(String gender) {
        if (gender == null) return false;
        String g = gender.trim().toLowerCase();
        return g.equals("male") || g.equals("female") || g.equals("other");
    }

    public static boolean isValidBranch(String branch) {
        return branch != null && !branch.trim().isEmpty() && branch.length() <= 30;
    }

    public static boolean isValidYear(int year) {
        return year >= 1 && year <= 4;
    }

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.trim()).matches();
    }

    public static boolean isValidMarks(double marks) {
        return marks >= 0.0 && marks <= 100.0;
    }

    public static boolean isValidAttendance(double attendance) {
        return attendance >= 0.0 && attendance <= 100.0;
    }

    // Safe Console Input Wrappers
    public static int readInt(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Error: Input must be between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number format. Please enter an integer.");
            }
        }
    }

    public static double readDouble(Scanner scanner, String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Error: Input must be between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number format. Please enter a decimal number.");
            }
        }
    }

    public static String readValidatedString(Scanner scanner, String prompt, String errorMsg, ValidationCheck checker) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (checker.check(input)) {
                return input;
            }
            System.out.println("Error: " + errorMsg);
        }
    }

    // Functional interface for custom checks
    public interface ValidationCheck {
        boolean check(String value);
    }
}
