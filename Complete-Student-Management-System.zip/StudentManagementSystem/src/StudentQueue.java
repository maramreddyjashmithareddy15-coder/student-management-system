public class StudentQueue {
    private static class Node {
        Student student;
        Node next;

        Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node front;
    private Node rear;
    private int size;

    public StudentQueue() {
        this.front = null;
        this.rear = null;
        this.size = 0;
    }

    // Enqueue: O(1)
    public void enqueue(Student student) {
        Node newNode = new Node(student);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    // Dequeue: O(1)
    public Student dequeue() {
        if (isEmpty()) {
            return null;
        }
        Student student = front.student;
        front = front.next;
        if (front == null) {
            rear = null; // Queue became empty
        }
        size--;
        return student;
    }

    // Peek: O(1)
    public Student peek() {
        if (isEmpty()) {
            return null;
        }
        return front.student;
    }

    // Check if empty
    public boolean isEmpty() {
        return front == null;
    }

    // Get size
    public int size() {
        return size;
    }

    // Display the queue contents
    public void display() {
        if (isEmpty()) {
            System.out.println("The admission queue is empty.");
            return;
        }
        System.out.println(Student.getTabularHeader());
        Node current = front;
        while (current != null) {
            System.out.println(current.student.getTabularRow());
            current = current.next;
        }
        System.out.println(Student.getTabularDivider());
    }
}
