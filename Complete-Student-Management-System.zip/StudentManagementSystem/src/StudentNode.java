public class StudentNode {
    public Student data;
    public StudentNode next;
    public StudentNode prev;

    public StudentNode(Student data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
