import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TestSMS {
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("       STARTING AUTOMATED SYSTEM TEST SUITE      ");
        System.out.println("=================================================");

        testAddAndGet();
        testCustomLinkedList();
        testUndoDeleteStack();
        testAdmissionQueue();
        testSearchAlgorithms();
        testSortingAlgorithms();
        testFilePersistence();
        testStatistics();

        System.out.println("\n=================================================");
        System.out.println("       ALL TESTS EXECUTED AND VERIFIED ✔         ");
        System.out.println("=================================================");
    }

    private static void testAddAndGet() {
        System.out.print("Testing Student Add and Retrieve... ");
        StudentManager manager = new StudentManager();
        Student s1 = new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 85.5, 90.0);
        Student s2 = new Student(102, "Jane Smith", 21, "Female", "ECE", 3, "jane@email.com", "8765432109", 94.0, 95.0);

        assertCheck(manager.addStudent(s1), "S1 add failed");
        assertCheck(manager.addStudent(s2), "S2 add failed");
        assertCheck(!manager.addStudent(s1), "Duplicate ID should fail");

        Student retrieved = manager.getStudentById(101);
        assertCheck(retrieved != null && retrieved.getName().equals("John Doe"), "Retrieve ID 101 failed");
        assertCheck(retrieved.getGrade().equals("A"), "Grade should be A");

        System.out.println("PASSED");
    }

    private static void testCustomLinkedList() {
        System.out.print("Testing Custom Doubly Linked List... ");
        StudentLinkedList list = new StudentLinkedList();
        Student s1 = new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 85.5, 90.0);
        Student s2 = new Student(102, "Jane Smith", 21, "Female", "ECE", 3, "jane@email.com", "8765432109", 94.0, 95.0);

        list.insert(s1);
        list.insert(s2);
        assertCheck(list.size() == 2, "Size should be 2");

        Student found = list.search(102);
        assertCheck(found != null && found.getName().equals("Jane Smith"), "LinkedList Search failed");

        list.delete(101);
        assertCheck(list.size() == 1, "Size should be 1 after deletion");
        assertCheck(list.search(101) == null, "S1 should be deleted");

        System.out.println("PASSED");
    }

    private static void testUndoDeleteStack() {
        System.out.print("Testing Undo Delete (Stack)... ");
        StudentManager manager = new StudentManager();
        Student s1 = new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 85.5, 90.0);
        manager.addStudent(s1);

        assertCheck(manager.deleteStudent(101), "Delete failed");
        assertCheck(manager.getStudentById(101) == null, "Student should not be in manager");

        Student restored = manager.undoDelete();
        assertCheck(restored != null && restored.getStudentId() == 101, "Undo should return s1");
        assertCheck(manager.getStudentById(101) != null, "Student should be back in manager");

        System.out.println("PASSED");
    }

    private static void testAdmissionQueue() {
        System.out.print("Testing Admission Queue... ");
        StudentQueue queue = new StudentQueue();
        Student s1 = new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 85.5, 90.0);
        Student s2 = new Student(102, "Jane Smith", 21, "Female", "ECE", 3, "jane@email.com", "8765432109", 94.0, 95.0);

        assertCheck(queue.isEmpty(), "Queue should be empty");
        queue.enqueue(s1);
        queue.enqueue(s2);
        assertCheck(queue.size() == 2, "Queue size should be 2");

        Student next = queue.peek();
        assertCheck(next != null && next.getStudentId() == 101, "Peek should return front (s1)");

        Student dequeued = queue.dequeue();
        assertCheck(dequeued != null && dequeued.getStudentId() == 101, "Dequeue should return front (s1)");
        assertCheck(queue.size() == 1, "Queue size should be 1 after dequeue");

        System.out.println("PASSED");
    }

    private static void testSearchAlgorithms() {
        System.out.print("Testing Searching Algorithms... ");
        List<Student> students = new ArrayList<>();
        Student s1 = new Student(103, "Charlie", 20, "Male", "CSE", 2, "charlie@email.com", "9876543210", 85.5, 90.0);
        Student s2 = new Student(101, "Alice", 21, "Female", "ECE", 3, "alice@email.com", "8765432109", 94.0, 95.0);
        Student s3 = new Student(102, "Bob", 22, "Male", "CSE", 4, "bob@email.com", "7654321098", 65.0, 75.0);
        students.add(s1);
        students.add(s2);
        students.add(s3);

        // Linear search
        Student searchId = SearchAlgorithms.linearSearchById(students, 101);
        assertCheck(searchId != null && searchId.getName().equals("Alice"), "Linear search ID failed");

        List<Student> searchBranch = SearchAlgorithms.linearSearchByBranch(students, "CSE");
        assertCheck(searchBranch.size() == 2, "Linear search Branch CSE failed");

        // Binary search recursive (it should handle sorting automatically)
        Student searchBin = SearchAlgorithms.binarySearchById(students, 102);
        assertCheck(searchBin != null && searchBin.getName().equals("Bob"), "Binary search ID failed");

        System.out.println("PASSED");
    }

    private static void testSortingAlgorithms() {
        System.out.print("Testing Sorting Algorithms... ");
        List<Student> original = new ArrayList<>();
        original.add(new Student(103, "Charlie", 20, "Male", "CSE", 2, "c@email.com", "9876543210", 55.0, 90.0));
        original.add(new Student(101, "Alice", 21, "Female", "ECE", 3, "a@email.com", "8765432109", 95.0, 95.0));
        original.add(new Student(102, "Bob", 22, "Male", "CSE", 4, "b@email.com", "7654321098", 75.0, 75.0));

        // 1. Bubble Sort (ID Ascending)
        List<Student> list = new ArrayList<>(original);
        SortingAlgorithms.bubbleSort(list, "id", true);
        assertCheck(list.get(0).getStudentId() == 101 && list.get(2).getStudentId() == 103, "Bubble Sort ID failed");

        // 2. Selection Sort (Name Descending)
        list = new ArrayList<>(original);
        SortingAlgorithms.selectionSort(list, "name", false);
        assertCheck(list.get(0).getName().equals("Charlie") && list.get(2).getName().equals("Alice"), "Selection Sort Name failed");

        // 3. Insertion Sort (Marks Ascending)
        list = new ArrayList<>(original);
        SortingAlgorithms.insertionSort(list, "marks", true);
        assertCheck(list.get(0).getMarks() == 55.0 && list.get(2).getMarks() == 95.0, "Insertion Sort Marks failed");

        // 4. Merge Sort (Attendance Descending)
        list = new ArrayList<>(original);
        SortingAlgorithms.mergeSort(list, "attendance", false);
        assertCheck(list.get(0).getAttendance() == 95.0 && list.get(2).getAttendance() == 75.0, "Merge Sort Attendance failed");

        // 5. Quick Sort (ID Ascending)
        list = new ArrayList<>(original);
        SortingAlgorithms.quickSort(list, "id", true);
        assertCheck(list.get(0).getStudentId() == 101 && list.get(2).getStudentId() == 103, "Quick Sort ID failed");

        System.out.println("PASSED");
    }

    private static void testFilePersistence() {
        System.out.print("Testing File Loading/Saving... ");
        String testPath = "data/students_test.txt";
        StudentManager m1 = new StudentManager();
        Student s1 = new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 85.5, 90.0);
        Student s2 = new Student(102, "Jane Smith", 21, "Female", "ECE", 3, "jane@email.com", "8765432109", 94.0, 95.0);
        m1.addStudent(s1);
        m1.addStudent(s2);

        try {
            m1.saveStudents(testPath);
            StudentManager m2 = new StudentManager();
            m2.loadStudents(testPath);

            assertCheck(m2.getStudentsList().size() == 2, "Loaded size should be 2");
            assertCheck(m2.getStudentById(101).getName().equals("John Doe"), "Loaded s1 mismatch");
            assertCheck(m2.getStudentById(102).getName().equals("Jane Smith"), "Loaded s2 mismatch");

            // Clean up
            new File(testPath).delete();
        } catch (IOException e) {
            fail("IOException in File I/O: " + e.getMessage());
        }

        System.out.println("PASSED");
    }

    private static void testStatistics() {
        System.out.print("Testing Statistics Report... ");
        StudentManager manager = new StudentManager();
        manager.addStudent(new Student(101, "John Doe", 20, "Male", "CSE", 2, "john@email.com", "9876543210", 40.0, 90.0)); // Fail
        manager.addStudent(new Student(102, "Jane Smith", 21, "Female", "ECE", 3, "jane@email.com", "8765432109", 90.0, 95.0)); // Pass
        manager.addStudent(new Student(103, "Bob", 22, "Male", "CSE", 4, "bob@email.com", "7654321098", 60.0, 85.0)); // Pass

        // Simply print statistics to verify no crash and correct counts
        System.out.println("\n--- Stats Verification Printout ---");
        manager.displayStatistics();
        System.out.println("-----------------------------------");
    }

    private static void assertCheck(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError("Test Assertion Failed: " + message);
        }
    }

    private static void fail(String message) {
        throw new AssertionError("Test Failed: " + message);
    }
}
