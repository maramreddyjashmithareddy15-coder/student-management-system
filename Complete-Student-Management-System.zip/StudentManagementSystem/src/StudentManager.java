import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class StudentManager {
    private ArrayList<Student> studentsList;
    private HashMap<Integer, Student> studentsMap;
    private StudentLinkedList customLinkedList;
    private StudentStack undoStack;
    private StudentQueue admissionQueue;

    public StudentManager() {
        this.studentsList = new ArrayList<>();
        this.studentsMap = new HashMap<>();
        this.customLinkedList = new StudentLinkedList();
        this.undoStack = new StudentStack();
        this.admissionQueue = new StudentQueue();
    }

    // Add Student: O(1) average (due to HashMap put and list insertion)
    public boolean addStudent(Student student) {
        if (studentsMap.containsKey(student.getStudentId())) {
            return false; // ID already exists
        }
        studentsList.add(student);
        studentsMap.put(student.getStudentId(), student);
        customLinkedList.insert(student);
        return true;
    }

    // Get Student by ID using HashMap: O(1) average lookup
    public Student getStudentById(int id) {
        return studentsMap.get(id);
    }

    // Delete Student: O(N) due to ArrayList and CustomLinkedList deletion
    public boolean deleteStudent(int studentId) {
        Student student = getStudentById(studentId);
        if (student == null) {
            return false;
        }
        // Remove from list, map, custom linked list
        studentsList.remove(student);
        studentsMap.remove(studentId);
        customLinkedList.delete(studentId);
        // Push to undo stack
        undoStack.push(student);
        return true;
    }

    // Undo delete: O(1) pop and add
    public Student undoDelete() {
        if (undoStack.isEmpty()) {
            return null;
        }
        Student student = undoStack.pop();
        addStudent(student);
        return student;
    }

    // Update Student: O(N) due to synchronization across list and custom list
    public boolean updateStudent(int id, String name, String email, String phone, String branch, double marks, double attendance) {
        Student student = getStudentById(id);
        if (student == null) {
            return false;
        }
        student.setName(name);
        student.setEmail(email);
        student.setPhone(phone);
        student.setBranch(branch);
        student.setMarks(marks);
        student.setAttendance(attendance);

        // Custom LinkedList syncs because it modifies the same object references,
        // but let's make sure it updates in custom list explicitly as well.
        customLinkedList.update(id, student);
        return true;
    }

    // Accessors for various data structures
    public ArrayList<Student> getStudentsList() {
        return studentsList;
    }

    public StudentLinkedList getCustomLinkedList() {
        return customLinkedList;
    }

    public StudentStack getUndoStack() {
        return undoStack;
    }

    public StudentQueue getAdmissionQueue() {
        return admissionQueue;
    }

    // Rebuild structures from Main list (useful after sorting)
    public void syncFromSortedList(ArrayList<Student> sortedList) {
        this.studentsList = new ArrayList<>(sortedList);
        customLinkedList.rebuildFromList(this.studentsList);
        studentsMap.clear();
        for (Student s : this.studentsList) {
            studentsMap.put(s.getStudentId(), s);
        }
    }

    // File Handling: Save Students to data/students.txt
    public void saveStudents(String filePath) throws IOException {
        File file = new File(filePath);
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            // Write CSV Header
            writer.write("studentId,name,age,gender,branch,year,email,phone,marks,attendance,grade");
            writer.newLine();
            for (Student student : studentsList) {
                String line = String.format("%d,%s,%d,%s,%s,%d,%s,%s,%.2f,%.2f,%s",
                        student.getStudentId(),
                        escapeCsvField(student.getName()),
                        student.getAge(),
                        escapeCsvField(student.getGender()),
                        escapeCsvField(student.getBranch()),
                        student.getYear(),
                        escapeCsvField(student.getEmail()),
                        escapeCsvField(student.getPhone()),
                        student.getMarks(),
                        student.getAttendance(),
                        student.getGrade());
                writer.write(line);
                writer.newLine();
            }
        }
    }

    // File Handling: Load Students from data/students.txt
    public void loadStudents(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            return; // Nothing to load
        }

        // Clear existing data before loading
        studentsList.clear();
        studentsMap.clear();
        customLinkedList = new StudentLinkedList();

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String header = reader.readLine(); // Read CSV header
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.split(",");
                if (parts.length >= 11) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        String name = unescapeCsvField(parts[1]);
                        int age = Integer.parseInt(parts[2]);
                        String gender = unescapeCsvField(parts[3]);
                        String branch = unescapeCsvField(parts[4]);
                        int year = Integer.parseInt(parts[5]);
                        String email = unescapeCsvField(parts[6]);
                        String phone = unescapeCsvField(parts[7]);
                        double marks = Double.parseDouble(parts[8]);
                        double attendance = Double.parseDouble(parts[9]);

                        Student student = new Student(id, name, age, gender, branch, year, email, phone, marks, attendance);
                        addStudent(student);
                    } catch (NumberFormatException e) {
                        System.err.println("Warning: Skipping invalid line (corrupt fields): " + line);
                    }
                }
            }
        }
    }

    private String escapeCsvField(String field) {
        if (field == null) return "";
        return field.replace(",", "\\,");
    }

    private String unescapeCsvField(String field) {
        if (field == null) return "";
        return field.replace("\\,", ",");
    }

    // Statistics Generation
    public void displayStatistics() {
        if (studentsList.isEmpty()) {
            System.out.println("\n+---------------------------------------------------+");
            System.out.println("|             STUDENT STATISTICS REPORT             |");
            System.out.println("+---------------------------------------------------+");
            System.out.println("| No student records available to analyze.         |");
            System.out.println("+---------------------------------------------------+");
            return;
        }

        int total = studentsList.size();
        double sumMarks = 0;
        double highestMarks = Double.MIN_VALUE;
        double lowestMarks = Double.MAX_VALUE;
        double sumAttendance = 0;
        int passedCount = 0;
        int failedCount = 0;

        Map<String, Integer> branchCounts = new HashMap<>();
        Map<String, Integer> gradeCounts = new HashMap<>();

        for (Student s : studentsList) {
            sumMarks += s.getMarks();
            sumAttendance += s.getAttendance();

            if (s.getMarks() > highestMarks) highestMarks = s.getMarks();
            if (s.getMarks() < lowestMarks) lowestMarks = s.getMarks();

            if (s.getMarks() >= 50.0) {
                passedCount++;
            } else {
                failedCount++;
            }

            // Branch tally
            String branch = s.getBranch().toUpperCase();
            branchCounts.put(branch, branchCounts.getOrDefault(branch, 0) + 1);

            // Grade tally
            String grade = s.getGrade();
            gradeCounts.put(grade, gradeCounts.getOrDefault(grade, 0) + 1);
        }

        double avgMarks = sumMarks / total;
        double avgAttendance = sumAttendance / total;

        System.out.println("\n==========================================================");
        System.out.println("                STUDENT STATISTICS REPORT                 ");
        System.out.println("==========================================================");
        System.out.printf("  Total Students Registered : %d\n", total);
        System.out.printf("  Average Academic Marks     : %.2f / 100.0\n", avgMarks);
        System.out.printf("  Highest Marks Achieved     : %.2f\n", highestMarks);
        System.out.printf("  Lowest Marks Recorded      : %.2f\n", lowestMarks);
        System.out.printf("  Average Class Attendance   : %.2f%%\n", avgAttendance);
        System.out.printf("  Passing Students (>= 50.0) : %d (%.1f%%)\n", passedCount, ((double)passedCount / total) * 100);
        System.out.printf("  Failing Students (< 50.0)  : %d (%.1f%%)\n", failedCount, ((double)failedCount / total) * 100);

        System.out.println("\n  Branch-wise Student Distribution:");
        System.out.println("  ---------------------------------");
        for (Map.Entry<String, Integer> entry : branchCounts.entrySet()) {
            System.out.printf("    %-15s : %d students\n", entry.getKey(), entry.getValue());
        }

        System.out.println("\n  Grade Distribution:");
        System.out.println("  -------------------");
        String[] grades = {"A+", "A", "B", "C", "D", "F"};
        for (String g : grades) {
            int count = gradeCounts.getOrDefault(g, 0);
            System.out.printf("    %-3s : %d students\n", g, count);
        }
        System.out.println("==========================================================");
    }
}
