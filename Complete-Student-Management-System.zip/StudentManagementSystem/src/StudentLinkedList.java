import java.util.ArrayList;

public class StudentLinkedList {
    private StudentNode head;
    private StudentNode tail;
    private int size;

    public StudentLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    // Insert at tail: O(1)
    public void insert(Student student) {
        StudentNode newNode = new StudentNode(student);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    // Delete student by ID: O(N)
    public boolean delete(int studentId) {
        StudentNode current = head;
        while (current != null) {
            if (current.data.getStudentId() == studentId) {
                // If it is the head node
                if (current == head) {
                    head = head.next;
                    if (head != null) {
                        head.prev = null;
                    } else {
                        tail = null; // List became empty
                    }
                }
                // If it is the tail node
                else if (current == tail) {
                    tail = tail.prev;
                    if (tail != null) {
                        tail.next = null;
                    } else {
                        head = null; // List became empty
                    }
                }
                // Middle node
                else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                size--;
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Search student by ID: O(N)
    public Student search(int studentId) {
        StudentNode current = head;
        while (current != null) {
            if (current.data.getStudentId() == studentId) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    // Update student details: O(N)
    public boolean update(int studentId, Student updated) {
        Student student = search(studentId);
        if (student != null) {
            student.setName(updated.getName());
            student.setAge(updated.getAge());
            student.setGender(updated.getGender());
            student.setBranch(updated.getBranch());
            student.setYear(updated.getYear());
            student.setEmail(updated.getEmail());
            student.setPhone(updated.getPhone());
            student.setMarks(updated.getMarks());
            student.setAttendance(updated.getAttendance());
            return true;
        }
        return false;
    }

    // Get size of list
    public int size() {
        return size;
    }

    // Check if list is empty
    public boolean isEmpty() {
        return head == null;
    }

    // Display list contents in tabular format
    public void display() {
        if (isEmpty()) {
            System.out.println("The list is empty.");
            return;
        }
        System.out.println(Student.getTabularHeader());
        StudentNode current = head;
        while (current != null) {
            System.out.println(current.data.getTabularRow());
            current = current.next;
        }
        System.out.println(Student.getTabularDivider());
    }

    // Helper to convert Custom Linked List to standard ArrayList
    public ArrayList<Student> toArrayList() {
        ArrayList<Student> list = new ArrayList<>();
        StudentNode current = head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }
        return list;
    }

    // Helper to rebuild list from ArrayList (for sync or sorting results)
    public void rebuildFromList(ArrayList<Student> list) {
        this.head = null;
        this.tail = null;
        this.size = 0;
        for (Student s : list) {
            insert(s);
        }
    }
}
