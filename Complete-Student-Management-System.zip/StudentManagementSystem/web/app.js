// ==========================================
// 🧠 CUSTOM DATA MODELS & STRUCTURES
// ==========================================

class Student {
    constructor(id, name, age, gender, branch, year, email, phone, marks, attendance) {
        this.studentId = parseInt(id);
        this.name = name;
        this.age = parseInt(age);
        this.gender = gender;
        this.branch = branch;
        this.year = parseInt(year);
        this.email = email;
        this.phone = phone;
        this.marks = parseFloat(marks);
        this.attendance = parseFloat(attendance);
        this.grade = Student.calculateGrade(this.marks);
    }

    static calculateGrade(marks) {
        if (marks >= 90) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        if (marks >= 50) return "D";
        return "F";
    }
}

class StudentNode {
    constructor(student) {
        this.data = student;
        this.next = null;
        this.prev = null;
    }
}

class StudentLinkedList {
    constructor() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    insert(student) {
        const newNode = new StudentNode(student);
        if (!this.head) {
            this.head = newNode;
            this.tail = newNode;
        } else {
            this.tail.next = newNode;
            newNode.prev = this.tail;
            this.tail = newNode;
        }
        this.size++;
    }

    delete(studentId) {
        let current = this.head;
        while (current) {
            if (current.data.studentId === studentId) {
                if (current === this.head) {
                    this.head = this.head.next;
                    if (this.head) this.head.prev = null;
                    else this.tail = null;
                } else if (current === this.tail) {
                    this.tail = this.tail.prev;
                    if (this.tail) this.tail.next = null;
                    else this.head = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                this.size--;
                return current.data;
            }
            current = current.next;
        }
        return null;
    }

    search(studentId) {
        let current = this.head;
        while (current) {
            if (current.data.studentId === studentId) return current.data;
            current = current.next;
        }
        return null;
    }

    update(studentId, updatedData) {
        let student = this.search(studentId);
        if (student) {
            student.name = updatedData.name;
            student.age = parseInt(updatedData.age);
            student.gender = updatedData.gender;
            student.branch = updatedData.branch;
            student.year = parseInt(updatedData.year);
            student.email = updatedData.email;
            student.phone = updatedData.phone;
            student.marks = parseFloat(updatedData.marks);
            student.attendance = parseFloat(updatedData.attendance);
            student.grade = Student.calculateGrade(student.marks);
            return true;
        }
        return false;
    }

    toArray() {
        const arr = [];
        let current = this.head;
        while (current) {
            arr.push(current.data);
            current = current.next;
        }
        return arr;
    }

    clear() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }
}

class StudentStack {
    constructor() {
        this.items = [];
    }

    push(student) {
        this.items.push({
            student: student,
            deletedAt: new Date().toLocaleTimeString()
        });
    }

    pop() {
        return this.items.pop();
    }

    peek() {
        return this.items[this.items.length - 1];
    }

    isEmpty() {
        return this.items.length === 0;
    }

    size() {
        return this.items.length;
    }
}

class StudentQueue {
    constructor() {
        this.items = [];
    }

    enqueue(student) {
        this.items.push(student);
    }

    dequeue() {
        if (this.isEmpty()) return null;
        return this.items.shift();
    }

    peek() {
        if (this.isEmpty()) return null;
        return this.items[0];
    }

    isEmpty() {
        return this.items.length === 0;
    }

    size() {
        return this.items.length;
    }
}

// ==========================================
// ⚡ ALGORITHMS IMPLEMENTATION
// ==========================================

const SortingAlgorithms = {
    compare(s1, s2, sortBy, ascending) {
        let comparison = 0;
        if (sortBy === 'id') {
            comparison = s1.studentId - s2.studentId;
        } else if (sortBy === 'name') {
            comparison = s1.name.localeCompare(s2.name);
        } else if (sortBy === 'marks') {
            comparison = s1.marks - s2.marks;
        } else if (sortBy === 'attendance') {
            comparison = s1.attendance - s2.attendance;
        }
        return ascending ? comparison : -comparison;
    },

    // Bubble Sort: O(n²)
    bubbleSort(arr, sortBy, ascending, tracker) {
        const n = arr.length;
        for (let i = 0; i < n - 1; i++) {
            let swapped = false;
            for (let j = 0; j < n - i - 1; j++) {
                tracker.comparisons++;
                if (this.compare(arr[j], arr[j + 1], sortBy, ascending) > 0) {
                    const temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    },

    // Selection Sort: O(n²)
    selectionSort(arr, sortBy, ascending, tracker) {
        const n = arr.length;
        for (let i = 0; i < n - 1; i++) {
            let minIdx = i;
            for (let j = i + 1; j < n; j++) {
                tracker.comparisons++;
                if (this.compare(arr[j], arr[minIdx], sortBy, ascending) < 0) {
                    minIdx = j;
                }
            }
            const temp = arr[minIdx];
            arr[minIdx] = arr[i];
            arr[i] = temp;
        }
    },

    // Insertion Sort: O(n²)
    insertionSort(arr, sortBy, ascending, tracker) {
        const n = arr.length;
        for (let i = 1; i < n; i++) {
            const key = arr[i];
            let j = i - 1;
            while (j >= 0) {
                tracker.comparisons++;
                if (this.compare(arr[j], key, sortBy, ascending) > 0) {
                    arr[j + 1] = arr[j];
                    j--;
                } else {
                    break;
                }
            }
            arr[j + 1] = key;
        }
    },

    // Merge Sort: O(n log n)
    mergeSort(arr, sortBy, ascending, tracker) {
        if (arr.length <= 1) return arr;
        this.mergeSortHelper(arr, 0, arr.length - 1, sortBy, ascending, tracker);
    },

    mergeSortHelper(arr, l, r, sortBy, ascending, tracker) {
        if (l < r) {
            const m = Math.floor(l + (r - l) / 2);
            this.mergeSortHelper(arr, l, m, sortBy, ascending, tracker);
            this.mergeSortHelper(arr, m + 1, r, sortBy, ascending, tracker);
            this.merge(arr, l, m, r, sortBy, ascending, tracker);
        }
    },

    merge(arr, l, m, r, sortBy, ascending, tracker) {
        const n1 = m - l + 1;
        const n2 = r - m;
        const L = arr.slice(l, m + 1);
        const R = arr.slice(m + 1, r + 1);

        let i = 0, j = 0, k = l;
        while (i < n1 && j < n2) {
            tracker.comparisons++;
            if (this.compare(L[i], R[j], sortBy, ascending) <= 0) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++; k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++; k++;
        }
    },

    // Quick Sort: O(n log n)
    quickSort(arr, sortBy, ascending, tracker) {
        if (arr.length <= 1) return;
        this.quickSortHelper(arr, 0, arr.length - 1, sortBy, ascending, tracker);
    },

    quickSortHelper(arr, low, high, sortBy, ascending, tracker) {
        if (low < high) {
            const pi = this.partition(arr, low, high, sortBy, ascending, tracker);
            this.quickSortHelper(arr, low, pi - 1, sortBy, ascending, tracker);
            this.quickSortHelper(arr, pi + 1, high, sortBy, ascending, tracker);
        }
    },

    partition(arr, low, high, sortBy, ascending, tracker) {
        const pivot = arr[high];
        let i = low - 1;
        for (let j = low; j < high; j++) {
            tracker.comparisons++;
            if (this.compare(arr[j], pivot, sortBy, ascending) < 0) {
                i++;
                const temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        const temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
};

const SearchAlgorithms = {
    // Linear Search: O(n)
    linearSearch(arr, query, field, tracker) {
        const results = [];
        const q = query.toLowerCase().trim();
        for (const student of arr) {
            tracker.comparisons++;
            if (field === 'id') {
                if (student.studentId.toString() === q) results.push(student);
            } else if (field === 'name') {
                if (student.name.toLowerCase().includes(q)) results.push(student);
            } else if (field === 'branch') {
                if (student.branch.toLowerCase() === q) results.push(student);
            }
        }
        return results;
    },

    // Recursive Binary Search: O(log n)
    // Automatically sorts the search scope ascending by ID
    binarySearch(arr, targetId, tracker) {
        const sorted = [...arr];
        // Sort it using Merge Sort first if it isn't sorted
        let isSorted = true;
        for (let i = 0; i < sorted.length - 1; i++) {
            if (sorted[i].studentId > sorted[i + 1].studentId) {
                isSorted = false;
                break;
            }
        }
        if (!isSorted) {
            SortingAlgorithms.mergeSort(sorted, 'id', true, { comparisons: 0 });
        }

        const index = this.binarySearchHelper(sorted, parseInt(targetId), 0, sorted.length - 1, tracker);
        return index !== -1 ? [sorted[index]] : [];
    },

    binarySearchHelper(arr, target, low, high, tracker) {
        if (low > high) return -1;
        tracker.comparisons++;
        const mid = Math.floor(low + (high - low) / 2);
        if (arr[mid].studentId === target) return mid;
        if (arr[mid].studentId > target) return this.binarySearchHelper(arr, target, low, mid - 1, tracker);
        return this.binarySearchHelper(arr, target, mid + 1, high, tracker);
    }
};

// ==========================================
// 🖥️ UI CONTROLLER & APP STATE
// ==========================================

// Global Structures
const database = new StudentLinkedList();
const undoHistory = new StudentStack();
const admissionQueue = new StudentQueue();

// UI Configuration state
let currentSortDirection = true; // true = Ascending
let searchFilterActive = false;
let activeSearchQuery = "";
let activeSearchField = "id";

// Page Initialization
window.onload = function() {
    loadFromLocalStorage();
    switchSection('dashboard');
    updateGlobalMetrics();
    renderDatabaseTable();
    renderQueueTable();
    renderStackTable();
    renderCharts();
};

function switchSection(sectionId) {
    // Toggle active navigation buttons
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.getElementById(`nav-${sectionId}`).classList.add('active');

    // Toggle active section components
    document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active-section'));
    document.getElementById(`sec-${sectionId}`).classList.add('active-section');
}

// Toggle light-dark theme mode
function toggleTheme() {
    const isLight = document.body.classList.toggle('light-theme');
    const icon = document.getElementById('theme-icon');
    if (isLight) {
        icon.className = 'fa-solid fa-sun';
    } else {
        icon.className = 'fa-solid fa-moon';
    }
}

// Modal open/close actions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
    // Clear forms inside modal
    const form = document.querySelector(`#${modalId} form`);
    if (form) form.reset();
}

// Toast alerts notifications
function showToast(title, message, type = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconClass = 'fa-circle-check';
    if (type === 'error') iconClass = 'fa-circle-xmark';
    if (type === 'warning') iconClass = 'fa-triangle-exclamation';

    toast.innerHTML = `
        <div class="toast-icon"><i class="fa-solid ${iconClass}"></i></div>
        <div class="toast-content">
            <h5>${title}</h5>
            <p>${message}</p>
        </div>
    `;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease-out reverse forwards';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Seed sample student profiles
function seedSampleData() {
    const samples = [
        new Student(1001, "Alice Smith", 19, "Female", "CSE", 2, "alice@email.com", "9876543210", 94.5, 92.0),
        new Student(1002, "Bob Johnson", 21, "Male", "ME", 3, "bob@email.com", "8765432109", 72.0, 85.0),
        new Student(1003, "Charlie Davis", 20, "Male", "CSE", 1, "charlie@email.com", "7654321098", 48.0, 78.0),
        new Student(1004, "Diana Prince", 22, "Female", "ECE", 4, "diana@email.com", "6543210987", 89.5, 96.5),
        new Student(1005, "Ethan Hunt", 20, "Male", "ECE", 2, "ethan@email.com", "5432109876", 62.0, 88.0)
    ];

    database.clear();
    samples.forEach(s => database.insert(s));
    
    // Add 2 to the queue
    admissionQueue.items = [];
    admissionQueue.enqueue(new Student(1006, "Fiona Carter", 19, "Female", "CSE", 1, "fiona@email.com", "4321098765", 81.0, 95.0));
    admissionQueue.enqueue(new Student(1007, "George Stark", 20, "Male", "ME", 2, "george@email.com", "3210987654", 51.5, 80.0));

    saveToLocalStorage();
    updateUI();
    showToast("Database Seeded", "Successfully loaded 5 student records and 2 queue applicants.", "success");
}

// Update UI elements
function updateUI() {
    updateGlobalMetrics();
    renderDatabaseTable();
    renderQueueTable();
    renderStackTable();
    renderCharts();
}

// Metrics calculators
function updateGlobalMetrics() {
    const arr = database.toArray();
    const total = arr.length;
    
    document.getElementById('stat-total').innerText = total;
    
    if (total === 0) {
        document.getElementById('stat-avg-marks').innerText = "0.0";
        document.getElementById('stat-avg-att').innerText = "0.0%";
        document.getElementById('stat-pass-rate').innerText = "0.0%";
        return;
    }

    const totalMarks = arr.reduce((sum, s) => sum + s.marks, 0);
    const totalAtt = arr.reduce((sum, s) => sum + s.attendance, 0);
    const passedCount = arr.filter(s => s.marks >= 50.0).length;

    document.getElementById('stat-avg-marks').innerText = (totalMarks / total).toFixed(1);
    document.getElementById('stat-avg-att').innerText = (totalAtt / total).toFixed(1) + "%";
    document.getElementById('stat-pass-rate').innerText = ((passedCount / total) * 100).toFixed(1) + "%";

    // Update SideBar navigation badges count
    document.getElementById('queue-badge').innerText = admissionQueue.size();
    document.getElementById('stack-badge').innerText = undoHistory.size();
    document.getElementById('queue-size-text').innerText = `${admissionQueue.size()} applicant${admissionQueue.size() === 1 ? '' : 's'}`;
    document.getElementById('stack-count-text').innerText = `${undoHistory.size()} Deleted Record${undoHistory.size() === 1 ? '' : 's'}`;
}

// Charts SVG rendering
function renderCharts() {
    const arr = database.toArray();
    const gradeChart = document.getElementById('grade-chart');
    const branchChart = document.getElementById('branch-chart');

    if (arr.length === 0) {
        gradeChart.innerHTML = `<p class="empty-state-text">No data to display. Add students first.</p>`;
        branchChart.innerHTML = `<p class="empty-state-text">No data to display. Add students first.</p>`;
        return;
    }

    // 1. Grade Tally
    const grades = {"A+": 0, "A": 0, "B": 0, "C": 0, "D": 0, "F": 0};
    arr.forEach(s => {
        if (grades[s.grade] !== undefined) grades[s.grade]++;
    });

    let gradeHtml = "";
    const maxGradeCount = Math.max(...Object.values(grades), 1);
    for (const [g, count] of Object.entries(grades)) {
        const pct = (count / maxGradeCount) * 100;
        gradeHtml += `
            <div class="chart-bar-wrapper">
                <div class="chart-bar" style="height: ${Math.max(pct, 5)}%">
                    ${count > 0 ? `<span class="chart-bar-val">${count}</span>` : ''}
                </div>
                <span class="chart-bar-label">${g}</span>
            </div>
        `;
    }
    gradeChart.innerHTML = gradeHtml;

    // 2. Branch Tally
    const branches = {};
    arr.forEach(s => {
        const b = s.branch.toUpperCase();
        branches[b] = (branches[b] || 0) + 1;
    });

    let branchHtml = "";
    const maxBranchCount = Math.max(...Object.values(branches), 1);
    for (const [b, count] of Object.entries(branches)) {
        const pct = (count / maxBranchCount) * 100;
        branchHtml += `
            <div class="chart-bar-wrapper">
                <div class="chart-bar" style="height: ${Math.max(pct, 5)}%; background: linear-gradient(to top, var(--color-cyan), var(--color-green));">
                    ${count > 0 ? `<span class="chart-bar-val">${count}</span>` : ''}
                </div>
                <span class="chart-bar-label">${b}</span>
            </div>
        `;
    }
    branchChart.innerHTML = branchHtml;
}

// Student Data Table renderer
function renderDatabaseTable() {
    const tbody = document.getElementById('student-table-body');
    tbody.innerHTML = "";
    
    let arr = database.toArray();

    // If search filter is active
    if (searchFilterActive && activeSearchQuery !== "") {
        const tracker = { comparisons: 0 };
        const startTime = performance.now();
        
        let results = [];
        if (document.getElementById('db-search-binary').checked && activeSearchField === 'id') {
            results = SearchAlgorithms.binarySearch(arr, activeSearchQuery, tracker);
        } else {
            results = SearchAlgorithms.linearSearch(arr, activeSearchQuery, activeSearchField, tracker);
        }
        
        const duration = (performance.now() - startTime).toFixed(3);
        showBenchmark(
            document.getElementById('db-search-binary').checked && activeSearchField === 'id' ? "Binary Search (Recursive)" : "Linear Search", 
            tracker.comparisons, 
            duration, 
            document.getElementById('db-search-binary').checked && activeSearchField === 'id' ? "O(log n)" : "O(n)"
        );
        arr = results;
    }

    if (arr.length === 0) {
        tbody.innerHTML = `<tr><td colspan="12" style="text-align: center; color: var(--text-muted);">No student records match the filters.</td></tr>`;
        return;
    }

    arr.forEach(s => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>#${s.studentId}</strong></td>
            <td>${s.name}</td>
            <td>${s.age}</td>
            <td>${s.gender}</td>
            <td><span class="pill pill-cyan">${s.branch}</span></td>
            <td>Yr ${s.year}</td>
            <td>${s.email}</td>
            <td>${s.phone}</td>
            <td>${s.marks.toFixed(1)}</td>
            <td>${s.attendance.toFixed(1)}%</td>
            <td><span class="pill ${s.marks >= 50 ? 'pill-green' : 'pill-red'}">${s.grade}</span></td>
            <td>
                <div class="row-actions">
                    <button class="row-btn edit" onclick="editStudent(${s.studentId})" title="Edit Details"><i class="fa-solid fa-pen"></i></button>
                    <button class="row-btn delete" onclick="deleteStudent(${s.studentId})" title="Delete Record"><i class="fa-solid fa-trash-can"></i></button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Queue Table renderer
function renderQueueTable() {
    const tbody = document.getElementById('queue-table-body');
    tbody.innerHTML = "";
    const items = admissionQueue.items;

    if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="13" style="text-align: center; color: var(--text-muted);">The admission pipeline is empty.</td></tr>`;
        return;
    }

    items.forEach((s, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${idx + 1}</strong></td>
            <td>#${s.studentId}</td>
            <td>${s.name}</td>
            <td>${s.age}</td>
            <td>${s.gender}</td>
            <td><span class="pill pill-cyan">${s.branch}</span></td>
            <td>Yr ${s.year}</td>
            <td>${s.email}</td>
            <td>${s.phone}</td>
            <td>${s.marks.toFixed(1)}</td>
            <td>${s.attendance.toFixed(1)}%</td>
            <td><span class="pill pill-cyan">${s.grade}</span></td>
            <td><span class="pill pill-amber">Waiting Approval</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// Undo Stack Table renderer
function renderStackTable() {
    const tbody = document.getElementById('stack-table-body');
    tbody.innerHTML = "";
    
    // Display elements from top of stack to bottom
    const items = [...undoHistory.items].reverse();

    if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="13" style="text-align: center; color: var(--text-muted);">No recently deleted student logs.</td></tr>`;
        return;
    }

    items.forEach((entry, idx) => {
        const s = entry.student;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>Top-${idx + 1}</strong></td>
            <td>#${s.studentId}</td>
            <td>${s.name}</td>
            <td>${s.age}</td>
            <td>${s.gender}</td>
            <td><span class="pill pill-cyan">${s.branch}</span></td>
            <td>Yr ${s.year}</td>
            <td>${s.email}</td>
            <td>${s.phone}</td>
            <td>${s.marks.toFixed(1)}</td>
            <td>${s.attendance.toFixed(1)}%</td>
            <td><span class="pill pill-red">${s.grade}</span></td>
            <td><span class="pill pill-red">${entry.deletedAt}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// Handle real-time searching inputs
function handleSearch() {
    const input = document.getElementById('db-search-input').value;
    const field = document.getElementById('db-search-field').value;
    
    if (input === "") {
        searchFilterActive = false;
        hideDiagPanel();
    } else {
        searchFilterActive = true;
        activeSearchQuery = input;
        activeSearchField = field;
    }
    renderDatabaseTable();
}

// Sorting Direction Toggle
function setSortDirection(asc) {
    currentSortDirection = asc;
    document.getElementById('sort-asc').classList.toggle('active', asc);
    document.getElementById('sort-desc').classList.toggle('active', !asc);
}

// Benchmark Display controller
function showBenchmark(algoName, comparisons, time, complexity) {
    document.getElementById('diag-algo-name').innerText = algoName;
    document.getElementById('diag-comparisons').innerText = comparisons;
    document.getElementById('diag-time').innerText = `${time} ms`;
    document.getElementById('diag-complexity').innerText = complexity;
    document.getElementById('algo-diag-panel').classList.remove('hidden');
}

function hideDiagPanel() {
    document.getElementById('algo-diag-panel').classList.add('hidden');
}

// Execute Sort Algorithms
function executeSort() {
    const key = document.getElementById('db-sort-key').value;
    const algo = document.getElementById('db-sort-algo').value;

    const arr = database.toArray();
    if (arr.length === 0) {
        showToast("Sorting Aborted", "Cannot sort an empty database.", "warning");
        return;
    }

    const tracker = { comparisons: 0 };
    const startTime = performance.now();

    let complexityText = "";
    let algoText = "";

    if (algo === 'bubble') {
        SortingAlgorithms.bubbleSort(arr, key, currentSortDirection, tracker);
        algoText = "Bubble Sort";
        complexityText = "O(n²)";
    } else if (algo === 'selection') {
        SortingAlgorithms.selectionSort(arr, key, currentSortDirection, tracker);
        algoText = "Selection Sort";
        complexityText = "O(n²)";
    } else if (algo === 'insertion') {
        SortingAlgorithms.insertionSort(arr, key, currentSortDirection, tracker);
        algoText = "Insertion Sort";
        complexityText = "O(n²)";
    } else if (algo === 'merge') {
        SortingAlgorithms.mergeSort(arr, key, currentSortDirection, tracker);
        algoText = "Merge Sort (Recursive)";
        complexityText = "O(n log n)";
    } else if (algo === 'quick') {
        SortingAlgorithms.quickSort(arr, key, currentSortDirection, tracker);
        algoText = "Quick Sort (Recursive)";
        complexityText = "O(n log n) avg";
    }

    const duration = (performance.now() - startTime).toFixed(3);
    
    // Apply changes in-place to doubly linked list
    database.clear();
    arr.forEach(s => database.insert(s));

    saveToLocalStorage();
    updateUI();
    showBenchmark(algoText, tracker.comparisons, duration, complexityText);
    showToast("Sorting Completed", `Successfully sorted database using ${algoText}.`, "success");
}

// Add Student submit triggers
function submitAddStudent(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById('add-id').value);
    
    if (database.search(id) !== null) {
        showToast("Insertion Error", `Student ID #${id} already exists in records.`, "error");
        return;
    }

    const student = new Student(
        id,
        document.getElementById('add-name').value,
        document.getElementById('add-age').value,
        document.getElementById('add-gender').value,
        document.getElementById('add-branch').value,
        document.getElementById('add-year').value,
        document.getElementById('add-email').value,
        document.getElementById('add-phone').value,
        document.getElementById('add-marks').value,
        document.getElementById('add-att').value
    );

    database.insert(student);
    saveToLocalStorage();
    updateUI();
    closeModal('add-student-modal');
    showToast("Student Added", `Successfully registered ${student.name} in database.`, "success");
}

// Delete student records
function deleteStudent(id) {
    if (confirm(`Are you sure you want to delete student #${id}?`)) {
        const deleted = database.delete(id);
        if (deleted) {
            undoHistory.push(deleted);
            saveToLocalStorage();
            updateUI();
            showToast("Student Deleted", `Record for student #${id} moved to Undo Stack.`, "warning");
        }
    }
}

// Edit Student trigger
function editStudent(id) {
    const student = database.search(id);
    if (!student) return;

    document.getElementById('edit-id').value = student.studentId;
    document.getElementById('edit-id-display').value = student.studentId;
    document.getElementById('edit-name').value = student.name;
    document.getElementById('edit-age').value = student.age;
    document.getElementById('edit-gender').value = student.gender;
    document.getElementById('edit-branch').value = student.branch;
    document.getElementById('edit-year').value = student.year;
    document.getElementById('edit-email').value = student.email;
    document.getElementById('edit-phone').value = student.phone;
    document.getElementById('edit-marks').value = student.marks;
    document.getElementById('edit-att').value = student.attendance;

    openModal('update-student-modal');
}

// Update Student submit triggers
function submitUpdateStudent(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById('edit-id').value);

    const updatedData = {
        name: document.getElementById('edit-name').value,
        age: document.getElementById('edit-age').value,
        gender: document.getElementById('edit-gender').value,
        branch: document.getElementById('edit-branch').value,
        year: document.getElementById('edit-year').value,
        email: document.getElementById('edit-email').value,
        phone: document.getElementById('edit-phone').value,
        marks: document.getElementById('edit-marks').value,
        attendance: document.getElementById('edit-att').value
    };

    if (database.update(id, updatedData)) {
        saveToLocalStorage();
        updateUI();
        closeModal('update-student-modal');
        showToast("Record Updated", `Student #${id} updated successfully.`, "success");
    }
}

// Undo delete pops from Stack
function popUndoHistory() {
    if (undoHistory.isEmpty()) {
        showToast("Stack Underflow", "No deleted student logs in Undo stack history.", "warning");
        return;
    }
    const popped = undoHistory.pop();
    database.insert(popped.student);
    saveToLocalStorage();
    updateUI();
    showToast("Restoration Complete", `Successfully restored student ${popped.student.name} from Stack.`, "success");
}

function clearUndoHistory() {
    undoHistory.items = [];
    updateUI();
    showToast("Stack Cleared", "Cleared all undo stack traces.", "success");
}

// Admission Queue Enqueue submissions
function submitEnqueueStudent(event) {
    event.preventDefault();
    const id = parseInt(document.getElementById('q-id').value);

    if (database.search(id) !== null) {
        showToast("Admission Alert", `ID #${id} already belongs to an active student. Proceeding anyway.`, "warning");
    }

    const applicant = new Student(
        id,
        document.getElementById('q-name').value,
        document.getElementById('q-age').value,
        document.getElementById('q-gender').value,
        document.getElementById('q-branch').value,
        document.getElementById('q-year').value,
        document.getElementById('q-email').value,
        document.getElementById('q-phone').value,
        document.getElementById('q-marks').value,
        document.getElementById('q-att').value
    );

    admissionQueue.enqueue(applicant);
    saveToLocalStorage();
    updateUI();
    closeModal('enqueue-student-modal');
    showToast("Enqueued", `${applicant.name} added to the admission queue.`, "success");
}

// Queue Peek
function peekQueue() {
    const next = admissionQueue.peek();
    if (!next) {
        showToast("Queue Empty", "No student applicants in queue to peek.", "warning");
        return;
    }

    const container = document.getElementById('peek-details-body');
    container.innerHTML = `
        <div class="peek-row"><span class="peek-label">Student ID:</span><span class="peek-val">#${next.studentId}</span></div>
        <div class="peek-row"><span class="peek-label">Full Name:</span><span class="peek-val">${next.name}</span></div>
        <div class="peek-row"><span class="peek-label">Branch:</span><span class="peek-val">${next.branch}</span></div>
        <div class="peek-row"><span class="peek-label">Gender / Age:</span><span class="peek-val">${next.gender} / ${next.age} yrs</span></div>
        <div class="peek-row"><span class="peek-label">Entrance Marks:</span><span class="peek-val">${next.marks.toFixed(1)} / 100.0</span></div>
        <div class="peek-row"><span class="peek-label">Grade:</span><span class="peek-val"><span class="pill pill-cyan">${next.grade}</span></span></div>
    `;

    openModal('peek-modal');
}

// Approve Peeked Applicant
function approvePeekedApplicant() {
    const next = admissionQueue.peek();
    if (next) {
        if (database.search(next.studentId) !== null) {
            showToast("Admission Blocked", "Unique ID constraint violated. Discard or update applicant.", "error");
            closeModal('peek-modal');
            return;
        }
        processQueueNext();
        closeModal('peek-modal');
    }
}

// Process Queue Next (Dequeue)
function processQueueNext() {
    if (admissionQueue.isEmpty()) {
        showToast("Queue Empty", "No applicants in queue to process.", "warning");
        return;
    }

    const next = admissionQueue.peek();
    if (database.search(next.studentId) !== null) {
        showToast("Collision Error", `Cannot admit: ID #${next.studentId} already exists in database.`, "error");
        return;
    }

    const dequeued = admissionQueue.dequeue();
    if (dequeued) {
        database.insert(dequeued);
        saveToLocalStorage();
        updateUI();
        showToast("Admission Approved", `${dequeued.name} is now registered in the main database.`, "success");
    }
}

// ==========================================
// 💾 LOCAL STORAGE PERSISTENCE
// ==========================================

function saveToLocalStorage() {
    const arr = database.toArray();
    localStorage.setItem('sms_students', JSON.stringify(arr));
    localStorage.setItem('sms_queue', JSON.stringify(admissionQueue.items));
    localStorage.setItem('sms_stack', JSON.stringify(undoHistory.items));
}

function loadFromLocalStorage() {
    try {
        const rawList = localStorage.getItem('sms_students');
        if (rawList) {
            const arr = JSON.parse(rawList);
            database.clear();
            arr.forEach(item => {
                database.insert(new Student(item.studentId, item.name, item.age, item.gender, item.branch, item.year, item.email, item.phone, item.marks, item.attendance));
            });
        }

        const rawQueue = localStorage.getItem('sms_queue');
        if (rawQueue) {
            const arr = JSON.parse(rawQueue);
            admissionQueue.items = arr.map(item => new Student(item.studentId, item.name, item.age, item.gender, item.branch, item.year, item.email, item.phone, item.marks, item.attendance));
        }

        const rawStack = localStorage.getItem('sms_stack');
        if (rawStack) {
            const arr = JSON.parse(rawStack);
            undoHistory.items = arr.map(entry => ({
                student: new Student(entry.student.studentId, entry.student.name, entry.student.age, entry.student.gender, entry.student.branch, entry.student.year, entry.student.email, entry.student.phone, entry.student.marks, entry.student.attendance),
                deletedAt: entry.deletedAt
            }));
        }
    } catch (e) {
        console.error("Error reading localStorage", e);
    }
}
