# 🚀 Advanced Student Management System (Java + DSA)

A complete, professional console-based Student Management System built using **Java 17** that implements core **Data Structures and Algorithms (DSA)** manually, showcasing how theoretical structures perform in a production-like application.

---

## 📋 Features

- **Robust Student Records**: Stores student ID, name, age, gender, branch, year, email, phone, marks, attendance, and automatically computes letter grades.
- **Custom Doubly Linked List**: Real-time record insertion, deletion, and node updates.
- **Custom Undo Delete Stack**: Keep track of deleted students and restore them instantly with $O(1)$ complexity.
- **Custom Admission Queue**: Simulates a FIFO registration pipeline to review applicant details before adding them to the database.
- **Manual Sorting Algorithms**: Five manual sort routines (Bubble, Selection, Insertion, Merge, Quick) to sort students by ID, Name, Marks, and Attendance in ascending/descending order.
- **Manual Searching Algorithms**:
  - Linear Search by ID, Name, or Branch.
  - Recursive Binary Search by ID (automatically invokes Merge Sort if data is unsorted).
- **Fast Hashing Lookups**: HashMap is utilized for instant $O(1)$ student record search and duplicate checking.
- **Robust Field Validation**: Strict type checking, bound boundaries, email regex validation, and unique ID verification to prevent crashes.
- **Persistent Data Store**: Standard CSV file-based reader/writer to save database records to `data/students.txt` automatically on exit.
- **Live Statistic Analytics**: Computes class means, score extremes, attendance averages, passing percentages, branch density, and grade distributions.

---

## 🧩 Manual DSA Concepts Implemented

### 1. Custom Doubly Linked List (`StudentLinkedList.java`)
- **Node definition**: `StudentNode` contains data, `next`, and `prev` pointers.
- **Usage**: Handles the dynamic chain of students without resizing latency or fixed limits.
- **Insertion**: $O(1)$ at tail.
- **Deletion**: $O(N)$ lookup then $O(1)$ pointer adjustments.

### 2. Custom Stack (`StudentStack.java`)
- **Mechanism**: A dynamic, node-based LIFO stack.
- **Usage**: Temporarily houses deleted `Student` records.
- **Undo Operation**: Popping from this stack restores the student back into the primary structures with $O(1)$ time complexity.

### 3. Custom Queue (`StudentQueue.java`)
- **Mechanism**: A dynamic, node-based FIFO queue.
- **Usage**: Buffers incoming student applicants in order of request.
- **Processing**: Processing a student pulls from the front of the queue, verifies uniqueness, and commits registration.

### 4. Manual Searching (`SearchAlgorithms.java`)
- **Linear Search**: Checks entries one-by-one; time complexity is $O(N)$.
- **Binary Search**: Dividends index search ranges recursively; time complexity is $O(\log N)$.

### 5. Manual Sorting (`SortingAlgorithms.java`)
- **Quadratic Sorting**: Bubble, Selection, and Insertion Sort ($O(N^2)$).
- **Divide and Conquer Sorting**:
  - **Merge Sort**: Stable sort with guaranteed $O(N \log N)$ worst-case time complexity.
  - **Quick Sort**: Space-efficient in-place sorting, averaging $O(N \log N)$ time.

### 6. HashMap Lookup (`StudentManager.java`)
- **Mechanism**: Utilizes key-value mapping (`HashMap<Integer, Student>`).
- **Complexity**: $O(1)$ average time complexity.
- **Why $O(1)$?**: It uses a hash function to compute array indices. While collisions (multiple keys hashing to the same bucket) can occur, separate chaining or open addressing resolves them. For a good hash distribution, average bucket occupancy is small, making lookup constant time.

---

## 🏗️ Project Architecture

```
StudentManagementSystem/
│
├── src/
│   ├── Main.java               # CLI Controller and Menu Loop
│   ├── Student.java            # Data Model with Grade calculator
│   ├── StudentManager.java     # System Coordinator (IO, Stats, Data sync)
│   ├── StudentNode.java        # Doubly Linked List Node
│   ├── StudentLinkedList.java  # Custom Doubly Linked List
│   ├── StudentQueue.java       # Custom FIFO Queue
│   ├── StudentStack.java       # Custom LIFO Stack
│   ├── SearchAlgorithms.java   # Custom Linear & Binary Search
│   ├── SortingAlgorithms.java  # Custom Bubble, Selection, Insertion, Merge, Quick Sort
│   └── InputValidator.java     # Regular expression and Scanner helpers
│
├── data/
│   └── students.txt            # Persistent database text file (CSV format)
│
└── README.md                   # This instruction guide
```

---

## ⚡ Complexity Table

| Operation / Algorithm | Best Case | Average Case | Worst Case | Space Complexity |
| :--- | :--- | :--- | :--- | :--- |
| **HashMap Lookup** | $O(1)$ | $O(1)$ | $O(N)$ | $O(N)$ |
| **Stack Push/Pop** | $O(1)$ | $O(1)$ | $O(1)$ | $O(1)$ |
| **Queue Enqueue/Dequeue** | $O(1)$ | $O(1)$ | $O(1)$ | $O(1)$ |
| **Linear Search** | $O(1)$ | $O(N)$ | $O(N)$ | $O(1)$ |
| **Binary Search** | $O(1)$ | $O(\log N)$ | $O(\log N)$ | $O(\log N)$ (call stack) |
| **Bubble Sort** | $O(N)$ (optimized) | $O(N^2)$ | $O(N^2)$ | $O(1)$ |
| **Selection Sort** | $O(N^2)$ | $O(N^2)$ | $O(N^2)$ | $O(1)$ |
| **Insertion Sort** | $O(N)$ | $O(N^2)$ | $O(N^2)$ | $O(1)$ |
| **Merge Sort** | $O(N \log N)$ | $O(N \log N)$ | $O(N \log N)$ | $O(N)$ |
| **Quick Sort** | $O(N \log N)$ | $O(N \log N)$ | $O(N^2)$ | $O(\log N)$ (call stack) |

---

## 🛠️ Compilation & Execution

### Prerequisites
- Ensure **Java 17 Development Kit (JDK)** or higher is installed and configured in your environment variable PATH.

### Compiling the Code
Open your terminal inside the `StudentManagementSystem/` root directory and execute:
```bash
javac src/*.java
```

### Running the Application
Run the compiled byte-code with:
```bash
java -cp src Main
```

---

## 📊 Sample Execution Log

### Main Menu
```
=========================================
        STUDENT MANAGEMENT SYSTEM        
=========================================
 1. Add Student
 2. View All Students
 3. Search Student
 4. Update Student
 5. Delete Student
 6. Undo Delete
 7. Sort Students
 8. Binary Search
 9. Admission Queue
 10. Recently Deleted Students (Stack)
 11. Student Statistics
 12. Save Data
 13. Load Data
 14. Exit
=========================================
Enter your choice: 
```

### Viewing All Students (Tabular Output)
```
+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+
| ID       | Name                 | Age | Gender   | Branch     | Year | Email Address             | Phone No     | Marks  | Attendance | Grade |
+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+
| 1001     | Alice Smith          | 19  | Female   | CSE        | 2    | alice@email.com           | 9876543210   | 92.5   | 95.0       | A+    |
| 1002     | Bob Johnson          | 20  | Male     | ME         | 3    | bob@email.com             | 8765432109   | 78.0   | 88.0       | B     |
+----------+----------------------+-----+----------+------------+------+---------------------------+--------------+--------+------------+-------+
```

---

## 🔮 Future Enhancements
- **SQL Integration**: Hook the system up to a JDBC Database (MySQL/SQLite) for transactional integrity.
- **Graphical GUI**: Build a JavaFX or Swing UI to replace the CLI.
- **Multithreading Auto-Save**: Add a background daemon thread that auto-saves student modifications to a secondary file periodically.
