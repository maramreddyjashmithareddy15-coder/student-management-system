const dotenv = require('dotenv');
const http = require('http');
const app = require('./app');
const db = require('./config/db');
const { seedDatabase } = require('./db/seeder');

// Load environment variables
dotenv.config();

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    // 1. Initialize Database
    await db.initDatabase();

    // 2. Seed database if empty
    await seedDatabase();

    // 3. Start server
    const server = http.createServer(app);
    server.listen(PORT, () => {
      console.log(`===============================================`);
      console.log(` Server is running on port ${PORT} in ${db.dbType} mode`);
      console.log(` Health check URL: http://localhost:${PORT}/api/health`);
      console.log(`===============================================`);
    });
  } catch (err) {
    console.error('CRITICAL: Server failed to start:', err.message);
    process.exit(1);
  }
}

startServer();
