const bcrypt = require('bcryptjs');
const db = require('../config/db');

async function seedDatabase() {
  try {
    // Check if seeding is already done
    const userCheck = await db.query('SELECT COUNT(*) as count FROM users');
    const userCount = userCheck[0].count;
    
    if (userCount > 0) {
      console.log('Database already seeded. Skipping seeder...');
      return;
    }

    console.log('Database is empty. Starting seeding process...');

    // 1. Hash passwords
    const adminHash = await bcrypt.hash('admin123', 10);
    const facultyHash = await bcrypt.hash('faculty123', 10);
    const studentHash = await bcrypt.hash('student123', 10);

    // 2. Insert Users
    // Roles: Admin, Faculty, Student
    console.log('Seeding users...');
    const users = [
      { username: 'admin', email: 'admin@college.com', password: adminHash, role: 'Admin' },
      { username: 'faculty', email: 'faculty@college.com', password: facultyHash, role: 'Faculty' },
      { username: 'student', email: 'student@college.com', password: studentHash, role: 'Student' },
      // Faculty Users
      { username: 'alan', email: 'alan@college.com', password: facultyHash, role: 'Faculty' },
      { username: 'ada', email: 'ada@college.com', password: facultyHash, role: 'Faculty' },
      { username: 'claude', email: 'claude@college.com', password: facultyHash, role: 'Faculty' },
      { username: 'tesla', email: 'tesla@college.com', password: facultyHash, role: 'Faculty' },
      // Student Users
      { username: 'john', email: 'john@college.com', password: studentHash, role: 'Student' },
      { username: 'alice', email: 'alice@college.com', password: studentHash, role: 'Student' },
      { username: 'bob', email: 'bob@college.com', password: studentHash, role: 'Student' },
      { username: 'charlie', email: 'charlie@college.com', password: studentHash, role: 'Student' },
      { username: 'david', email: 'david@college.com', password: studentHash, role: 'Student' },
      { username: 'emma', email: 'emma@college.com', password: studentHash, role: 'Student' },
      { username: 'frank', email: 'frank@college.com', password: studentHash, role: 'Student' },
      { username: 'george', email: 'george@college.com', password: studentHash, role: 'Student' },
      { username: 'helen', email: 'helen@college.com', password: studentHash, role: 'Student' }
    ];

    for (const u of users) {
      await db.query(
        'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
        [u.username, u.email, u.password, u.role]
      );
    }

    // 3. Insert Departments
    console.log('Seeding departments...');
    const departments = [
      { name: 'Computer Science & Engineering', code: 'CSE', hod: 'Dr. Alan Turing' },
      { name: 'Information Technology', code: 'IT', hod: 'Dr. Ada Lovelace' },
      { name: 'Electronics and Communication', code: 'ECE', hod: 'Prof. Claude Shannon' },
      { name: 'Electrical Engineering', code: 'EE', hod: 'Prof. Nikola Tesla' },
      { name: 'Mechanical Engineering', code: 'ME', hod: 'Dr. James Watt' }
    ];

    for (const d of departments) {
      await db.query(
        'INSERT INTO departments (department_name, department_code, hod) VALUES (?, ?, ?)',
        [d.name, d.code, d.hod]
      );
    }

    // 4. Insert Courses
    console.log('Seeding courses...');
    const courses = [
      { name: 'B.Tech Computer Science', code: 'BTech-CSE', deptId: 1, duration: 4, semesters: 8, desc: 'Bachelor of Technology in Computer Science & Engineering' },
      { name: 'B.Tech Information Technology', code: 'BTech-IT', deptId: 2, duration: 4, semesters: 8, desc: 'Bachelor of Technology in Information Technology' },
      { name: 'B.Tech Electronics & Communication', code: 'BTech-ECE', deptId: 3, duration: 4, semesters: 8, desc: 'Bachelor of Technology in Electronics and Communication Engineering' },
      { name: 'B.Tech Mechanical Engineering', code: 'BTech-ME', deptId: 5, duration: 4, semesters: 8, desc: 'Bachelor of Technology in Mechanical Engineering' },
      { name: 'B.Tech Electrical Engineering', code: 'BTech-EE', deptId: 4, duration: 4, semesters: 8, desc: 'Bachelor of Technology in Electrical Engineering' }
    ];

    for (const c of courses) {
      await db.query(
        'INSERT INTO courses (course_name, course_code, department_id, duration, semesters, description, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [c.name, c.code, c.deptId, c.duration, c.semesters, c.desc, 'Active']
      );
    }

    // 5. Insert Faculty
    console.log('Seeding faculty...');
    const facultyList = [
      { fid: 'F-001', name: 'Dr. Grace Hopper', email: 'faculty@college.com', phone: '9876543210', gender: 'Female', deptId: 1, qual: 'Ph.D in CSE', desig: 'Professor', date: '2015-08-01' },
      { fid: 'F-002', name: 'Dr. Alan Turing', email: 'alan@college.com', phone: '9876543211', gender: 'Male', deptId: 1, qual: 'Ph.D in Mathematics', desig: 'HOD & Professor', date: '2012-07-15' },
      { fid: 'F-003', name: 'Dr. Ada Lovelace', email: 'ada@college.com', phone: '9876543212', gender: 'Female', deptId: 2, qual: 'Ph.D in Systems Science', desig: 'HOD & Associate Professor', date: '2016-01-10' },
      { fid: 'F-004', name: 'Prof. Claude Shannon', email: 'claude@college.com', phone: '9876543213', gender: 'Male', deptId: 3, qual: 'M.Tech in Telecom', desig: 'HOD & Professor', date: '2014-06-20' },
      { fid: 'F-005', name: 'Prof. Nikola Tesla', email: 'tesla@college.com', phone: '9876543214', gender: 'Male', deptId: 4, qual: 'Ph.D in Electrical Eng', desig: 'HOD & Professor', date: '2010-09-01' }
    ];

    for (const f of facultyList) {
      await db.query(
        'INSERT INTO faculty (faculty_id, name, email, phone, gender, department_id, qualification, designation, joining_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [f.fid, f.name, f.email, f.phone, f.gender, f.deptId, f.qual, f.desig, f.date, 'Active']
      );
    }

    // 6. Insert Students
    console.log('Seeding students...');
    const studentsList = [
      { sid: 'S-001', roll: '101', fname: 'Jane', lname: 'Smith', gen: 'Female', dob: '2005-04-12', blood: 'B+', email: 'student@college.com', phone: '8765432100', addr: '123 Academic Lane, Campus', deptId: 1, courseId: 1, year: 3, sem: 5, date: '2023-08-20', pname: 'Richard Smith', pphone: '8765432109', pemail: 'richard@gmail.com' },
      { sid: 'S-002', roll: '102', fname: 'John', lname: 'Doe', gen: 'Male', dob: '2005-09-18', blood: 'O+', email: 'john@college.com', phone: '8765432101', addr: '456 Hostellers Hall, Campus', deptId: 1, courseId: 1, year: 3, sem: 5, date: '2023-08-20', pname: 'Robert Doe', pphone: '8765432110', pemail: 'robert@gmail.com' },
      { sid: 'S-003', roll: '103', fname: 'Alice', lname: 'Cooper', gen: 'Female', dob: '2006-02-28', blood: 'A-', email: 'alice@college.com', phone: '8765432102', addr: '789 Garden Road, City', deptId: 2, courseId: 2, year: 2, sem: 3, date: '2024-08-18', pname: 'Mary Cooper', pphone: '8765432111', pemail: 'mary@gmail.com' },
      { sid: 'S-004', roll: '104', fname: 'Bob', lname: 'Marley', gen: 'Male', dob: '2007-06-15', blood: 'O-', email: 'bob@college.com', phone: '8765432103', addr: '234 Reggae Boulevard, City', deptId: 3, courseId: 3, year: 1, sem: 1, date: '2025-08-15', pname: 'Nesta Marley', pphone: '8765432112', pemail: 'nesta@gmail.com' },
      { sid: 'S-005', roll: '105', fname: 'Charlie', lname: 'Brown', gen: 'Male', dob: '2004-10-30', blood: 'AB+', email: 'charlie@college.com', phone: '8765432104', addr: '12 Peanut Street, City', deptId: 5, courseId: 4, year: 4, sem: 7, date: '2022-08-22', pname: 'Sally Brown', pphone: '8765432113', pemail: 'sally@gmail.com' },
      { sid: 'S-006', roll: '106', fname: 'David', lname: 'Beckham', gen: 'Male', dob: '2005-05-02', blood: 'O+', email: 'david@college.com', phone: '8765432105', addr: '99 Soccer Way, City', deptId: 5, courseId: 5, year: 3, sem: 5, date: '2023-08-20', pname: 'Ted Beckham', pphone: '8765432114', pemail: 'ted@gmail.com' },
      { sid: 'S-007', roll: '107', fname: 'Emma', lname: 'Watson', gen: 'Female', dob: '2006-04-15', blood: 'A+', email: 'emma@college.com', phone: '8765432106', addr: '32 Library Lane, Town', deptId: 1, courseId: 1, year: 2, sem: 3, date: '2024-08-18', pname: 'Chris Watson', pphone: '8765432115', pemail: 'chris@gmail.com' },
      { sid: 'S-008', roll: '108', fname: 'Frank', lname: 'Sinatra', gen: 'Male', dob: '2005-12-12', blood: 'B-', email: 'frank@college.com', phone: '8765432107', addr: '77 Broadway Blvd, City', deptId: 3, courseId: 3, year: 3, sem: 5, date: '2023-08-20', pname: 'Dolly Sinatra', pphone: '8765432116', pemail: 'dolly@gmail.com' },
      { sid: 'S-009', roll: '109', fname: 'George', lname: 'Washington', gen: 'Male', dob: '2005-02-22', blood: 'A+', email: 'george@college.com', phone: '8765432108', addr: '1 Independence Ave, City', deptId: 2, courseId: 2, year: 3, sem: 5, date: '2023-08-20', pname: 'Augustine Washington', pphone: '8765432117', pemail: 'aug@gmail.com' },
      { sid: 'S-010', roll: '110', fname: 'Helen', lname: 'Keller', gen: 'Female', dob: '2006-06-27', blood: 'O+', email: 'helen@college.com', phone: '8765432099', addr: '44 Silent Ridge, City', deptId: 5, courseId: 4, year: 2, sem: 3, date: '2024-08-18', pname: 'Arthur Keller', pphone: '8765432118', pemail: 'arthur@gmail.com' }
    ];

    for (const s of studentsList) {
      await db.query(
        `INSERT INTO students (
          student_id, roll_number, first_name, last_name, gender, dob, blood_group, 
          email, phone, address, department_id, course_id, year, semester, 
          admission_date, parent_name, parent_phone, parent_email, profile_image, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          s.sid, s.roll, s.fname, s.lname, s.gen, s.dob, s.blood, 
          s.email, s.phone, s.addr, s.deptId, s.courseId, s.year, s.sem, 
          s.date, s.pname, s.pphone, s.pemail, null, 'Active'
        ]
      );
    }

    // 7. Insert Subjects
    console.log('Seeding subjects...');
    const subjects = [
      { name: 'Data Structures and Algorithms', code: 'CS-301', deptId: 1, courseId: 1, sem: 3, credits: 4, facId: 2 },
      { name: 'Database Management Systems', code: 'CS-501', deptId: 1, courseId: 1, sem: 5, credits: 4, facId: 1 },
      { name: 'Computer Networks', code: 'CS-502', deptId: 1, courseId: 1, sem: 5, credits: 3, facId: 1 },
      { name: 'Theory of Computation', code: 'CS-503', deptId: 1, courseId: 1, sem: 5, credits: 4, facId: 2 },
      { name: 'Web Programming', code: 'IT-301', deptId: 2, courseId: 2, sem: 3, credits: 3, facId: 3 },
      { name: 'Software Engineering', code: 'IT-501', deptId: 2, courseId: 2, sem: 5, credits: 3, facId: 3 },
      { name: 'Digital Logic & Circuitry', code: 'ECE-101', deptId: 3, courseId: 3, sem: 1, credits: 4, facId: 4 },
      { name: 'Analog Communication', code: 'ECE-501', deptId: 3, courseId: 3, sem: 5, credits: 4, facId: 4 },
      { name: 'Basic Thermodynamics', code: 'ME-301', deptId: 5, courseId: 4, sem: 3, credits: 4, facId: 5 },
      { name: 'Machine Design', code: 'ME-701', deptId: 5, courseId: 4, sem: 7, credits: 3, facId: 5 }
    ];

    for (const sub of subjects) {
      await db.query(
        'INSERT INTO subjects (subject_name, subject_code, department_id, course_id, semester, credits, faculty_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [sub.name, sub.code, sub.deptId, sub.courseId, sub.sem, sub.credits, sub.facId]
      );
    }

    // 8. Insert Attendance Records (For Student 1 and Student 2 in CS-501 and CS-502)
    console.log('Seeding attendance...');
    // Seed attendance for 10 dates (10 class sessions)
    const dates = [
      '2026-08-17', '2026-08-18', '2026-08-19', '2026-08-20', '2026-08-21',
      '2026-08-24', '2026-08-25', '2026-08-26', '2026-08-27', '2026-08-28'
    ];

    // Jane Smith (id: 1) is Present 9 times, Absent 1 time (90% attendance)
    // John Doe (id: 2) is Present 7 times, Absent 3 times (70% attendance - falls under 75% warning!)
    const janesPresences = ['Present', 'Present', 'Present', 'Present', 'Absent', 'Present', 'Present', 'Present', 'Present', 'Present'];
    const johnsPresences = ['Present', 'Absent', 'Present', 'Present', 'Absent', 'Present', 'Present', 'Absent', 'Present', 'Present'];

    for (let i = 0; i < dates.length; i++) {
      // Subject 2: DBMS (faculty_id: 1)
      await db.query(
        'INSERT INTO attendance (student_id, subject_id, faculty_id, date, status) VALUES (?, ?, ?, ?, ?)',
        [1, 2, 1, dates[i], janesPresences[i]]
      );
      await db.query(
        'INSERT INTO attendance (student_id, subject_id, faculty_id, date, status) VALUES (?, ?, ?, ?, ?)',
        [2, 2, 1, dates[i], johnsPresences[i]]
      );

      // Subject 3: Computer Networks (faculty_id: 1)
      await db.query(
        'INSERT INTO attendance (student_id, subject_id, faculty_id, date, status) VALUES (?, ?, ?, ?, ?)',
        [1, 3, 1, dates[i], janesPresences[i]]
      );
      await db.query(
        'INSERT INTO attendance (student_id, subject_id, faculty_id, date, status) VALUES (?, ?, ?, ?, ?)',
        [2, 3, 1, dates[i], johnsPresences[i]]
      );
    }

    // 9. Insert Marks Records
    console.log('Seeding marks...');
    // Jane Smith (student_id: 1) marks
    // Subject 2: DBMS (Max marks: Internal 20, Midterm 30, Assignment 10, Final 40)
    const marksData = [
      // Jane Smith (Student 1) - DBMS
      { studentId: 1, subjectId: 2, examType: 'Internal', marks: 18, maxMarks: 20, grade: 'A+' },
      { studentId: 1, subjectId: 2, examType: 'Midterm', marks: 25, maxMarks: 30, grade: 'A' },
      { studentId: 1, subjectId: 2, examType: 'Assignment', marks: 9, maxMarks: 10, grade: 'A+' },
      { studentId: 1, subjectId: 2, examType: 'Final', marks: 35, maxMarks: 40, grade: 'A' },
      
      // Jane Smith (Student 1) - Computer Networks
      { studentId: 1, subjectId: 3, examType: 'Internal', marks: 19, maxMarks: 20, grade: 'A+' },
      { studentId: 1, subjectId: 3, examType: 'Midterm', marks: 27, maxMarks: 30, grade: 'A+' },
      { studentId: 1, subjectId: 3, examType: 'Assignment', marks: 8, maxMarks: 10, grade: 'A' },
      { studentId: 1, subjectId: 3, examType: 'Final', marks: 32, maxMarks: 40, grade: 'B+' },

      // John Doe (Student 2) - DBMS
      { studentId: 2, subjectId: 2, examType: 'Internal', marks: 14, maxMarks: 20, grade: 'B' },
      { studentId: 2, subjectId: 2, examType: 'Midterm', marks: 21, maxMarks: 30, grade: 'B+' },
      { studentId: 2, subjectId: 2, examType: 'Assignment', marks: 7, maxMarks: 10, grade: 'B' },
      { studentId: 2, subjectId: 2, examType: 'Final', marks: 22, maxMarks: 40, grade: 'C' },

      // John Doe (Student 2) - Computer Networks
      { studentId: 2, subjectId: 3, examType: 'Internal', marks: 11, maxMarks: 20, grade: 'C' },
      { studentId: 2, subjectId: 3, examType: 'Midterm', marks: 16, maxMarks: 30, grade: 'D' },
      { studentId: 2, subjectId: 3, examType: 'Assignment', marks: 6, maxMarks: 10, grade: 'C' },
      { studentId: 2, subjectId: 3, examType: 'Final', marks: 14, maxMarks: 40, grade: 'F' }
    ];

    for (const m of marksData) {
      await db.query(
        'INSERT INTO marks (student_id, subject_id, exam_type, marks, max_marks, grade) VALUES (?, ?, ?, ?, ?, ?)',
        [m.studentId, m.subjectId, m.examType, m.marks, m.maxMarks, m.grade]
      );
    }

    // 10. Insert Notices
    console.log('Seeding notices...');
    const notices = [
      { title: 'End Semester Theory Examination Schedule', desc: 'The theory examinations for the Odd Semesters are scheduled to start from November 16, 2026. Please check the website portal for details.', target: 'All', priority: 'High' },
      { title: 'Faculty Meeting for NAAC Accreditation Review', desc: 'All faculty members are requested to attend the NAAC accreditation planning meeting on September 4, 2026, at 2:00 PM in Conference Room A.', target: 'Faculty', priority: 'High' },
      { title: 'Annual Hackathon "Hack-Over-Flow 2026" Registrations Open', desc: 'Register your teams of up to 4 students for the annual hackathon. Cash prizes up to $5,000 to be won. Last date for registration is September 25, 2026.', target: 'Student', priority: 'Normal' },
      { title: 'TCS On-Campus Placement Drive for Final Year B.Tech', desc: 'TCS will be visiting campus for a recruitment drive on September 15, 2026. All eligible final year students must register via the placement portal.', target: 'Student', priority: 'High' },
      { title: 'Scheduled Maintenance: Student Portal Offline', desc: 'The student database portal will undergo scheduled database maintenance on Sunday, September 6, 2026, from 12:00 AM to 4:00 AM. Services will be offline.', target: 'All', priority: 'Low' }
    ];

    for (const n of notices) {
      await db.query(
        'INSERT INTO notices (title, description, target, priority) VALUES (?, ?, ?, ?)',
        [n.title, n.desc, n.target, n.priority]
      );
    }

    console.log('Database seeding completed successfully!');
  } catch (err) {
    console.error('Seeding process encountered an error:', err.message);
  }
}

module.exports = { seedDatabase };
