const express = require('express');
const cors = require('cors');
const path = require('path');

// Import routers
const authRoutes = require('./routes/auth');
const studentRoutes = require('./routes/students');
const facultyRoutes = require('./routes/faculty');
const departmentRoutes = require('./routes/departments');
const courseRoutes = require('./routes/courses');
const subjectRoutes = require('./routes/subjects');
const attendanceRoutes = require('./routes/attendance');
const marksRoutes = require('./routes/marks');
const noticeRoutes = require('./routes/notices');
const dashboardRoutes = require('./routes/dashboard');

const app = express();

// Middlewares
app.use(cors({
  origin: '*', // For development, allow React dev server requests
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve profile uploads if any (optional future enhancement)
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Routes Mount
app.use('/api/auth', authRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/faculty', facultyRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/subjects', subjectRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/marks', marksRoutes);
app.use('/api/notices', noticeRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Base status route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'College Student Management System API is healthy.' });
});

// Serve frontend build in production / cloud deployment if present
const frontendDist = path.join(__dirname, '../../frontend/dist');
const fs = require('fs');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (req, res, next) => {
    if (req.originalUrl.startsWith('/api')) {
      return next();
    }
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

// 404 Route handler for unhandled API routes
app.use((req, res, next) => {
  res.status(404).json({ message: `API route not found: ${req.originalUrl}` });
});

// Secure Global Error Handler (Never leaks raw stack traces or DB syntax to client)
app.use((err, req, res, next) => {
  console.error('API Error: ', err.stack || err.message);
  
  const statusCode = err.statusCode || 500;
  let message = 'An unexpected server error occurred. Please try again later.';
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({ message: err.message });
  }

  res.status(statusCode).json({ message });
});

module.exports = app;
