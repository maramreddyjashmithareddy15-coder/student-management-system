const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/courses - List all courses with department info
router.get('/', authenticateToken, async (req, res) => {
  try {
    const sql = `
      SELECT c.*, d.department_name 
      FROM courses c
      LEFT JOIN departments d ON c.department_id = d.id
      ORDER BY c.id ASC
    `;
    const courses = await db.query(sql);
    res.json(courses);
  } catch (err) {
    console.error('List courses error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/courses - Add course (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const { course_name, course_code, department_id, duration, semesters, description, status = 'Active' } = req.body;

  if (!course_name || !course_code || !department_id || !duration || !semesters) {
    return res.status(400).json({ message: 'Course name, code, department, duration, and semesters are required.' });
  }

  try {
    const existing = await db.query('SELECT id FROM courses WHERE course_code = ?', [course_code]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Course code already exists.' });
    }

    const result = await db.query(
      `INSERT INTO courses (course_name, course_code, department_id, duration, semesters, description, status) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [course_name, course_code, department_id, duration, semesters, description || '', status]
    );

    res.status(201).json({
      message: 'Course created successfully',
      courseId: result.insertId
    });
  } catch (err) {
    console.error('Create course error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/courses/:id - Update course (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const { course_name, course_code, department_id, duration, semesters, description, status } = req.body;

  try {
    const current = await db.query('SELECT * FROM courses WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Course not found.' });
    }

    if (course_code !== current[0].course_code) {
      const existing = await db.query('SELECT id FROM courses WHERE course_code = ? AND id != ?', [course_code, id]);
      if (existing.length > 0) {
        return res.status(400).json({ message: 'Course code already in use.' });
      }
    }

    await db.query(
      `UPDATE courses 
       SET course_name = ?, course_code = ?, department_id = ?, duration = ?, semesters = ?, description = ?, status = ? 
       WHERE id = ?`,
      [course_name, course_code, department_id, duration, semesters, description || '', status, id]
    );

    res.json({ message: 'Course updated successfully' });
  } catch (err) {
    console.error('Update course error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/courses/:id - Delete course (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const current = await db.query('SELECT * FROM courses WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Course not found.' });
    }

    await db.query('DELETE FROM courses WHERE id = ?', [id]);
    res.json({ message: 'Course deleted successfully' });
  } catch (err) {
    console.error('Delete course error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
