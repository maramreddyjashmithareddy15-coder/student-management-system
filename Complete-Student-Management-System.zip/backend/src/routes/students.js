const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/students - List students (with filters, search, pagination)
router.get('/', authenticateToken, authorize('Admin', 'Faculty'), async (req, res) => {
  const { 
    search = '', 
    department_id = '', 
    course_id = '', 
    year = '', 
    semester = '', 
    status = '',
    page = 1,
    limit = 10 
  } = req.query;

  const offset = (parseInt(page) - 1) * parseInt(limit);
  let sql = `
    SELECT s.*, d.department_name, c.course_name 
    FROM students s
    LEFT JOIN departments d ON s.department_id = d.id
    LEFT JOIN courses c ON s.course_id = c.id
    WHERE 1=1
  `;
  const params = [];

  // Search filter
  if (search) {
    sql += ` AND (s.student_id LIKE ? OR s.roll_number LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.email LIKE ?)`;
    const searchWild = `%${search}%`;
    params.push(searchWild, searchWild, searchWild, searchWild, searchWild);
  }

  // Exact matches
  if (department_id) {
    sql += ` AND s.department_id = ?`;
    params.push(parseInt(department_id));
  }
  if (course_id) {
    sql += ` AND s.course_id = ?`;
    params.push(parseInt(course_id));
  }
  if (year) {
    sql += ` AND s.year = ?`;
    params.push(parseInt(year));
  }
  if (semester) {
    sql += ` AND s.semester = ?`;
    params.push(parseInt(semester));
  }
  if (status) {
    sql += ` AND s.status = ?`;
    params.push(status);
  }

  // Count total matching records for pagination
  let countSql = `SELECT COUNT(*) as total FROM (${sql}) as t`;
  
  // Sort and pagination
  sql += ` ORDER BY s.id DESC LIMIT ? OFFSET ?`;
  
  // For SQLite we need to cast pagination params as numbers
  const countParams = [...params];
  params.push(parseInt(limit), offset);

  try {
    const countResult = await db.query(countSql, countParams);
    const total = countResult[0].total;

    const students = await db.query(sql, params);
    
    res.json({
      students,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    console.error('List students error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// GET /api/students/:id - Detailed student profile
router.get('/:id', authenticateToken, async (req, res) => {
  const { id } = req.params;

  // Let students view only their own profile
  if (req.user.role === 'Student') {
    try {
      const selfCheck = await db.query('SELECT id FROM students WHERE email = ?', [req.user.email]);
      if (selfCheck.length === 0 || selfCheck[0].id !== parseInt(id)) {
        return res.status(403).json({ message: 'Forbidden. You can only view your own profile.' });
      }
    } catch (err) {
      return res.status(500).json({ message: 'Error verifying permission.' });
    }
  }

  try {
    // 1. Fetch core student details
    const studentRows = await db.query(
      `SELECT s.*, d.department_name, c.course_name 
       FROM students s
       LEFT JOIN departments d ON s.department_id = d.id
       LEFT JOIN courses c ON s.course_id = c.id
       WHERE s.id = ?`,
      [id]
    );

    if (studentRows.length === 0) {
      return res.status(404).json({ message: 'Student not found.' });
    }

    const student = studentRows[0];

    // 2. Fetch attendance summary details
    const attendanceStats = await db.query(
      `SELECT 
        sub.subject_name,
        sub.subject_code,
        COUNT(a.id) as total_classes,
        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count,
        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent_count
       FROM subjects sub
       LEFT JOIN attendance a ON sub.id = a.subject_id AND a.student_id = ?
       WHERE sub.course_id = ? AND sub.semester = ?
       GROUP BY sub.id`,
      [student.id, student.course_id, student.semester]
    );

    // Calculate aggregate attendance
    let totalClasses = 0;
    let totalPresent = 0;
    attendanceStats.forEach(item => {
      totalClasses += item.total_classes || 0;
      totalPresent += item.present_count || 0;
    });
    const overallAttendance = totalClasses > 0 ? ((totalPresent / totalClasses) * 100).toFixed(1) : '100.0';

    // 3. Fetch academic grades and GPA details
    const marksList = await db.query(
      `SELECT m.*, sub.subject_name, sub.subject_code, sub.credits
       FROM marks m
       JOIN subjects sub ON m.subject_id = sub.id
       WHERE m.student_id = ?`,
      [student.id]
    );

    // Fetch enrolled subjects list
    const subjectsList = await db.query(
      `SELECT sub.*, f.name as faculty_name 
       FROM subjects sub
       LEFT JOIN faculty f ON sub.faculty_id = f.id
       WHERE sub.course_id = ? AND sub.semester = ?`,
      [student.course_id, student.semester]
    );

    // Calculate CGPA/GPA based on Final Exam grades
    // Grade rules: A+=10, A=9, B+=8, B=7, C=6, D=5, F=0
    let totalCredits = 0;
    let earnedPoints = 0;

    // Filter final exam grades to calculate current CGPA
    const finalExams = marksList.filter(m => m.exam_type === 'Final');
    finalExams.forEach(m => {
      let gp = 0;
      if (m.grade === 'A+') gp = 10;
      else if (m.grade === 'A') gp = 9;
      else if (m.grade === 'B+') gp = 8;
      else if (m.grade === 'B') gp = 7;
      else if (m.grade === 'C') gp = 6;
      else if (m.grade === 'D') gp = 5;
      
      earnedPoints += gp * (m.credits || 4);
      totalCredits += (m.credits || 4);
    });
    
    const cgpa = totalCredits > 0 ? (earnedPoints / totalCredits).toFixed(2) : '0.00';

    res.json({
      ...student,
      attendancePercentage: parseFloat(overallAttendance),
      cgpa: parseFloat(cgpa),
      attendanceStats,
      marksList,
      subjectsList
    });

  } catch (err) {
    console.error('Get student details error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/students - Register a new student (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const {
    student_id, roll_number, first_name, last_name, gender, dob, blood_group,
    email, phone, address, department_id, course_id, year, semester, admission_date,
    parent_name, parent_phone, parent_email, profile_image, status = 'Active'
  } = req.body;

  // Validation
  if (!student_id || !roll_number || !first_name || !last_name || !gender || !dob || !email || !department_id || !course_id || !year || !semester || !admission_date) {
    return res.status(400).json({ message: 'All mandatory academic and personal fields are required.' });
  }

  try {
    // 1. Check if student_id, roll_number, or email are already taken
    const existing = await db.query(
      'SELECT id FROM students WHERE student_id = ? OR roll_number = ? OR email = ?',
      [student_id, roll_number, email]
    );
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Student ID, Roll Number, or Email already registered.' });
    }

    // Check users table as well
    const existingUser = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'A user login is already registered with this email.' });
    }

    // 2. Create Student record
    const result = await db.query(
      `INSERT INTO students (
        student_id, roll_number, first_name, last_name, gender, dob, blood_group,
        email, phone, address, department_id, course_id, year, semester, admission_date,
        parent_name, parent_phone, parent_email, profile_image, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        student_id, roll_number, first_name, last_name, gender, dob, blood_group,
        email, phone, address, department_id, course_id, year, semester, admission_date,
        parent_name, parent_phone, parent_email, profile_image || null, status
      ]
    );

    // 3. Auto-generate student login user in user table
    const defaultPassword = 'student123';
    const hashedPassword = await bcrypt.hash(defaultPassword, 10);
    const username = email.split('@')[0];

    await db.query(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, 'Student']
    );

    res.status(201).json({
      message: 'Student added successfully',
      studentId: result.insertId
    });

  } catch (err) {
    console.error('Create student error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/students/:id - Update student details (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const {
    student_id, roll_number, first_name, last_name, gender, dob, blood_group,
    email, phone, address, department_id, course_id, year, semester, admission_date,
    parent_name, parent_phone, parent_email, profile_image, status
  } = req.body;

  try {
    // 1. Check if student exists
    const currentRows = await db.query('SELECT * FROM students WHERE id = ?', [id]);
    if (currentRows.length === 0) {
      return res.status(404).json({ message: 'Student record not found.' });
    }
    const currentStudent = currentRows[0];

    // 2. Validate uniqueness of ID/Email/Roll if changed
    if (student_id !== currentStudent.student_id || roll_number !== currentStudent.roll_number || email !== currentStudent.email) {
      const uniquenessCheck = await db.query(
        `SELECT id, email, student_id, roll_number 
         FROM students 
         WHERE (student_id = ? OR roll_number = ? OR email = ?) AND id != ?`,
        [student_id, roll_number, email, id]
      );
      if (uniquenessCheck.length > 0) {
        return res.status(400).json({ message: 'Student ID, Roll Number, or Email already assigned to another student.' });
      }
    }

    // 3. Update students table
    await db.query(
      `UPDATE students 
       SET student_id = ?, roll_number = ?, first_name = ?, last_name = ?, gender = ?, dob = ?, 
           blood_group = ?, email = ?, phone = ?, address = ?, department_id = ?, course_id = ?, 
           year = ?, semester = ?, admission_date = ?, parent_name = ?, parent_phone = ?, 
           parent_email = ?, profile_image = ?, status = ?
       WHERE id = ?`,
      [
        student_id, roll_number, first_name, last_name, gender, dob, blood_group,
        email, phone, address, department_id, course_id, year, semester, admission_date,
        parent_name, parent_phone, parent_email, profile_image || null, status, id
      ]
    );

    // 4. Keep users table in sync if the email changes
    if (email !== currentStudent.email) {
      await db.query(
        'UPDATE users SET email = ?, username = ? WHERE email = ?',
        [email, email.split('@')[0], currentStudent.email]
      );
    }

    res.json({ message: 'Student updated successfully' });

  } catch (err) {
    console.error('Update student error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/students/:id - Delete student (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    // 1. Get student email to delete user
    const student = await db.query('SELECT email FROM students WHERE id = ?', [id]);
    if (student.length === 0) {
      return res.status(404).json({ message: 'Student record not found.' });
    }

    const { email } = student[0];

    // 2. Delete student (cascades will clean marks & attendance)
    await db.query('DELETE FROM students WHERE id = ?', [id]);

    // 3. Delete login user
    await db.query('DELETE FROM users WHERE email = ?', [email]);

    res.json({ message: 'Student deleted successfully' });

  } catch (err) {
    console.error('Delete student error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
