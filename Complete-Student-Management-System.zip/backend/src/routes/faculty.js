const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/faculty - List all faculty (with search and department filter)
router.get('/', authenticateToken, authorize('Admin', 'Faculty'), async (req, res) => {
  const { search = '', department_id = '' } = req.query;

  let sql = `
    SELECT f.*, d.department_name 
    FROM faculty f
    LEFT JOIN departments d ON f.department_id = d.id
    WHERE 1=1
  `;
  const params = [];

  if (search) {
    sql += ` AND (f.faculty_id LIKE ? OR f.name LIKE ? OR f.email LIKE ? OR f.designation LIKE ?)`;
    const searchWild = `%${search}%`;
    params.push(searchWild, searchWild, searchWild, searchWild);
  }

  if (department_id) {
    sql += ` AND f.department_id = ?`;
    params.push(parseInt(department_id));
  }

  sql += ` ORDER BY f.id DESC`;

  try {
    const faculty = await db.query(sql, params);
    res.json(faculty);
  } catch (err) {
    console.error('List faculty error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/faculty - Add a new faculty member (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const {
    faculty_id, name, email, phone, gender, department_id,
    qualification, designation, joining_date, status = 'Active'
  } = req.body;

  if (!faculty_id || !name || !email || !department_id || !designation || !joining_date) {
    return res.status(400).json({ message: 'All mandatory academic and personal fields are required.' });
  }

  try {
    // Check uniqueness
    const existing = await db.query(
      'SELECT id FROM faculty WHERE faculty_id = ? OR email = ?',
      [faculty_id, email]
    );
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Faculty ID or Email already registered.' });
    }

    const existingUser = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'A user login is already registered with this email.' });
    }

    // Create Faculty record
    const result = await db.query(
      `INSERT INTO faculty (
        faculty_id, name, email, phone, gender, department_id, 
        qualification, designation, joining_date, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [faculty_id, name, email, phone, gender, department_id, qualification, designation, joining_date, status]
    );

    // Create user login account
    const defaultPassword = 'faculty123';
    const hashedPassword = await bcrypt.hash(defaultPassword, 10);
    const username = email.split('@')[0];

    await db.query(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, 'Faculty']
    );

    res.status(201).json({
      message: 'Faculty member added successfully',
      facultyId: result.insertId
    });

  } catch (err) {
    console.error('Create faculty error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/faculty/:id - Update faculty details (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const {
    faculty_id, name, email, phone, gender, department_id,
    qualification, designation, joining_date, status
  } = req.body;

  try {
    // Check if faculty exists
    const currentRows = await db.query('SELECT * FROM faculty WHERE id = ?', [id]);
    if (currentRows.length === 0) {
      return res.status(404).json({ message: 'Faculty record not found.' });
    }
    const currentFaculty = currentRows[0];

    // Validate uniqueness of ID/Email if changed
    if (faculty_id !== currentFaculty.faculty_id || email !== currentFaculty.email) {
      const uniquenessCheck = await db.query(
        'SELECT id FROM faculty WHERE (faculty_id = ? OR email = ?) AND id != ?',
        [faculty_id, email, id]
      );
      if (uniquenessCheck.length > 0) {
        return res.status(400).json({ message: 'Faculty ID or Email already assigned to another staff member.' });
      }
    }

    // Update faculty table
    await db.query(
      `UPDATE faculty 
       SET faculty_id = ?, name = ?, email = ?, phone = ?, gender = ?, department_id = ?, 
           qualification = ?, designation = ?, joining_date = ?, status = ?
       WHERE id = ?`,
      [faculty_id, name, email, phone, gender, department_id, qualification, designation, joining_date, status, id]
    );

    // Keep user email in sync
    if (email !== currentFaculty.email) {
      await db.query(
        'UPDATE users SET email = ?, username = ? WHERE email = ?',
        [email, email.split('@')[0], currentFaculty.email]
      );
    }

    res.json({ message: 'Faculty updated successfully' });

  } catch (err) {
    console.error('Update faculty error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/faculty/:id - Delete faculty member (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const faculty = await db.query('SELECT email FROM faculty WHERE id = ?', [id]);
    if (faculty.length === 0) {
      return res.status(404).json({ message: 'Faculty record not found.' });
    }

    const { email } = faculty[0];

    // Delete faculty (marks/attendance will cascaded clean-up if linked, but usually subjects references this ID. Set to null)
    await db.query('DELETE FROM faculty WHERE id = ?', [id]);

    // Delete login account
    await db.query('DELETE FROM users WHERE email = ?', [email]);

    res.json({ message: 'Faculty deleted successfully' });

  } catch (err) {
    console.error('Delete faculty error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
