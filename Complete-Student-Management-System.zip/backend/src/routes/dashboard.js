const express = require('express');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard/stats - Custom dashboard content based on roles
router.get('/stats', authenticateToken, async (req, res) => {
  const { role, email } = req.user;

  try {
    if (role === 'Admin') {
      // 1. Total statistics
      const studentCount = await db.query('SELECT COUNT(*) as total FROM students');
      const facultyCount = await db.query('SELECT COUNT(*) as total FROM faculty');
      const departmentCount = await db.query('SELECT COUNT(*) as total FROM departments');
      const courseCount = await db.query('SELECT COUNT(*) as total FROM courses');

      // 2. Chart data: Students by department
      const studentsByDept = await db.query(
        `SELECT d.department_code as name, COUNT(s.id) as value 
         FROM departments d 
         LEFT JOIN students s ON s.department_id = d.id 
         GROUP BY d.id, d.department_code`
      );

      // 3. Chart data: Gender distribution
      const genderDistribution = await db.query(
        `SELECT gender as name, COUNT(*) as value 
         FROM students 
         GROUP BY gender`
      );

      // 4. Chart data: Overall Attendance Overview (Present vs Absent)
      const attendanceOverview = await db.query(
        `SELECT status as name, COUNT(*) as value 
         FROM attendance 
         GROUP BY status`
      );

      // 5. Recent activities
      const recentStudents = await db.query(
        `SELECT student_id, first_name, last_name, admission_date, status
         FROM students 
         ORDER BY id DESC LIMIT 5`
      );

      const recentAttendance = await db.query(
        `SELECT a.date, s.first_name, s.last_name, sub.subject_name, a.status 
         FROM attendance a 
         JOIN students s ON a.student_id = s.id 
         JOIN subjects sub ON a.subject_id = sub.id 
         ORDER BY a.id DESC LIMIT 5`
      );

      const recentMarks = await db.query(
        `SELECT m.created_at, s.first_name, s.last_name, sub.subject_name, m.exam_type, m.marks, m.max_marks 
         FROM marks m 
         JOIN students s ON m.student_id = s.id 
         JOIN subjects sub ON m.subject_id = sub.id 
         ORDER BY m.id DESC LIMIT 5`
      );

      res.json({
        stats: {
          totalStudents: studentCount[0].total,
          totalFaculty: facultyCount[0].total,
          totalDepartments: departmentCount[0].total,
          totalCourses: courseCount[0].total
        },
        charts: {
          studentsByDept,
          genderDistribution,
          attendanceOverview
        },
        recentActivity: {
          recentStudents,
          recentAttendance,
          recentMarks
        }
      });

    } else if (role === 'Faculty') {
      // Find faculty details first
      const facultyRows = await db.query('SELECT * FROM faculty WHERE email = ?', [email]);
      if (facultyRows.length === 0) {
        return res.status(404).json({ message: 'Faculty profile not found.' });
      }
      const faculty = facultyRows[0];

      // 1. Total assigned subjects
      const subjectsCount = await db.query('SELECT COUNT(*) as total FROM subjects WHERE faculty_id = ?', [faculty.id]);

      // 2. Total students under taught courses
      const studentsCount = await db.query(
        `SELECT COUNT(DISTINCT s.id) as total 
         FROM students s
         JOIN subjects sub ON s.course_id = sub.course_id AND s.semester = sub.semester
         WHERE sub.faculty_id = ?`,
        [faculty.id]
      );

      // 3. Fetch subjects list with courses
      const assignedSubjects = await db.query(
        `SELECT sub.*, c.course_name, d.department_name
         FROM subjects sub
         LEFT JOIN courses c ON sub.course_id = c.id
         LEFT JOIN departments d ON sub.department_id = d.id
         WHERE sub.faculty_id = ?`,
         [faculty.id]
      );

      // 4. Fetch recent class attendance entries
      const recentAttendanceMarked = await db.query(
        `SELECT a.date, sub.subject_name, sub.subject_code, 
                COUNT(a.id) as total_students,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count
         FROM attendance a
         JOIN subjects sub ON a.subject_id = sub.id
         WHERE a.faculty_id = ?
         GROUP BY a.date, sub.id
         ORDER BY a.date DESC LIMIT 5`,
        [faculty.id]
      );

      // 5. Recent marks entries
      const recentMarksEntered = await db.query(
        `SELECT m.created_at, s.first_name, s.last_name, sub.subject_name, m.exam_type, m.marks, m.max_marks 
         FROM marks m 
         JOIN students s ON m.student_id = s.id 
         JOIN subjects sub ON m.subject_id = sub.id 
         WHERE sub.faculty_id = ?
         ORDER BY m.id DESC LIMIT 5`,
         [faculty.id]
      );

      res.json({
        profile: faculty,
        stats: {
          totalSubjects: subjectsCount[0].total,
          totalStudents: studentsCount[0].total
        },
        assignedSubjects,
        recentActivity: {
          recentAttendanceMarked,
          recentMarksEntered
        }
      });

    } else if (role === 'Student') {
      // Find student details first
      const studentRows = await db.query(
        `SELECT s.*, c.course_name, d.department_name 
         FROM students s
         LEFT JOIN courses c ON s.course_id = c.id
         LEFT JOIN departments d ON s.department_id = d.id
         WHERE s.email = ?`,
        [email]
      );
      if (studentRows.length === 0) {
        return res.status(404).json({ message: 'Student profile not found.' });
      }
      const student = studentRows[0];

      // 1. Total subjects in current semester
      const subjectsCount = await db.query(
        'SELECT COUNT(*) as total FROM subjects WHERE course_id = ? AND semester = ?',
        [student.course_id, student.semester]
      );

      // 2. Attendance stats
      const attendanceRows = await db.query(
        `SELECT 
           COUNT(id) as total,
           SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present
         FROM attendance 
         WHERE student_id = ?`,
        [student.id]
      );
      const totalClasses = attendanceRows[0].total || 0;
      const presentClasses = attendanceRows[0].present || 0;
      const attendancePercentage = totalClasses > 0 ? ((presentClasses / totalClasses) * 100).toFixed(1) : '100.0';

      // 3. Marks statistics (final exams only)
      const finalMarks = await db.query(
        `SELECT m.*, sub.subject_name, sub.subject_code, sub.credits
         FROM marks m
         JOIN subjects sub ON m.subject_id = sub.id
         WHERE m.student_id = ? AND m.exam_type = 'Final'`,
        [student.id]
      );
      
      let earnedPoints = 0;
      let totalCredits = 0;
      let totalMarksGot = 0;
      let totalMaxMarks = 0;

      finalMarks.forEach(m => {
        let gp = 0;
        if (m.grade === 'A+') gp = 10;
        else if (m.grade === 'A') gp = 9;
        else if (m.grade === 'B+') gp = 8;
        else if (m.grade === 'B') gp = 7;
        else if (m.grade === 'C') gp = 6;
        else if (m.grade === 'D') gp = 5;

        earnedPoints += gp * (m.credits || 4);
        totalCredits += (m.credits || 4);
        totalMarksGot += m.marks;
        totalMaxMarks += m.max_marks;
      });

      const cgpa = totalCredits > 0 ? (earnedPoints / totalCredits).toFixed(2) : '0.00';
      const averageMarksPercent = totalMaxMarks > 0 ? ((totalMarksGot / totalMaxMarks) * 100).toFixed(1) : '0.0';

      // Subject-wise marks chart data
      const subjectMarksChart = finalMarks.map(m => ({
        subject: m.subject_code,
        marks: parseFloat(((m.marks / m.max_marks) * 100).toFixed(1))
      }));

      // Attendance by subject chart data
      const attendanceBySubject = await db.query(
        `SELECT 
          sub.subject_code as name,
          COUNT(a.id) as total_classes,
          SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present_count
         FROM subjects sub
         LEFT JOIN attendance a ON sub.id = a.subject_id AND a.student_id = ?
         WHERE sub.course_id = ? AND sub.semester = ?
         GROUP BY sub.id, sub.subject_code`,
        [student.id, student.course_id, student.semester]
      );

      const attendanceChart = attendanceBySubject.map(item => ({
        subject: item.name,
        percentage: item.total_classes > 0 ? parseFloat(((item.present_count / item.total_classes) * 100).toFixed(1)) : 100.0
      }));

      res.json({
        profile: student,
        stats: {
          totalSubjects: subjectsCount[0].total,
          attendancePercentage: parseFloat(attendancePercentage),
          averageMarks: parseFloat(averageMarksPercent),
          cgpa: parseFloat(cgpa)
        },
        charts: {
          subjectMarksChart,
          attendanceChart
        }
      });
    }
  } catch (err) {
    console.error('Fetch dashboard stats error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
