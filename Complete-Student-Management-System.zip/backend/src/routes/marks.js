const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// Helper function to calculate letter grade based on marks percentage
function calculateGrade(marks, maxMarks) {
  if (!maxMarks || maxMarks <= 0) return 'F';
  const percentage = (marks / maxMarks) * 100;
  
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B+';
  if (percentage >= 60) return 'B';
  if (percentage >= 50) return 'C';
  if (percentage >= 40) return 'D';
  return 'F';
}

// GET /api/marks - Fetch marks list for input or viewing
// Query: course_id, semester, subject_id, exam_type
router.get('/', authenticateToken, authorize('Admin', 'Faculty', 'Student'), async (req, res) => {
  const { course_id, semester, subject_id, exam_type } = req.query;

  if (req.user.role === 'Student') {
    // Return all grades for the logged in student
    try {
      const studentResult = await db.query('SELECT id FROM students WHERE email = ?', [req.user.email]);
      if (studentResult.length === 0) {
        return res.status(404).json({ message: 'Student profile not found.' });
      }
      const studentId = studentResult[0].id;

      const myGrades = await db.query(
        `SELECT m.*, sub.subject_name, sub.subject_code, sub.credits
         FROM marks m
         JOIN subjects sub ON m.subject_id = sub.id
         WHERE m.student_id = ?
         ORDER BY sub.id ASC, m.created_at ASC`,
        [studentId]
      );
      return res.json(myGrades);
    } catch (err) {
      console.error('Fetch student self-grades error:', err.message);
      return res.status(500).json({ message: 'Internal server error.' });
    }
  }

  // Admin and Faculty flow
  if (!course_id || !semester || !subject_id || !exam_type) {
    return res.status(400).json({ message: 'course_id, semester, subject_id, and exam_type are required.' });
  }

  try {
    // 1. Fetch grades already entered
    const enteredGrades = await db.query(
      `SELECT s.id as student_id, s.first_name, s.last_name, s.roll_number, s.student_id as student_code, 
              m.marks, m.max_marks, m.grade, m.id as mark_id
       FROM students s
       JOIN marks m ON s.id = m.student_id
       WHERE m.subject_id = ? AND m.exam_type = ? AND s.course_id = ? AND s.semester = ?`,
      [parseInt(subject_id), exam_type, parseInt(course_id), parseInt(semester)]
    );

    if (enteredGrades.length > 0) {
      return res.json({
        entered: true,
        records: enteredGrades
      });
    }

    // 2. Fetch students who don't have marks entered yet
    const students = await db.query(
      `SELECT id as student_id, first_name, last_name, roll_number, student_id as student_code, 
              0 as marks, 100 as max_marks, '' as grade
       FROM students
       WHERE course_id = ? AND semester = ? AND status = 'Active'`,
      [parseInt(course_id), parseInt(semester)]
    );

    res.json({
      entered: false,
      records: students
    });

  } catch (err) {
    console.error('Fetch marks list error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/marks - Save/Update Marks (Faculty and Admin only)
router.post('/', authenticateToken, authorize('Admin', 'Faculty'), async (req, res) => {
  const { course_id, semester, subject_id, exam_type, records } = req.body;
  // records: Array of { student_id, marks, max_marks }

  if (!course_id || !semester || !subject_id || !exam_type || !records || !Array.isArray(records)) {
    return res.status(400).json({ message: 'Missing required parameters or records list.' });
  }

  try {
    const studentIds = records.map(r => r.student_id);
    
    if (studentIds.length > 0) {
      // Delete existing marks logs for this subject, exam type, and students to update/overwrite cleanly
      const placeholders = studentIds.map(() => '?').join(',');
      const deleteSql = `DELETE FROM marks WHERE subject_id = ? AND exam_type = ? AND student_id IN (${placeholders})`;
      await db.query(deleteSql, [parseInt(subject_id), exam_type, ...studentIds]);

      // Bulk insert new records with auto-calculated grades
      for (const r of records) {
        const grade = calculateGrade(parseFloat(r.marks), parseFloat(r.max_marks));
        await db.query(
          'INSERT INTO marks (student_id, subject_id, exam_type, marks, max_marks, grade) VALUES (?, ?, ?, ?, ?, ?)',
          [parseInt(r.student_id), parseInt(subject_id), exam_type, parseFloat(r.marks), parseFloat(r.max_marks), grade]
        );
      }
    }

    res.json({ message: 'Marks updated successfully' });

  } catch (err) {
    console.error('Save marks error:', err.message);
    res.status(500).json({ message: 'Failed to update student marks.' });
  }
});

module.exports = router;
