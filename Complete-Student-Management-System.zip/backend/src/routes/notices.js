const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/notices - List notices filtered by user role
router.get('/', authenticateToken, async (req, res) => {
  const role = req.user.role;
  let sql = 'SELECT * FROM notices';
  const params = [];

  if (role === 'Student') {
    sql += " WHERE target = 'Student' OR target = 'All'";
  } else if (role === 'Faculty') {
    sql += " WHERE target = 'Faculty' OR target = 'All'";
  }
  // Admin sees all

  sql += ' ORDER BY id DESC';

  try {
    const notices = await db.query(sql, params);
    res.json(notices);
  } catch (err) {
    console.error('List notices error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/notices - Create a notice (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const { title, description, target = 'All', priority = 'Normal' } = req.body;

  if (!title || !description) {
    return res.status(400).json({ message: 'Title and description are required.' });
  }

  try {
    const result = await db.query(
      'INSERT INTO notices (title, description, target, priority) VALUES (?, ?, ?, ?)',
      [title, description, target, priority]
    );

    res.status(201).json({
      message: 'Notice added successfully',
      noticeId: result.insertId
    });
  } catch (err) {
    console.error('Create notice error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/notices/:id - Update a notice (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const { title, description, target, priority } = req.body;

  try {
    const current = await db.query('SELECT * FROM notices WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Notice not found.' });
    }

    await db.query(
      'UPDATE notices SET title = ?, description = ?, target = ?, priority = ? WHERE id = ?',
      [title, description, target, priority, id]
    );

    res.json({ message: 'Notice updated successfully' });
  } catch (err) {
    console.error('Update notice error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/notices/:id - Delete a notice (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const current = await db.query('SELECT * FROM notices WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Notice not found.' });
    }

    await db.query('DELETE FROM notices WHERE id = ?', [id]);
    res.json({ message: 'Notice deleted successfully' });
  } catch (err) {
    console.error('Delete notice error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
