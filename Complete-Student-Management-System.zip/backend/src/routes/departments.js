const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/departments - Get all departments with counts of students and faculty
router.get('/', authenticateToken, async (req, res) => {
  try {
    const sql = `
      SELECT d.*, 
        (SELECT COUNT(*) FROM students s WHERE s.department_id = d.id) as student_count,
        (SELECT COUNT(*) FROM faculty f WHERE f.department_id = d.id) as faculty_count
      FROM departments d
      ORDER BY d.id ASC
    `;
    const departments = await db.query(sql);
    res.json(departments);
  } catch (err) {
    console.error('List departments error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/departments - Add department (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const { department_name, department_code, hod } = req.body;

  if (!department_name || !department_code) {
    return res.status(400).json({ message: 'Department name and code are required.' });
  }

  try {
    const existing = await db.query('SELECT id FROM departments WHERE department_code = ?', [department_code]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Department code already exists.' });
    }

    const result = await db.query(
      'INSERT INTO departments (department_name, department_code, hod) VALUES (?, ?, ?)',
      [department_name, department_code, hod || '']
    );

    res.status(201).json({
      message: 'Department created successfully',
      departmentId: result.insertId
    });
  } catch (err) {
    console.error('Create department error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/departments/:id - Update department (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const { department_name, department_code, hod } = req.body;

  try {
    const current = await db.query('SELECT * FROM departments WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Department not found.' });
    }

    if (department_code !== current[0].department_code) {
      const existing = await db.query('SELECT id FROM departments WHERE department_code = ? AND id != ?', [department_code, id]);
      if (existing.length > 0) {
        return res.status(400).json({ message: 'Department code already in use.' });
      }
    }

    await db.query(
      'UPDATE departments SET department_name = ?, department_code = ?, hod = ? WHERE id = ?',
      [department_name, department_code, hod || '', id]
    );

    res.json({ message: 'Department updated successfully' });
  } catch (err) {
    console.error('Update department error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/departments/:id - Delete department (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const current = await db.query('SELECT * FROM departments WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Department not found.' });
    }

    // Courses and subjects linked to this department will cascade delete (defined in foreign keys)
    await db.query('DELETE FROM departments WHERE id = ?', [id]);
    res.json({ message: 'Department deleted successfully' });
  } catch (err) {
    console.error('Delete department error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
