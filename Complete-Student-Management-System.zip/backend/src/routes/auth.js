const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    // 1. Fetch user by email or username
    const users = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, email]);
    if (users.length === 0) {
      return res.status(401).json({ message: 'Invalid email/username or password.' });
    }

    const user = users[0];

    // 2. Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email/username or password.' });
    }

    // 3. Generate token
    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'super_secret_jwt_key_123456',
      { expiresIn: '24h' }
    );

    // 4. Fetch specific profile details based on role
    let profile = null;
    if (user.role === 'Student') {
      const studentDetails = await db.query(
        `SELECT s.*, c.course_name, d.department_name 
         FROM students s
         LEFT JOIN courses c ON s.course_id = c.id
         LEFT JOIN departments d ON s.department_id = d.id
         WHERE s.email = ?`,
        [user.email]
      );
      if (studentDetails.length > 0) profile = studentDetails[0];
    } else if (user.role === 'Faculty') {
      const facultyDetails = await db.query(
        `SELECT f.*, d.department_name 
         FROM faculty f
         LEFT JOIN departments d ON f.department_id = d.id
         WHERE f.email = ?`,
        [user.email]
      );
      if (facultyDetails.length > 0) profile = facultyDetails[0];
    }

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile
      }
    });
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ message: 'Internal server error during login.' });
  }
});

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { username, email, password, role } = req.body;

  if (!username || !email || !password || !role) {
    return res.status(400).json({ message: 'Username, email, password, and role are required.' });
  }

  try {
    // Check if user already exists
    const existing = await db.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, username]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Username or email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await db.query(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, role]
    );

    res.status(201).json({
      message: 'User registered successfully',
      userId: result.insertId
    });
  } catch (err) {
    console.error('Registration error:', err.message);
    res.status(500).json({ message: 'Internal server error during registration.' });
  }
});

// GET /api/auth/me (Get current user and refresh data)
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const users = await db.query('SELECT id, username, email, role, created_at FROM users WHERE id = ?', [req.user.id]);
    if (users.length === 0) {
      return res.status(404).json({ message: 'User not found.' });
    }
    const user = users[0];

    let profile = null;
    if (user.role === 'Student') {
      const studentDetails = await db.query(
        `SELECT s.*, c.course_name, d.department_name 
         FROM students s
         LEFT JOIN courses c ON s.course_id = c.id
         LEFT JOIN departments d ON s.department_id = d.id
         WHERE s.email = ?`,
        [user.email]
      );
      if (studentDetails.length > 0) profile = studentDetails[0];
    } else if (user.role === 'Faculty') {
      const facultyDetails = await db.query(
        `SELECT f.*, d.department_name 
         FROM faculty f
         LEFT JOIN departments d ON f.department_id = d.id
         WHERE f.email = ?`,
        [user.email]
      );
      if (facultyDetails.length > 0) profile = facultyDetails[0];
    }

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile
      }
    });
  } catch (err) {
    console.error('Me check error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/auth/change-password
router.put('/change-password', authenticateToken, async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ message: 'Current password and new password are required.' });
  }

  try {
    const userRows = await db.query('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (userRows.length === 0) {
      return res.status(404).json({ message: 'User not found.' });
    }

    const user = userRows[0];
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Incorrect current password.' });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    await db.query('UPDATE users SET password = ? WHERE id = ?', [hashedNewPassword, user.id]);

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('Password change error:', err.message);
    res.status(500).json({ message: 'Failed to update password.' });
  }
});

module.exports = router;
