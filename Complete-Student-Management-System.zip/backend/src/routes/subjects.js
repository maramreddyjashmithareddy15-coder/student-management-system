const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/subjects - List all subjects with department, course, and assigned faculty
router.get('/', authenticateToken, async (req, res) => {
  try {
    const sql = `
      SELECT s.*, d.department_name, c.course_name, f.name as faculty_name 
      FROM subjects s
      LEFT JOIN departments d ON s.department_id = d.id
      LEFT JOIN courses c ON s.course_id = c.id
      LEFT JOIN faculty f ON s.faculty_id = f.id
      ORDER BY s.id ASC
    `;
    const subjects = await db.query(sql);
    res.json(subjects);
  } catch (err) {
    console.error('List subjects error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/subjects - Add subject (Admin only)
router.post('/', authenticateToken, authorize('Admin'), async (req, res) => {
  const { subject_name, subject_code, department_id, course_id, semester, credits, faculty_id } = req.body;

  if (!subject_name || !subject_code || !department_id || !course_id || !semester || !credits) {
    return res.status(400).json({ message: 'Subject name, code, department, course, semester, and credits are required.' });
  }

  try {
    const existing = await db.query('SELECT id FROM subjects WHERE subject_code = ?', [subject_code]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'Subject code already exists.' });
    }

    const result = await db.query(
      `INSERT INTO subjects (subject_name, subject_code, department_id, course_id, semester, credits, faculty_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [subject_name, subject_code, department_id, course_id, semester, credits, faculty_id || null]
    );

    res.status(201).json({
      message: 'Subject created successfully',
      subjectId: result.insertId
    });
  } catch (err) {
    console.error('Create subject error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// PUT /api/subjects/:id - Update subject / Assign to faculty (Admin only)
router.put('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;
  const { subject_name, subject_code, department_id, course_id, semester, credits, faculty_id } = req.body;

  try {
    const current = await db.query('SELECT * FROM subjects WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Subject not found.' });
    }

    if (subject_code !== current[0].subject_code) {
      const existing = await db.query('SELECT id FROM subjects WHERE subject_code = ? AND id != ?', [subject_code, id]);
      if (existing.length > 0) {
        return res.status(400).json({ message: 'Subject code already in use.' });
      }
    }

    await db.query(
      `UPDATE subjects 
       SET subject_name = ?, subject_code = ?, department_id = ?, course_id = ?, semester = ?, credits = ?, faculty_id = ? 
       WHERE id = ?`,
      [subject_name, subject_code, department_id, course_id, semester, credits, faculty_id || null, id]
    );

    res.json({ message: 'Subject updated successfully' });
  } catch (err) {
    console.error('Update subject error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// DELETE /api/subjects/:id - Delete subject (Admin only)
router.delete('/:id', authenticateToken, authorize('Admin'), async (req, res) => {
  const { id } = req.params;

  try {
    const current = await db.query('SELECT * FROM subjects WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ message: 'Subject not found.' });
    }

    await db.query('DELETE FROM subjects WHERE id = ?', [id]);
    res.json({ message: 'Subject deleted successfully' });
  } catch (err) {
    console.error('Delete subject error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

module.exports = router;
