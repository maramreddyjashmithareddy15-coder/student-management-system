const express = require('express');
const db = require('../config/db');
const { authenticateToken, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/attendance - Fetch attendance sheet for marking or viewing
// Query: course_id, semester, subject_id, date
router.get('/', authenticateToken, authorize('Admin', 'Faculty', 'Student'), async (req, res) => {
  const { course_id, semester, subject_id, date } = req.query;

  if (req.user.role === 'Student') {
    // Students can see only their own detailed attendance
    try {
      const studentResult = await db.query('SELECT id FROM students WHERE email = ?', [req.user.email]);
      if (studentResult.length === 0) {
        return res.status(404).json({ message: 'Student profile not found.' });
      }
      const studentId = studentResult[0].id;

      const myAttendance = await db.query(
        `SELECT a.*, sub.subject_name, sub.subject_code, f.name as faculty_name
         FROM attendance a
         JOIN subjects sub ON a.subject_id = sub.id
         LEFT JOIN faculty f ON a.faculty_id = f.id
         WHERE a.student_id = ?
         ORDER BY a.date DESC`,
        [studentId]
      );
      return res.json(myAttendance);
    } catch (err) {
      console.error('Fetch student self-attendance error:', err.message);
      return res.status(500).json({ message: 'Internal server error.' });
    }
  }

  // Admin and Faculty flow
  if (!course_id || !semester || !subject_id || !date) {
    return res.status(400).json({ message: 'course_id, semester, subject_id, and date are required parameters.' });
  }

  try {
    // 1. Check if attendance has already been marked for this subject and date
    const markedStudents = await db.query(
      `SELECT s.id as student_id, s.first_name, s.last_name, s.roll_number, s.student_id as student_code, a.status, a.id as attendance_id
       FROM students s
       JOIN attendance a ON s.id = a.student_id
       WHERE a.subject_id = ? AND a.date = ? AND s.course_id = ? AND s.semester = ?`,
      [parseInt(subject_id), date, parseInt(course_id), parseInt(semester)]
    );

    if (markedStudents.length > 0) {
      // Return the already marked sheet
      return res.json({
        marked: true,
        records: markedStudents
      });
    }

    // 2. If not marked, fetch all enrolled students in the course/semester
    const students = await db.query(
      `SELECT id as student_id, first_name, last_name, roll_number, student_id as student_code, 'Present' as status
       FROM students
       WHERE course_id = ? AND semester = ? AND status = 'Active'`,
      [parseInt(course_id), parseInt(semester)]
    );

    res.json({
      marked: false,
      records: students
    });

  } catch (err) {
    console.error('Fetch attendance sheet error:', err.message);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// POST /api/attendance - Bulk Save/Update Attendance (Faculty / Admin only)
router.post('/', authenticateToken, authorize('Admin', 'Faculty'), async (req, res) => {
  const { course_id, semester, subject_id, date, records } = req.body;
  // records: Array of { student_id, status }

  if (!course_id || !semester || !subject_id || !date || !records || !Array.isArray(records)) {
    return res.status(400).json({ message: 'Missing required fields or records list.' });
  }

  try {
    // Get faculty_id from current user if they are Faculty
    let facultyId = null;
    if (req.user.role === 'Faculty') {
      const facultyRows = await db.query('SELECT id FROM faculty WHERE email = ?', [req.user.email]);
      if (facultyRows.length > 0) {
        facultyId = facultyRows[0].id;
      }
    }
    
    // If Admin marks attendance, fetch the faculty assigned to this subject
    if (!facultyId) {
      const subjectRows = await db.query('SELECT faculty_id FROM subjects WHERE id = ?', [subject_id]);
      if (subjectRows.length > 0) {
        facultyId = subjectRows[0].faculty_id || 1; // Fallback to first faculty if none assigned
      } else {
        facultyId = 1;
      }
    }

    // 1. Delete existing attendance logs for this subject, date, and students to overwrite cleanly
    const studentIds = records.map(r => r.student_id);
    if (studentIds.length > 0) {
      // Build placeholder parameters
      const placeholders = studentIds.map(() => '?').join(',');
      const deleteSql = `DELETE FROM attendance WHERE subject_id = ? AND date = ? AND student_id IN (${placeholders})`;
      await db.query(deleteSql, [parseInt(subject_id), date, ...studentIds]);
      
      // 2. Bulk insert new logs
      for (const r of records) {
        await db.query(
          'INSERT INTO attendance (student_id, subject_id, faculty_id, date, status) VALUES (?, ?, ?, ?, ?)',
          [parseInt(r.student_id), parseInt(subject_id), facultyId, date, r.status]
        );
      }
    }

    res.json({ message: 'Attendance saved successfully' });

  } catch (err) {
    console.error('Save attendance error:', err.message);
    res.status(500).json({ message: 'Failed to save attendance logs.' });
  }
});

module.exports = router;
