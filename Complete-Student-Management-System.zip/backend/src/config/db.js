const mysql = require('mysql2/promise');
const sqlite3 = require('sqlite3');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const dbType = (process.env.DB_TYPE || 'sqlite').toLowerCase();
let mysqlPool = null;
let sqliteDb = null;

// Connect to the appropriate database
async function initDatabase() {
  if (dbType === 'mysql') {
    console.log('Connecting to MySQL Database...');
    mysqlPool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'student_management',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    // Test connection
    try {
      const conn = await mysqlPool.getConnection();
      console.log('Successfully connected to MySQL server.');
      conn.release();
    } catch (err) {
      console.error('Failed to connect to MySQL server. Error:', err.message);
      console.error('Please verify MySQL is running and details in .env are correct.');
      throw err;
    }
  } else {
    console.log('Connecting to local SQLite Database...');
    const dbFile = path.resolve(__dirname, '..', '..', process.env.DB_FILE || 'database.sqlite');
    const dbDir = path.dirname(dbFile);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    const isNew = !fs.existsSync(dbFile);

    sqliteDb = new sqlite3.Database(dbFile, (err) => {
      if (err) {
        console.error('Failed to open SQLite database:', err.message);
      } else {
        console.log(`SQLite database opened successfully at ${dbFile}`);
        // Enable foreign key constraints
        sqliteDb.run('PRAGMA foreign_keys = ON;', (err) => {
          if (err) console.error('Failed to enable foreign keys in SQLite:', err.message);
        });
      }
    });

    if (isNew) {
      console.log('New SQLite database detected. Initializing schema...');
      try {
        const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sqlite.sql');
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');
        
        // Execute the schema statements
        await executeSqlScript(schemaSql);
        console.log('SQLite schema initialized successfully.');
      } catch (err) {
        console.error('Error initializing SQLite schema:', err.message);
      }
    }
  }
}

// Executes multi-statement SQL script for SQLite
function executeSqlScript(sqlText) {
  return new Promise((resolve, reject) => {
    sqliteDb.exec(sqlText, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

// Core promise-based query function compatible with both MySQL & SQLite
async function query(sql, params = []) {
  if (dbType === 'mysql') {
    if (!mysqlPool) {
      throw new Error('MySQL pool is not initialized. Call initDatabase() first.');
    }
    const [result] = await mysqlPool.query(sql, params);
    
    // Normalize response for INSERT/UPDATE
    if (result && result.insertId !== undefined) {
      return { insertId: result.insertId, affectedRows: result.affectedRows };
    }
    return result;
  } else {
    if (!sqliteDb) {
      throw new Error('SQLite database is not initialized. Call initDatabase() first.');
    }
    return new Promise((resolve, reject) => {
      // Normalize parameter styles if needed, SQLite natively supports ?
      const cleanSql = sql.trim();
      const isSelect = cleanSql.toLowerCase().startsWith('select') || 
                       cleanSql.toLowerCase().startsWith('with') ||
                       cleanSql.toLowerCase().startsWith('pragma');
                       
      if (isSelect) {
        sqliteDb.all(cleanSql, params, (err, rows) => {
          if (err) {
            console.error('SQLite Select Error: ', err.message, 'SQL:', cleanSql);
            reject(err);
          } else {
            resolve(rows);
          }
        });
      } else {
        sqliteDb.run(cleanSql, params, function (err) {
          if (err) {
            console.error('SQLite Run Error: ', err.message, 'SQL:', cleanSql);
            reject(err);
          } else {
            resolve({
              insertId: this.lastID,
              affectedRows: this.changes
            });
          }
        });
      }
    });
  }
}

module.exports = {
  initDatabase,
  query,
  dbType
};
