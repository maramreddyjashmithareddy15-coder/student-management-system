import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DashboardCard from '../components/DashboardCard';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  Users, UserCheck, Building2, BookOpen, 
  Calendar, Award, Plus, ArrowRight, UserPlus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, PieChart, Pie, Cell 
} from 'recharts';

const AdminDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchDashboardData = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/api/dashboard/stats');
      setData(response.data);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setError('Could not load administrative statistics from the server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  if (loading) return <Loading size="lg" className="min-h-[70vh]" />;
  if (error) return <ErrorMessage message={error} onRetry={fetchDashboardData} />;
  if (!data) return null;

  const { stats, charts, recentActivity } = data;

  // Chart Palettes
  const COLORS = ['#3b70ff', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];
  const GENDER_COLORS = ['#ec4899', '#3b70ff']; // Pink for female, Blue for male
  const ATTENDANCE_COLORS = ['#10b981', '#ef4444']; // Green for Present, Red for Absent

  return (
    <div className="space-y-8 page-transition">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Administrative Dashboard</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Real-time college operations and analytical summaries.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/students')}
            className="px-4 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-semibold rounded-2xl transition duration-150 flex items-center gap-2 shadow-md shadow-brand-500/10"
          >
            <UserPlus className="w-4 h-4" />
            Manage Students
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard
          title="Total Students"
          value={stats.totalStudents}
          icon={Users}
          colorClass="bg-brand-500"
          description="Enrolled in active courses"
        />
        <DashboardCard
          title="Total Faculty"
          value={stats.totalFaculty}
          icon={UserCheck}
          colorClass="bg-emerald-500"
          description="Academic staff members"
        />
        <DashboardCard
          title="Departments"
          value={stats.totalDepartments}
          icon={Building2}
          colorClass="bg-amber-500"
          description="Core academic departments"
        />
        <DashboardCard
          title="Total Courses"
          value={stats.totalCourses}
          icon={BookOpen}
          colorClass="bg-violet-500"
          description="Active degrees & programs"
        />
      </div>

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Students by Department */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Students by Department</h3>
          <div className="h-80">
            {charts.studentsByDept.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.studentsByDept}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ background: '#fff', borderRadius: '16px', border: '1px solid #f1f5f9', boxShadow: '0 4px 30px rgba(0,0,0,0.05)' }} 
                    labelClassName="font-bold text-slate-800"
                  />
                  <Bar dataKey="value" fill="#3b70ff" radius={[8, 8, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm">No department data available.</div>
            )}
          </div>
        </div>

        {/* Attendance Summary */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Attendance Summary (Overall)</h3>
          <div className="h-80 flex flex-col md:flex-row items-center justify-around gap-6">
            <div className="w-full md:w-1/2 h-full">
              {charts.attendanceOverview.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={charts.attendanceOverview}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {charts.attendanceOverview.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.name === 'Present' ? ATTENDANCE_COLORS[0] : ATTENDANCE_COLORS[1]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '16px' }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 text-sm">No logs found.</div>
              )}
            </div>
            
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Status Legend</h4>
              {charts.attendanceOverview.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.name === 'Present' ? ATTENDANCE_COLORS[0] : ATTENDANCE_COLORS[1] }}></div>
                  <span className="text-sm font-semibold text-slate-700">{item.name}: <span className="font-bold text-slate-800">{item.value} logs</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Gender Distribution */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Student Gender Distribution</h3>
          <div className="h-80 flex flex-col md:flex-row items-center justify-around gap-6">
            <div className="w-full md:w-1/2 h-full">
              {charts.genderDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={charts.genderDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {charts.genderDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.name === 'Female' ? GENDER_COLORS[0] : GENDER_COLORS[1]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '16px' }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 text-sm">No students data.</div>
              )}
            </div>
            
            <div className="space-y-4">
              <h4 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Demographics</h4>
              {charts.genderDistribution.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.name === 'Female' ? GENDER_COLORS[0] : GENDER_COLORS[1] }}></div>
                  <span className="text-sm font-semibold text-slate-700">{item.name}: <span className="font-bold text-slate-800">{item.value} students</span></span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Student Academic performance profile - MOCK distribution for visualizing admin grading */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Final Grades Spread</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[
                { grade: 'A+', count: 5 },
                { grade: 'A', count: 3 },
                { grade: 'B+', count: 4 },
                { grade: 'B', count: 3 },
                { grade: 'C', count: 2 },
                { grade: 'D', count: 1 },
                { grade: 'F', count: 1 }
              ]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="grade" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '16px' }} />
                <Bar dataKey="count" fill="#8b5cf6" radius={[8, 8, 0, 0]} barSize={35} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recently Added Students */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium flex flex-col">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Users className="w-4 h-4 text-brand-500" />
              Recent Students
            </h3>
            <button onClick={() => navigate('/students')} className="text-xs font-bold text-brand-500 hover:text-brand-600 flex items-center gap-1">
              View All <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-4 flex-1">
            {recentActivity.recentStudents.length > 0 ? (
              recentActivity.recentStudents.map((student, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-2xl hover:bg-slate-50 transition-colors">
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{student.first_name} {student.last_name}</h4>
                    <span className="text-xs text-slate-400 font-semibold">{student.student_id} • Enrolled</span>
                  </div>
                  <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-xl">
                    {student.admission_date}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No recent students.</p>
            )}
          </div>
        </div>

        {/* Recent Attendance Updates */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium flex flex-col">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-500" />
              Recent Attendance
            </h3>
          </div>
          <div className="space-y-4 flex-1">
            {recentActivity.recentAttendance.length > 0 ? (
              recentActivity.recentAttendance.map((log, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-2xl hover:bg-slate-50 transition-colors">
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{log.first_name} {log.last_name}</h4>
                    <span className="text-xs text-slate-400 font-semibold">{log.subject_name}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    log.status === 'Present' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
                  }`}>
                    {log.status}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No recent attendance logged.</p>
            )}
          </div>
        </div>

        {/* Recent Marks Updates */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium flex flex-col">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              Recent Marks
            </h3>
          </div>
          <div className="space-y-4 flex-1">
            {recentActivity.recentMarks.length > 0 ? (
              recentActivity.recentMarks.map((log, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-2xl hover:bg-slate-50 transition-colors">
                  <div className="truncate max-w-[180px]">
                    <h4 className="text-sm font-bold text-slate-800 truncate">{log.first_name} {log.last_name}</h4>
                    <span className="text-xs text-slate-400 font-semibold">{log.subject_name} • {log.exam_type}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-extrabold text-slate-800">{log.marks}/{log.max_marks}</span>
                    <span className="block text-[10px] font-bold text-brand-600 bg-brand-50 px-1.5 py-0.5 rounded-md text-center mt-0.5">
                      Grade {calculateLetter(log.marks, log.max_marks)}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No recent marks entered.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Quick calculation helper
function calculateLetter(marks, max) {
  if (!max || max <= 0) return 'F';
  const percent = (marks / max) * 100;
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B+';
  if (percent >= 60) return 'B';
  if (percent >= 50) return 'C';
  if (percent >= 40) return 'D';
  return 'F';
}

export default AdminDashboard;
