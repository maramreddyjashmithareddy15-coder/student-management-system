import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { GraduationCap, Lock, Mail, Eye, EyeOff } from 'lucide-react';
import Loading from '../components/Loading';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const [error, setError] = useState('');
  const [localLoading, setLocalLoading] = useState(false);

  const { loginUser } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }

    setLocalLoading(true);
    try {
      const loggedUser = await loginUser(email, password);
      
      // Role-based routing
      if (loggedUser.role === 'Admin') {
        navigate('/admin-dashboard');
      } else if (loggedUser.role === 'Faculty') {
        navigate('/faculty-dashboard');
      } else if (loggedUser.role === 'Student') {
        navigate('/student-dashboard');
      } else {
        setError('Unknown user role. Please contact administrator.');
      }
    } catch (err) {
      console.error('Login submit error:', err);
      if (err.response && err.response.data) {
        setError(err.response.data.message || 'Invalid credentials. Please try again.');
      } else {
        setError('Connection to server failed. Ensure the backend is running.');
      }
    } finally {
      setLocalLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 relative overflow-hidden px-4">
      {/* Decorative premium gradients */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-brand-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-brand-850 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>

      {/* Login Card */}
      <div className="bg-slate-900 border border-slate-800 p-8 sm:p-10 rounded-[32px] w-full max-w-md shadow-2xl relative z-10 text-white page-transition">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-brand-600/10 text-brand-500 flex items-center justify-center rounded-3xl mx-auto mb-4 border border-brand-500/20 shadow-inner">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight text-white">CAMPUS<span className="text-brand-500">LINK</span></h2>
          <p className="text-xs text-slate-400 font-semibold tracking-wider uppercase mt-1">Student Management System</p>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="p-4 bg-red-950/40 border border-red-500/30 rounded-2xl mb-6 text-sm text-red-400 font-medium">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">
              Email or Username
            </label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="text"
                placeholder="admin@college.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3.5 bg-slate-950/60 border border-slate-800 focus:border-brand-500 text-white placeholder-slate-600 rounded-2xl outline-none transition-colors duration-200 text-sm font-semibold"
                disabled={localLoading}
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-12 py-3.5 bg-slate-950/60 border border-slate-800 focus:border-brand-500 text-white placeholder-slate-600 rounded-2xl outline-none transition-colors duration-200 text-sm font-semibold"
                disabled={localLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                disabled={localLoading}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Remember Me / Forgot Pass */}
          <div className="flex items-center justify-between text-xs font-bold">
            <label className="flex items-center gap-2 text-slate-400 hover:text-slate-300 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={() => setRememberMe(!rememberMe)}
                className="w-4 h-4 accent-brand-500 rounded bg-slate-950 border-slate-800"
                disabled={localLoading}
              />
              Remember Me
            </label>
            
            <button
              type="button"
              onClick={() => alert('Demo account reset: Use the default credentials admin@college.com / admin123')}
              className="text-brand-500 hover:text-brand-400"
              disabled={localLoading}
            >
              Forgot Password?
            </button>
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-4 bg-brand-500 hover:bg-brand-600 active:scale-98 text-white font-bold rounded-2xl transition-all duration-200 shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2"
            disabled={localLoading}
          >
            {localLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        {/* Demo Credentials Box */}
        <div className="mt-8 pt-6 border-t border-slate-800 text-center">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Demo Credentials</h4>
          <div className="space-y-2 text-xs font-semibold text-slate-400">
            <p>Admin: <span className="text-slate-200">admin@college.com</span> / <span className="text-slate-200">admin123</span></p>
            <p>Faculty: <span className="text-slate-200">faculty@college.com</span> / <span className="text-slate-200">faculty123</span></p>
            <p>Student: <span className="text-slate-200">student@college.com</span> / <span className="text-slate-200">student123</span></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
