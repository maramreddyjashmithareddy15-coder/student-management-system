import React, { useState, useEffect } from 'react';
import api from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { FileSpreadsheet, Printer, Download, Filter, Search, BarChart2 } from 'lucide-react';

const Reports = () => {
  const [reportType, setReportType] = useState('students'); // students, attendance, marks, departments, faculty
  
  // Parameter dropdowns
  const [departments, setDepartments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [subjects, setSubjects] = useState([]);

  // Filter selections
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedSemester, setSelectedSemester] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedExam, setSelectedExam] = useState('Final');
  
  // Results
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 1. Fetch dropdown options on mount
  useEffect(() => {
    const fetchParams = async () => {
      try {
        const dRes = await api.get('/api/departments');
        setDepartments(dRes.data);
        const cRes = await api.get('/api/courses');
        setCourses(cRes.data);
        const sRes = await api.get('/api/subjects');
        setSubjects(sRes.data);
      } catch (err) {
        console.error('Failed to load reports filters:', err);
      }
    };
    fetchParams();
  }, []);

  // 2. Fetch records based on selections
  const generateReport = async (e) => {
    if (e) e.preventDefault();
    setLoading(true);
    setError('');
    setRecords([]);

    try {
      if (reportType === 'students') {
        const response = await api.get('/api/students', {
          params: { department_id: selectedDept, course_id: selectedCourse, semester: selectedSemester, limit: 100 }
        });
        setRecords(response.data.students);
      } else if (reportType === 'faculty') {
        const response = await api.get('/api/faculty', {
          params: { department_id: selectedDept }
        });
        setRecords(response.data);
      } else if (reportType === 'departments') {
        const response = await api.get('/api/departments');
        setRecords(response.data);
      } else if (reportType === 'attendance') {
        if (!selectedCourse || !selectedSemester || !selectedSubject) {
          throw new Error('Course, Semester, and Subject are required for Attendance Reports.');
        }
        const response = await api.get('/api/attendance', {
          params: { course_id: selectedCourse, semester: selectedSemester, subject_id: selectedSubject, date: new Date().toISOString().split('T')[0] }
        });
        setRecords(response.data.records || []);
      } else if (reportType === 'marks') {
        if (!selectedCourse || !selectedSemester || !selectedSubject || !selectedExam) {
          throw new Error('Course, Semester, Subject, and Exam Component are required for Marks Reports.');
        }
        const response = await api.get('/api/marks', {
          params: { course_id: selectedCourse, semester: selectedSemester, subject_id: selectedSubject, exam_type: selectedExam }
        });
        setRecords(response.data.records || []);
      }
    } catch (err) {
      console.error('Failed to compile report:', err);
      setError(err.message || 'Failed to fetch report records. Fill filters and try again.');
    } finally {
      setLoading(false);
    }
  };

  // 3. Pure Javascript Client-side CSV Exporter
  const handleCSVExport = () => {
    if (records.length === 0) return;

    let headers = [];
    let filename = `report_${reportType}`;

    if (reportType === 'students') {
      headers = [
        { label: 'Student ID', key: 'student_id' },
        { label: 'Roll Number', key: 'roll_number' },
        { label: 'First Name', key: 'first_name' },
        { label: 'Last Name', key: 'last_name' },
        { label: 'Email', key: 'email' },
        { label: 'Course', key: 'course_name' },
        { label: 'Semester', key: 'semester' },
        { label: 'Admission Date', key: 'admission_date' },
        { label: 'Status', key: 'status' }
      ];
    } else if (reportType === 'faculty') {
      headers = [
        { label: 'Faculty ID', key: 'faculty_id' },
        { label: 'Name', key: 'name' },
        { label: 'Email', key: 'email' },
        { label: 'Department', key: 'department_name' },
        { label: 'Designation', key: 'designation' },
        { label: 'Joining Date', key: 'joining_date' }
      ];
    } else if (reportType === 'departments') {
      headers = [
        { label: 'Code', key: 'department_code' },
        { label: 'Department Name', key: 'department_name' },
        { label: 'HOD Name', key: 'hod' },
        { label: 'Students Registered', key: 'student_count' },
        { label: 'Faculty Registered', key: 'faculty_count' }
      ];
    } else if (reportType === 'attendance') {
      headers = [
        { label: 'Roll Number', key: 'roll_number' },
        { label: 'Student ID', key: 'student_code' },
        { label: 'First Name', key: 'first_name' },
        { label: 'Last Name', key: 'last_name' },
        { label: 'Status', key: 'status' }
      ];
    } else if (reportType === 'marks') {
      headers = [
        { label: 'Roll Number', key: 'roll_number' },
        { label: 'Student ID', key: 'student_code' },
        { label: 'First Name', key: 'first_name' },
        { label: 'Last Name', key: 'last_name' },
        { label: 'Marks', key: 'marks' },
        { label: 'Max Marks', key: 'max_marks' },
        { label: 'Grade Letter', key: 'grade' }
      ];
    }

    // Build comma rows
    const headerRow = headers.map(h => h.label).join(',');
    const dataRows = records.map(row => 
      headers.map(h => {
        const val = row[h.key] || '';
        return `"${String(val).replace(/"/g, '""')}"`;
      }).join(',')
    );

    const csvContent = [headerRow, ...dataRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 page-transition print-area">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 no-print">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Report Generator</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Compile data and export academic spreadsheets or print formats.</p>
        </div>
        
        {records.length > 0 && (
          <div className="flex items-center gap-3">
            <button
              onClick={handleCSVExport}
              className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-sm font-bold border border-emerald-250 rounded-2xl transition duration-150 flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export CSV
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2.5 bg-brand-50 hover:bg-brand-100 text-brand-700 text-sm font-bold border border-brand-200 rounded-2xl transition duration-150 flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print Report
            </button>
          </div>
        )}
      </div>

      {/* Reports Selection Board */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium space-y-6 no-print">
        <div className="flex border-b border-slate-100 pb-3 overflow-x-auto gap-1">
          {[
            { id: 'students', label: 'Student Directory' },
            { id: 'attendance', label: 'Attendance Ledger' },
            { id: 'marks', label: 'Marks Card' },
            { id: 'departments', label: 'Departments List' },
            { id: 'faculty', label: 'Faculty Directory' }
          ].map(btn => (
            <button
              key={btn.id}
              onClick={() => {
                setReportType(btn.id);
                setRecords([]);
                setError('');
              }}
              className={`px-5 py-2.5 rounded-xl font-bold text-xs transition duration-150 shrink-0 ${
                reportType === btn.id 
                  ? 'bg-brand-500 text-white shadow-md shadow-brand-500/10' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>

        {/* Dynamic Filters form based on Report Type */}
        <form onSubmit={generateReport} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 items-end">
          {/* Dept Filter: Students, Faculty */}
          {(reportType === 'students' || reportType === 'faculty') && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Department</label>
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              >
                <option value="">All Departments</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.department_code}</option>
                ))}
              </select>
            </div>
          )}

          {/* Course filter: Students, Attendance, Marks */}
          {(reportType === 'students' || reportType === 'attendance' || reportType === 'marks') && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Course Program</label>
              <select
                value={selectedCourse}
                onChange={(e) => setSelectedCourse(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              >
                <option value="">All/Select Course</option>
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.course_code}</option>
                ))}
              </select>
            </div>
          )}

          {/* Semester: Students, Attendance, Marks */}
          {(reportType === 'students' || reportType === 'attendance' || reportType === 'marks') && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Semester</label>
              <select
                value={selectedSemester}
                onChange={(e) => setSelectedSemester(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              >
                <option value="">All/Select Semester</option>
                {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                  <option key={s} value={String(s)}>Semester {s}</option>
                ))}
              </select>
            </div>
          )}

          {/* Subject: Attendance, Marks */}
          {(reportType === 'attendance' || reportType === 'marks') && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Subject</label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              >
                <option value="">Select Subject</option>
                {subjects
                  .filter(sub => !selectedCourse || sub.course_id === parseInt(selectedCourse))
                  .map(s => (
                    <option key={s.id} value={s.id}>{s.subject_code} - {s.subject_name}</option>
                  ))
                }
              </select>
            </div>
          )}

          {/* Exam Component: Marks */}
          {reportType === 'marks' && (
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Exam Component</label>
              <select
                value={selectedExam}
                onChange={(e) => setSelectedExam(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              >
                <option value="Internal">Internal (20)</option>
                <option value="Midterm">Midterm (30)</option>
                <option value="Assignment">Assignment (10)</option>
                <option value="Practical">Practical (20)</option>
                <option value="Final">Final Examination (40)</option>
              </select>
            </div>
          )}

          {/* Action button */}
          <button
            type="submit"
            className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-2xl transition duration-150 shadow-md shadow-brand-500/10"
          >
            Compile Report
          </button>
        </form>
      </div>

      {/* Reports Display Sheet */}
      {loading ? (
        <Loading size="lg" className="min-h-[30vh]" />
      ) : error ? (
        <ErrorMessage message={error} />
      ) : records.length > 0 ? (
        <div className="bg-white border border-slate-100 rounded-[32px] p-8 shadow-premium print-card space-y-6">
          {/* Printable Header */}
          <div className="text-center border-b border-slate-200 pb-4">
            <h2 className="text-xl font-extrabold text-slate-800">CAMPUS LINK UNIVERSITY PORTAL</h2>
            <h3 className="text-sm font-bold text-brand-600 uppercase tracking-widest mt-1">
              Official Report: {reportType}
            </h3>
            <p className="text-[10px] text-slate-400 font-semibold mt-1">
              Compiled on: {new Date().toLocaleDateString()}
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b-2 border-slate-200 text-slate-500 text-xs font-extrabold uppercase tracking-wider">
                  {reportType === 'students' && (
                    <>
                      <th className="pb-3">ID</th>
                      <th className="pb-3">Roll No</th>
                      <th className="pb-3">Full Name</th>
                      <th className="pb-3">Email ID</th>
                      <th className="pb-3">Course</th>
                      <th className="pb-3 text-center">Semester</th>
                      <th className="pb-3 text-center">Status</th>
                    </>
                  )}
                  {reportType === 'faculty' && (
                    <>
                      <th className="pb-3">ID</th>
                      <th className="pb-3">Instructor Name</th>
                      <th className="pb-3">Email ID</th>
                      <th className="pb-3">Department</th>
                      <th className="pb-3">Designation</th>
                      <th className="pb-3">Joining Date</th>
                    </>
                  )}
                  {reportType === 'departments' && (
                    <>
                      <th className="pb-3">Code</th>
                      <th className="pb-3">Department Name</th>
                      <th className="pb-3">Head of Dept (HOD)</th>
                      <th className="pb-3 text-center">Students Enrolled</th>
                      <th className="pb-3 text-center">Faculty Assigned</th>
                    </>
                  )}
                  {reportType === 'attendance' && (
                    <>
                      <th className="pb-3">Roll No</th>
                      <th className="pb-3">Student ID</th>
                      <th className="pb-3">Full Name</th>
                      <th className="pb-3 text-center">Presence Status</th>
                    </>
                  )}
                  {reportType === 'marks' && (
                    <>
                      <th className="pb-3">Roll No</th>
                      <th className="pb-3">Student ID</th>
                      <th className="pb-3">Full Name</th>
                      <th className="pb-3 text-center">Score Card</th>
                      <th className="pb-3 text-center">Grade Letter</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-semibold">
                {records.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/20">
                    {reportType === 'students' && (
                      <>
                        <td className="py-3 text-brand-600 font-bold">{row.student_id}</td>
                        <td className="py-3 text-slate-500">{row.roll_number}</td>
                        <td className="py-3 text-slate-800">{row.first_name} {row.last_name}</td>
                        <td className="py-3">{row.email}</td>
                        <td className="py-3 text-xs text-slate-500 font-bold">{row.course_name}</td>
                        <td className="py-3 text-center">Sem {row.semester}</td>
                        <td className="py-3 text-center">
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-slate-100">{row.status}</span>
                        </td>
                      </>
                    )}
                    {reportType === 'faculty' && (
                      <>
                        <td className="py-3 text-brand-600 font-bold">{row.faculty_id}</td>
                        <td className="py-3 text-slate-800">{row.name}</td>
                        <td className="py-3">{row.email}</td>
                        <td className="py-3 text-xs text-slate-500 font-bold">{row.department_name}</td>
                        <td className="py-3">{row.designation}</td>
                        <td className="py-3 text-slate-500">{row.joining_date ? row.joining_date.split('T')[0] : ''}</td>
                      </>
                    )}
                    {reportType === 'departments' && (
                      <>
                        <td className="py-3 text-brand-600 font-bold">{row.department_code}</td>
                        <td className="py-3 text-slate-800">{row.department_name}</td>
                        <td className="py-3">{row.hod || 'Unassigned'}</td>
                        <td className="py-3 text-center">{row.student_count}</td>
                        <td className="py-3 text-center">{row.faculty_count}</td>
                      </>
                    )}
                    {reportType === 'attendance' && (
                      <>
                        <td className="py-3 text-slate-500">{row.roll_number}</td>
                        <td className="py-3 font-bold text-slate-800">{row.student_code}</td>
                        <td className="py-3 text-slate-800">{row.first_name} {row.last_name}</td>
                        <td className="py-3 text-center">
                          <span className={`text-xs font-bold uppercase px-2.5 py-1 rounded-lg ${
                            row.status === 'Present' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
                          }`}>
                            {row.status}
                          </span>
                        </td>
                      </>
                    )}
                    {reportType === 'marks' && (
                      <>
                        <td className="py-3 text-slate-500">{row.roll_number}</td>
                        <td className="py-3 font-bold text-slate-800">{row.student_code}</td>
                        <td className="py-3 text-slate-800">{row.first_name} {row.last_name}</td>
                        <td className="py-3 text-center font-extrabold text-slate-800">{row.marks}/{row.max_marks}</td>
                        <td className="py-3 text-center">
                          <span className="text-xs font-bold bg-slate-100 px-2 py-0.5 rounded">{row.grade}</span>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-100 p-12 text-center rounded-[32px] shadow-premium text-slate-400 no-print">
          <BarChart2 className="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-400" />
          <p className="text-sm font-semibold">Select parameters above and click 'Compile Report' to generate data summaries.</p>
        </div>
      )}
    </div>
  );
};

export default Reports;
