import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { Plus, Edit2, Trash2, Check, UserCheck } from 'lucide-react';

const Subjects = () => {
  const [subjects, setSubjects] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [faculty, setFaculty] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({
    subject_name: '', subject_code: '', department_id: '',
    course_id: '', semester: '1', credits: '4', faculty_id: ''
  });
  const [fieldErrors, setFieldErrors] = useState({});

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const subRes = await api.get('/api/subjects');
      setSubjects(subRes.data);

      const deptRes = await api.get('/api/departments');
      setDepartments(deptRes.data);

      const courseRes = await api.get('/api/courses');
      setCourses(courseRes.data);

      const facRes = await api.get('/api/faculty');
      setFaculty(facRes.data);
    } catch (err) {
      console.error('Failed to load subjects:', err);
      setError('Could not retrieve subjects data from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errors = {};
    if (!form.subject_name.trim()) errors.subject_name = 'Subject name is required.';
    if (!form.subject_code.trim()) errors.subject_code = 'Subject code is required (e.g. CS-301).';
    if (!form.department_id) errors.department_id = 'Department selection is required.';
    if (!form.course_id) errors.course_id = 'Course selection is required.';
    if (!form.semester || parseInt(form.semester) <= 0) errors.semester = 'Semester must be positive.';
    if (!form.credits || parseInt(form.credits) <= 0) errors.credits = 'Credits must be positive.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFieldErrors({});
    setForm({
      subject_name: '', subject_code: '', department_id: departments[0]?.id || '',
      course_id: courses[0]?.id || '', semester: '1', credits: '4', faculty_id: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (sub) => {
    setIsEditing(true);
    setEditId(sub.id);
    setFieldErrors({});
    setForm({
      subject_name: sub.subject_name,
      subject_code: sub.subject_code,
      department_id: sub.department_id || '',
      course_id: sub.course_id || '',
      semester: String(sub.semester),
      credits: String(sub.credits),
      faculty_id: sub.faculty_id || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (isEditing) {
        await api.put(`/api/subjects/${editId}`, form);
        setSuccessMsg('Subject updated successfully.');
      } else {
        await api.post('/api/subjects', form);
        setSuccessMsg('Subject created successfully.');
      }
      setIsModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit subject error:', err);
      alert(err.response?.data?.message || 'Failed to submit form.');
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you absolutely sure you want to delete subject "${name}"?\nWarning: This will delete all marks and attendance logs associated with this subject.`);
    if (!confirm) return;

    try {
      await api.delete(`/api/subjects/${id}`);
      setSuccessMsg('Subject deleted successfully.');
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete subject error:', err);
      alert(err.response?.data?.message || 'Failed to delete subject.');
    }
  };

  const headers = [
    { label: 'Code', key: 'subject_code', className: 'font-bold text-slate-800' },
    { label: 'Subject Name', key: 'subject_name' },
    { label: 'Department', key: 'department_name', className: 'text-xs text-slate-500 font-bold' },
    { label: 'Course Enrolled', key: 'course_name', className: 'text-xs text-slate-500 font-bold' },
    { label: 'Semester', render: (row) => `Sem ${row.semester}` },
    { label: 'Credits', render: (row) => <span className="bg-slate-100 px-2 py-0.5 rounded-lg text-xs font-bold text-slate-600">{row.credits}</span> },
    { label: 'Assigned Instructor', render: (row) => row.faculty_name || <span className="text-red-500 text-xs italic font-bold">Unassigned</span> },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit Details / Assign Faculty"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, row.subject_name)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete Subject"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 page-transition">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">University Subjects</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Manage subjects and assign classes to academic staff.</p>
        </div>
        <div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Subject
          </button>
        </div>
      </div>

      {/* Notification Bars */}
      {error && <ErrorMessage message={error} />}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Table grid */}
      <DataTable
        headers={headers}
        data={subjects}
        loading={loading}
        emptyMessage="No subjects registered. Get started by clicking 'Add Subject'."
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Modify Subject Structure' : 'Create New Subject'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Subject Code *</label>
              <input
                type="text"
                name="subject_code"
                placeholder="e.g. CS-301"
                value={form.subject_code}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${fieldErrors.subject_code ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                disabled={isEditing}
              />
              {fieldErrors.subject_code && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.subject_code}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Subject Name *</label>
              <input
                type="text"
                name="subject_name"
                placeholder="e.g. Data Structures and Algorithms"
                value={form.subject_name}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${fieldErrors.subject_name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
              />
              {fieldErrors.subject_name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.subject_name}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Department *</label>
              <select
                name="department_id"
                value={form.department_id}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${fieldErrors.department_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
              >
                <option value="">Select Department</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.department_name}</option>
                ))}
              </select>
              {fieldErrors.department_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.department_id}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Course Curriculum *</label>
              <select
                name="course_id"
                value={form.course_id}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${fieldErrors.course_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
              >
                <option value="">Select Course</option>
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.course_name}</option>
                ))}
              </select>
              {fieldErrors.course_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.course_id}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Semester (Target Semester) *</label>
              <select
                name="semester"
                value={form.semester}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                  <option key={s} value={String(s)}>Semester {s}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Subject Credits *</label>
              <input
                type="number"
                name="credits"
                value={form.credits}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${fieldErrors.credits ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
              />
              {fieldErrors.credits && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.credits}</p>}
            </div>

            <div className="md:col-span-2">
              <label className="text-xs font-bold text-slate-500 block mb-1 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-brand-500" />
                Assign Faculty / Instructor
              </label>
              <select
                name="faculty_id"
                value={form.faculty_id}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              >
                <option value="">Leave Unassigned (Pending)</option>
                {faculty.map(f => (
                  <option key={f.id} value={f.id}>{f.name} ({f.designation})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
            >
              {isEditing ? 'Save Changes' : 'Create Subject'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Subjects;
