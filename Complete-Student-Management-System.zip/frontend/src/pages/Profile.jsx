import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { changePassword } from '../services/auth';
import { User, Shield, Key, Check, AlertCircle } from 'lucide-react';

const Profile = () => {
  const { user } = useAuth();
  
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('Please fill in all password fields.');
      return;
    }

    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New password confirmation does not match.');
      return;
    }

    setLoading(true);
    try {
      await changePassword(currentPassword, newPassword);
      setSuccess('Your account password was updated successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      console.error('Password change submit error:', err);
      setError(err.response?.data?.message || 'Incorrect current password or server failure.');
    } finally {
      setLoading(false);
    }
  };

  // Get name to display based on profile or username
  const getUserDisplayName = () => {
    if (!user) return 'Guest User';
    if (user.role === 'Student' && user.profile) {
      return `${user.profile.first_name} ${user.profile.last_name}`;
    }
    if (user.role === 'Faculty' && user.profile) {
      return user.profile.name;
    }
    return user.username;
  };

  return (
    <div className="space-y-8 page-transition max-w-4xl mx-auto">
      {/* Title */}
      <div>
        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">My Profile</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">Manage your portal credentials and passwords.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        {/* Left Card: Account summary */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium text-center">
          <div className="w-20 h-20 bg-brand-500 text-white font-extrabold text-2xl flex items-center justify-center rounded-[20px] mx-auto mb-4 shadow-md shadow-brand-500/10">
            {user?.username ? user.username.slice(0, 2).toUpperCase() : 'US'}
          </div>
          
          <h3 className="text-lg font-bold text-slate-850 tracking-tight leading-tight">
            {getUserDisplayName()}
          </h3>
          <span className="text-[10px] font-extrabold text-brand-600 bg-brand-50 border border-brand-100 px-2.5 py-0.5 rounded-full inline-block mt-2 uppercase tracking-wider">
            {user?.role} Account
          </span>

          <div className="border-t border-slate-50 pt-4 mt-6 text-left text-xs font-semibold text-slate-500 space-y-3">
            <p>Username: <span className="text-slate-700 font-bold block mt-0.5">{user?.username}</span></p>
            <p>Authorized Email: <span className="text-slate-700 font-bold block mt-0.5">{user?.email}</span></p>
          </div>
        </div>

        {/* Right Cards: Password Change form */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium md:col-span-2 space-y-6">
          <h3 className="text-base font-bold text-slate-800 flex items-center gap-2 border-b border-slate-50 pb-3">
            <Key className="w-5 h-5 text-brand-500" />
            Security Credentials Update
          </h3>

          {success && (
            <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-sm">
              <Check className="w-5 h-5 text-emerald-600 shrink-0" />
              <span className="text-sm font-semibold">{success}</span>
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 border border-red-100 text-red-700 rounded-2xl flex items-center gap-3 shadow-sm">
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              <span className="text-sm font-semibold">{error}</span>
            </div>
          )}

          <form onSubmit={handlePasswordChange} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Current Password *</label>
              <input
                type="password"
                placeholder="Enter current password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                disabled={loading}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">New Password *</label>
              <input
                type="password"
                placeholder="At least 6 characters"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                disabled={loading}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Confirm New Password *</label>
              <input
                type="password"
                placeholder="Retype new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                disabled={loading}
              />
            </div>

            <div className="flex items-center justify-end pt-4">
              <button
                type="submit"
                className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold rounded-xl shadow-md shadow-brand-500/10 flex items-center justify-center gap-2 transition active:scale-95 text-sm"
                disabled={loading}
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  'Change Password'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;
