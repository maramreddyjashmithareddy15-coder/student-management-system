import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DashboardCard from '../components/DashboardCard';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  Library, Calendar, Award, GraduationCap, 
  Bell, AlertTriangle, ChevronRight, User 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, Legend 
} from 'recharts';

const StudentDashboard = () => {
  const [data, setData] = useState(null);
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    setError('');
    try {
      const statsResponse = await api.get('/api/dashboard/stats');
      setData(statsResponse.data);

      const noticesResponse = await api.get('/api/notices');
      setNotices(noticesResponse.data.slice(0, 5));
    } catch (err) {
      console.error('Failed to load student dashboard:', err);
      setError('Could not load student stats from the server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return <Loading size="lg" className="min-h-[70vh]" />;
  if (error) return <ErrorMessage message={error} onRetry={fetchData} />;
  if (!data) return null;

  const { profile, stats, charts } = data;

  const isLowAttendance = stats.attendancePercentage < 75;

  return (
    <div className="space-y-8 page-transition">
      {/* Welcome & Overview Header */}
      <div className="bg-slate-900 border border-slate-800 text-white p-8 rounded-[32px] shadow-2xl relative overflow-hidden">
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-brand-600/10 rounded-full blur-3xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="text-brand-400 text-xs font-bold uppercase tracking-widest bg-brand-500/10 border border-brand-500/20 px-3 py-1 rounded-xl">
              Student Portal
            </span>
            <h1 className="text-3xl font-extrabold text-white mt-3 tracking-tight">
              Hello, {profile.first_name} {profile.last_name}
            </h1>
            <p className="text-sm text-slate-400 font-medium mt-1">
              Roll No: {profile.roll_number} • ID: {profile.student_id} • Semester {profile.semester}
            </p>
            <p className="text-xs text-slate-500 font-semibold mt-1 uppercase tracking-wider">
              {profile.course_name} ({profile.department_name})
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => navigate('/attendance')}
              className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
            >
              Detailed Attendance
            </button>
            <button
              onClick={() => navigate('/marks')}
              className="px-5 py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 hover:text-white font-bold rounded-2xl border border-slate-700 transition-all text-sm flex items-center gap-2"
            >
              Academic Transcript
            </button>
          </div>
        </div>
      </div>

      {/* Attendance Alert Flag */}
      {isLowAttendance && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-2xl flex items-center gap-3 shadow-sm animate-pulse">
          <AlertTriangle className="w-6 h-6 text-red-600 shrink-0" />
          <div>
            <h4 className="text-sm font-bold">Attendance Deficit Warning</h4>
            <p className="text-xs font-semibold text-red-600 mt-0.5">
              Your overall attendance is {stats.attendancePercentage}%, which is below the mandatory 75% requirement. Please contact your subject faculty to clear deficits.
            </p>
          </div>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard
          title="Current Semester Subjects"
          value={stats.totalSubjects}
          icon={Library}
          colorClass="bg-brand-500"
          description="Enrolled courses"
        />
        <DashboardCard
          title="Overall Attendance"
          value={`${stats.attendancePercentage}%`}
          icon={Calendar}
          colorClass={isLowAttendance ? 'bg-red-500' : 'bg-emerald-500'}
          description={isLowAttendance ? 'Deficit (Threshold 75%)' : 'Good Standing'}
        />
        <DashboardCard
          title="Final Exams Average"
          value={`${stats.averageMarks}%`}
          icon={Award}
          colorClass="bg-amber-500"
          description="Percentage scored"
        />
        <DashboardCard
          title="Current CGPA"
          value={stats.cgpa}
          icon={GraduationCap}
          colorClass="bg-violet-500"
          description="Out of 10.0 scale"
        />
      </div>

      {/* Visual Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject-wise Final Marks */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Final Exams Score (Percentage)</h3>
          <div className="h-80">
            {charts.subjectMarksChart.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.subjectMarksChart}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px' }}
                    formatter={(value) => [`${value}%`, 'Score']}
                  />
                  <Bar dataKey="marks" fill="#3b70ff" radius={[8, 8, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm">
                No Final Examination scores published yet.
              </div>
            )}
          </div>
        </div>

        {/* Subject-wise Attendance */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Subject-wise Presence (%)</h3>
          <div className="h-80">
            {charts.attendanceChart.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={charts.attendanceChart}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} fontWeight={600} tickLine={false} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px' }}
                    formatter={(value) => [`${value}%`, 'Attendance']}
                  />
                  <Bar dataKey="percentage" fill="#10b981" radius={[8, 8, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 text-sm">
                No attendance logs found.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Notice Board Panel */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
        <div className="flex items-center gap-2 mb-6 border-b border-slate-50 pb-3">
          <Bell className="w-5 h-5 text-amber-500" />
          <h3 className="text-base font-bold text-slate-800 tracking-tight">Academic Notice Board</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {notices.length > 0 ? (
            notices.map((n, idx) => (
              <div key={idx} className="p-5 bg-slate-50 border border-slate-100 rounded-3xl flex flex-col gap-2 hover:border-slate-200 transition-colors">
                <div className="flex items-center justify-between">
                  <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                    n.priority === 'High' ? 'text-red-700 bg-red-50 border border-red-200' :
                    n.priority === 'Low' ? 'text-slate-500 bg-slate-100' : 'text-amber-700 bg-amber-50'
                  }`}>
                    {n.priority} Priority
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">{n.created_at ? n.created_at.split('T')[0] : ''}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-800 mt-1">{n.title}</h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed line-clamp-3">{n.description}</p>
              </div>
            ))
          ) : (
            <p className="col-span-full text-center text-xs text-slate-400 py-10">No new notices for today.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
