import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  Search, Filter, Plus, Edit2, Trash2, Eye, 
  X, UserPlus, Info, Check, AlertCircle 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Students = () => {
  const [students, setStudents] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [courses, setCourses] = useState([]);
  
  // Filtering & Pagination State
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [courseFilter, setCourseFilter] = useState('');
  const [yearFilter, setYearFilter] = useState('');
  const [semFilter, setSemFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState(null);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  const navigate = useNavigate();

  // Add/Edit Student Form States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [form, setForm] = useState({
    first_name: '', last_name: '', gender: 'Male', dob: '', blood_group: 'O+',
    email: '', phone: '', address: '', student_id: '', roll_number: '',
    department_id: '', course_id: '', year: '1', semester: '1', admission_date: '',
    parent_name: '', parent_phone: '', parent_email: '', status: 'Active'
  });

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      // 1. Fetch filtered students
      const studRes = await api.get('/api/students', {
        params: {
          search,
          department_id: deptFilter,
          course_id: courseFilter,
          year: yearFilter,
          semester: semFilter,
          status: statusFilter,
          page,
          limit: 10
        }
      });
      setStudents(studRes.data.students);
      setPagination(studRes.data.pagination);

      // 2. Fetch departments and courses for dropdowns
      const deptRes = await api.get('/api/departments');
      setDepartments(deptRes.data);

      const courseRes = await api.get('/api/courses');
      setCourses(courseRes.data);
    } catch (err) {
      console.error('Error loading students portal:', err);
      setError('Failed to fetch students data. Verify backend connections.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [search, deptFilter, courseFilter, yearFilter, semFilter, statusFilter, page]);

  // Handle Form Change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Clear field error
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  // Client-side Validations
  const validateForm = () => {
    const errors = {};
    if (!form.first_name.trim()) errors.first_name = 'First name is required.';
    if (!form.last_name.trim()) errors.last_name = 'Last name is required.';
    if (!form.dob) errors.dob = 'DOB is required.';
    if (!form.email.trim()) errors.email = 'Email is required.';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errors.email = 'Email is invalid.';
    if (!form.student_id.trim()) errors.student_id = 'Student ID is required.';
    if (!form.roll_number.trim()) errors.roll_number = 'Roll Number is required.';
    if (!form.department_id) errors.department_id = 'Department selection is required.';
    if (!form.course_id) errors.course_id = 'Course selection is required.';
    if (!form.admission_date) errors.admission_date = 'Admission Date is required.';
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFormErrors({});
    setForm({
      first_name: '', last_name: '', gender: 'Male', dob: '', blood_group: 'O+',
      email: '', phone: '', address: '', student_id: '', roll_number: '',
      department_id: departments[0]?.id || '', course_id: courses[0]?.id || '',
      year: '1', semester: '1', admission_date: new Date().toISOString().split('T')[0],
      parent_name: '', parent_phone: '', parent_email: '', status: 'Active'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (student) => {
    setIsEditing(true);
    setEditId(student.id);
    setFormErrors({});
    setForm({
      first_name: student.first_name,
      last_name: student.last_name,
      gender: student.gender,
      dob: student.dob ? student.dob.split('T')[0] : '',
      blood_group: student.blood_group || 'O+',
      email: student.email,
      phone: student.phone || '',
      address: student.address || '',
      student_id: student.student_id,
      roll_number: student.roll_number,
      department_id: student.department_id || '',
      course_id: student.course_id || '',
      year: String(student.year),
      semester: String(student.semester),
      admission_date: student.admission_date ? student.admission_date.split('T')[0] : '',
      parent_name: student.parent_name || '',
      parent_phone: student.parent_phone || '',
      parent_email: student.parent_email || '',
      status: student.status
    });
    setIsModalOpen(true);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      if (isEditing) {
        await api.put(`/api/students/${editId}`, form);
        setSuccessMsg('Student details updated successfully.');
      } else {
        await api.post('/api/students', form);
        setSuccessMsg('Student added successfully. Login credentials generated.');
      }
      setIsModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit form error:', err);
      const msg = err.response?.data?.message || 'Failed to submit form.';
      alert(msg);
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you absolutely sure you want to delete student "${name}"?\nThis will permanently erase all attendance logs, grades, and their user login profile.`);
    if (!confirm) return;

    try {
      await api.delete(`/api/students/${id}`);
      setSuccessMsg('Student deleted successfully.');
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete student error:', err);
      alert(err.response?.data?.message || 'Failed to delete student.');
    }
  };

  // Table Headers definition
  const tableHeaders = [
    { label: 'Student ID', key: 'student_id', className: 'font-bold text-slate-800' },
    { label: 'Name', render: (row) => `${row.first_name} ${row.last_name}` },
    { label: 'Roll No', key: 'roll_number' },
    { label: 'Email', key: 'email' },
    { label: 'Course', key: 'course_name', className: 'text-xs text-slate-500 font-bold' },
    { label: 'Semester', render: (row) => `Sem ${row.semester}` },
    { 
      label: 'Status', 
      render: (row) => (
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
          row.status === 'Active' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
        }`}>
          {row.status}
        </span>
      ) 
    },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => navigate(`/student-profile/${row.id}`)}
            className="p-1.5 text-slate-400 hover:text-brand-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit student details"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, `${row.first_name} ${row.last_name}`)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete student"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 page-transition">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Student Files</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Manage, search, register and edit student records.</p>
        </div>
        <div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Student
          </button>
        </div>
      </div>

      {/* Success Notification Bar */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Filters Board */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Filter Records</span>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {/* Search bar */}
          <div className="lg:col-span-2 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, Name, Roll..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none transition-colors text-xs font-semibold"
            />
          </div>

          {/* Department */}
          <select
            value={deptFilter}
            onChange={(e) => { setDeptFilter(e.target.value); setPage(1); }}
            className="px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
          >
            <option value="">All Departments</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.department_code}</option>
            ))}
          </select>

          {/* Course */}
          <select
            value={courseFilter}
            onChange={(e) => { setCourseFilter(e.target.value); setPage(1); }}
            className="px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
          >
            <option value="">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.course_code}</option>
            ))}
          </select>

          {/* Year */}
          <select
            value={yearFilter}
            onChange={(e) => { setYearFilter(e.target.value); setPage(1); }}
            className="px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
          >
            <option value="">All Years</option>
            <option value="1">Year 1</option>
            <option value="2">Year 2</option>
            <option value="3">Year 3</option>
            <option value="4">Year 4</option>
          </select>

          {/* Status */}
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Main Grid table */}
      <DataTable
        headers={tableHeaders}
        data={students}
        loading={loading}
        pagination={pagination}
        onPageChange={(p) => setPage(p)}
        emptyMessage="No students found matching your criteria."
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Modify Student Record' : 'Register New Student'}
        size="lg"
      >
        <form onSubmit={handleFormSubmit} className="space-y-8">
          {/* Section 1: Personal Info */}
          <div className="space-y-4">
            <h4 className="text-xs font-extrabold text-brand-600 uppercase tracking-widest border-b border-slate-100 pb-2">
              1. Personal Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">First Name *</label>
                <input
                  type="text"
                  name="first_name"
                  value={form.first_name}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.first_name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.first_name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.first_name}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Last Name *</label>
                <input
                  type="text"
                  name="last_name"
                  value={form.last_name}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.last_name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.last_name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.last_name}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Gender *</label>
                <select
                  name="gender"
                  value={form.gender}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Date of Birth *</label>
                <input
                  type="date"
                  name="dob"
                  value={form.dob}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.dob ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.dob && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.dob}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Blood Group</label>
                <select
                  name="blood_group"
                  value={form.blood_group}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                >
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Phone Number</label>
                <input
                  type="text"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                />
              </div>

              <div className="md:col-span-3">
                <label className="text-xs font-bold text-slate-500 block mb-1">Residential Address</label>
                <textarea
                  name="address"
                  rows="2"
                  value={form.address}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Academic Info */}
          <div className="space-y-4">
            <h4 className="text-xs font-extrabold text-brand-600 uppercase tracking-widest border-b border-slate-100 pb-2">
              2. Academic Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Student ID (Code) *</label>
                <input
                  type="text"
                  name="student_id"
                  placeholder="e.g. S-101"
                  value={form.student_id}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.student_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                  disabled={isEditing}
                />
                {formErrors.student_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.student_id}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Roll Number *</label>
                <input
                  type="text"
                  name="roll_number"
                  placeholder="e.g. 101"
                  value={form.roll_number}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.roll_number ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.roll_number && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.roll_number}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Email / Username *</label>
                <input
                  type="email"
                  name="email"
                  placeholder="name@college.com"
                  value={form.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.email ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.email && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.email}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Department *</label>
                <select
                  name="department_id"
                  value={form.department_id}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.department_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                >
                  <option value="">Select Department</option>
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.department_name}</option>
                  ))}
                </select>
                {formErrors.department_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.department_id}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Course *</label>
                <select
                  name="course_id"
                  value={form.course_id}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.course_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                >
                  <option value="">Select Course</option>
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.course_name}</option>
                  ))}
                </select>
                {formErrors.course_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.course_id}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Year *</label>
                <select
                  name="year"
                  value={form.year}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                >
                  <option value="1">1st Year</option>
                  <option value="2">2nd Year</option>
                  <option value="3">3rd Year</option>
                  <option value="4">4th Year</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Semester *</label>
                <select
                  name="semester"
                  value={form.semester}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                    <option key={s} value={String(s)}>Semester {s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Admission Date *</label>
                <input
                  type="date"
                  name="admission_date"
                  value={form.admission_date}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    formErrors.admission_date ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {formErrors.admission_date && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.admission_date}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Account Status</label>
                <select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Parent Info */}
          <div className="space-y-4">
            <h4 className="text-xs font-extrabold text-brand-600 uppercase tracking-widest border-b border-slate-100 pb-2">
              3. Parent / Guardian Details
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Guardian Name</label>
                <input
                  type="text"
                  name="parent_name"
                  value={form.parent_name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Guardian Phone</label>
                <input
                  type="text"
                  name="parent_phone"
                  value={form.parent_phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Guardian Email</label>
                <input
                  type="email"
                  name="parent_email"
                  value={form.parent_email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
            >
              {isEditing ? 'Save Changes' : 'Submit Application'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Students;
