import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  Search, Filter, Plus, Edit2, Trash2, 
  Check, AlertCircle, Mail, Phone, Calendar, ShieldAlert 
} from 'lucide-react';

const Faculty = () => {
  const [facultyList, setFacultyList] = useState([]);
  const [departments, setDepartments] = useState([]);
  
  // Filtering states
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [form, setForm] = useState({
    faculty_id: '', name: '', email: '', phone: '', gender: 'Male',
    department_id: '', qualification: '', designation: '', 
    joining_date: '', status: 'Active'
  });

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      // 1. Fetch faculty list
      const facRes = await api.get('/api/faculty', {
        params: { search, department_id: deptFilter }
      });
      setFacultyList(facRes.data);

      // 2. Fetch departments
      const deptRes = await api.get('/api/departments');
      setDepartments(deptRes.data);
    } catch (err) {
      console.error('Failed to load faculty portal:', err);
      setError('Could not download faculty records from the server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [search, deptFilter]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!form.faculty_id.trim()) errors.faculty_id = 'Faculty ID is required.';
    if (!form.name.trim()) errors.name = 'Full name is required.';
    if (!form.email.trim()) errors.email = 'Email is required.';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errors.email = 'Email address is invalid.';
    if (!form.department_id) errors.department_id = 'Department selection is required.';
    if (!form.designation.trim()) errors.designation = 'Designation is required.';
    if (!form.joining_date) errors.joining_date = 'Joining Date is required.';
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFormErrors({});
    setForm({
      faculty_id: '', name: '', email: '', phone: '', gender: 'Male',
      department_id: departments[0]?.id || '', qualification: '', 
      designation: '', joining_date: new Date().toISOString().split('T')[0], status: 'Active'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (fac) => {
    setIsEditing(true);
    setEditId(fac.id);
    setFormErrors({});
    setForm({
      faculty_id: fac.faculty_id,
      name: fac.name,
      email: fac.email,
      phone: fac.phone || '',
      gender: fac.gender || 'Male',
      department_id: fac.department_id || '',
      qualification: fac.qualification || '',
      designation: fac.designation,
      joining_date: fac.joining_date ? fac.joining_date.split('T')[0] : '',
      status: fac.status
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      if (isEditing) {
        await api.put(`/api/faculty/${editId}`, form);
        setSuccessMsg('Faculty details updated successfully.');
      } else {
        await api.post('/api/faculty', form);
        setSuccessMsg('Faculty staff registered successfully. Login credentials generated.');
      }
      setIsModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit form error:', err);
      alert(err.response?.data?.message || 'Failed to submit form.');
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you sure you want to delete Faculty member "${name}"?\nThis will permanently delete their class links and login profile.`);
    if (!confirm) return;

    try {
      await api.delete(`/api/faculty/${id}`);
      setSuccessMsg('Faculty record deleted successfully.');
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete faculty error:', err);
      alert(err.response?.data?.message || 'Failed to remove faculty member.');
    }
  };

  const tableHeaders = [
    { label: 'Faculty ID', key: 'faculty_id', className: 'font-bold text-slate-800' },
    { label: 'Name', key: 'name' },
    { label: 'Email', key: 'email' },
    { label: 'Department', key: 'department_name', className: 'text-xs text-slate-500 font-bold' },
    { label: 'Designation', key: 'designation' },
    { label: 'Qualification', key: 'qualification' },
    { 
      label: 'Status', 
      render: (row) => (
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
          row.status === 'Active' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
        }`}>
          {row.status}
        </span>
      ) 
    },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit Details"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, row.name)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete Faculty member"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 page-transition">
      {/* Title bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Faculty Directory</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Manage, search, register, and update academic staff details.</p>
        </div>
        <div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Faculty
          </button>
        </div>
      </div>

      {/* Success Notification Bar */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Filters Board */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Filter Faculty</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {/* Search bar */}
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by ID, Name, Email, Designation..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none transition-colors text-xs font-semibold"
            />
          </div>

          {/* Department */}
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
          >
            <option value="">All Departments</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.department_code}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid Table */}
      <DataTable
        headers={tableHeaders}
        data={facultyList}
        loading={loading}
        emptyMessage="No faculty members found matching your search."
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Modify Staff Record' : 'Register New Faculty'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Faculty ID (Code) *</label>
              <input
                type="text"
                name="faculty_id"
                placeholder="e.g. F-101"
                value={form.faculty_id}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.faculty_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
                disabled={isEditing}
              />
              {formErrors.faculty_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.faculty_id}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Full Name *</label>
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {formErrors.name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.name}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Email / Username *</label>
              <input
                type="email"
                name="email"
                placeholder="name@college.com"
                value={form.email}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.email ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {formErrors.email && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.email}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Phone Number</label>
              <input
                type="text"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Gender *</label>
              <select
                name="gender"
                value={form.gender}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Department *</label>
              <select
                name="department_id"
                value={form.department_id}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.department_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              >
                <option value="">Select Department</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.department_name}</option>
                ))}
              </select>
              {formErrors.department_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.department_id}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Designation *</label>
              <input
                type="text"
                name="designation"
                placeholder="e.g. Professor, Assistant Professor"
                value={form.designation}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.designation ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {formErrors.designation && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.designation}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Qualification</label>
              <input
                type="text"
                name="qualification"
                placeholder="e.g. M.Tech, Ph.D in Computer Science"
                value={form.qualification}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Joining Date *</label>
              <input
                type="date"
                name="joining_date"
                value={form.joining_date}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  formErrors.joining_date ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {formErrors.joining_date && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{formErrors.joining_date}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Status</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
            >
              {isEditing ? 'Save Changes' : 'Register Staff'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Faculty;
