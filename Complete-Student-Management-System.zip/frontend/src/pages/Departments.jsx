import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { Plus, Edit2, Trash2, Check } from 'lucide-react';

const Departments = () => {
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ department_name: '', department_code: '', hod: '' });
  const [fieldErrors, setFieldErrors] = useState({});

  const fetchDepartments = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/api/departments');
      setDepartments(response.data);
    } catch (err) {
      console.error('Failed to load departments:', err);
      setError('Could not download departments list from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errors = {};
    if (!form.department_name.trim()) errors.department_name = 'Name is required.';
    if (!form.department_code.trim()) errors.department_code = 'Code is required (e.g. CSE).';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFieldErrors({});
    setForm({ department_name: '', department_code: '', hod: '' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (dept) => {
    setIsEditing(true);
    setEditId(dept.id);
    setFieldErrors({});
    setForm({
      department_name: dept.department_name,
      department_code: dept.department_code,
      hod: dept.hod || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (isEditing) {
        await api.put(`/api/departments/${editId}`, form);
        setSuccessMsg('Department updated successfully.');
      } else {
        await api.post('/api/departments', form);
        setSuccessMsg('Department added successfully.');
      }
      setIsModalOpen(false);
      fetchDepartments();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit department error:', err);
      alert(err.response?.data?.message || 'Failed to submit form.');
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you absolutely sure you want to delete department "${name}"?\nWarning: This will delete all course programs and subjects under this department.`);
    if (!confirm) return;

    try {
      await api.delete(`/api/departments/${id}`);
      setSuccessMsg('Department deleted successfully.');
      fetchDepartments();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete department error:', err);
      alert(err.response?.data?.message || 'Failed to delete department.');
    }
  };

  const headers = [
    { label: 'Code', key: 'department_code', className: 'font-bold text-brand-600' },
    { label: 'Department Name', key: 'department_name', className: 'text-slate-800 font-bold' },
    { label: 'H.O.D (Head)', key: 'hod', render: (row) => row.hod || 'Unassigned' },
    { label: 'Students Count', key: 'student_count', className: 'text-center font-bold text-slate-500' },
    { label: 'Faculty Count', key: 'faculty_count', className: 'text-center font-bold text-slate-500' },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, row.department_name)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete Department"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 page-transition">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Academic Departments</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Manage and view core university department structures.</p>
        </div>
        <div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Department
          </button>
        </div>
      </div>

      {/* Success Notification Bar */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Table grid */}
      <DataTable
        headers={headers}
        data={departments}
        loading={loading}
        emptyMessage="No departments registered."
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Modify Department Details' : 'Create New Department'}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Department Code *</label>
              <input
                type="text"
                name="department_code"
                placeholder="e.g. CSE"
                value={form.department_code}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  fieldErrors.department_code ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
                disabled={isEditing}
              />
              {fieldErrors.department_code && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.department_code}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Department Name *</label>
              <input
                type="text"
                name="department_name"
                placeholder="e.g. Computer Science & Engineering"
                value={form.department_name}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  fieldErrors.department_name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {fieldErrors.department_name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.department_name}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Head of Department (HOD)</label>
              <input
                type="text"
                name="hod"
                placeholder="e.g. Dr. John Doe"
                value={form.hod}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
            >
              {isEditing ? 'Save Changes' : 'Create Department'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Departments;
