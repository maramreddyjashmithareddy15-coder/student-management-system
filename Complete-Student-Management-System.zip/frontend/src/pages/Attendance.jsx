import React, { useState, useEffect } from 'react';
import api from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { useAuth } from '../context/AuthContext';
import { Calendar, CheckCircle2, XCircle, Users, Check, AlertTriangle, Filter } from 'lucide-react';

const Attendance = () => {
  const { user } = useAuth();
  
  // Faculty/Admin parameters
  const [courses, setCourses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedSemester, setSelectedSemester] = useState('1');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [studentsSheet, setStudentsSheet] = useState([]);
  const [isMarked, setIsMarked] = useState(false);
  const [sheetLoaded, setSheetLoaded] = useState(false);
  
  // Student self parameters
  const [myAttendance, setMyAttendance] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // 1. Fetch startup dropdown options
  useEffect(() => {
    const initData = async () => {
      setLoading(true);
      setError('');
      try {
        if (user.role === 'Student') {
          // Fetch student self attendance logs
          const response = await api.get('/api/attendance');
          
          // Aggregate by subject code for clean display
          const summary = {};
          response.data.forEach(item => {
            if (!summary[item.subject_id]) {
              summary[item.subject_id] = {
                subject_name: item.subject_name,
                subject_code: item.subject_code,
                faculty_name: item.faculty_name || 'Pending',
                total: 0,
                present: 0,
                absent: 0
              };
            }
            summary[item.subject_id].total += 1;
            if (item.status === 'Present') {
              summary[item.subject_id].present += 1;
            } else {
              summary[item.subject_id].absent += 1;
            }
          });
          setMyAttendance(Object.values(summary));
        } else {
          // Fetch courses & subjects list for entry
          const courseRes = await api.get('/api/courses');
          setCourses(courseRes.data);
          if (courseRes.data.length > 0) setSelectedCourse(courseRes.data[0].id);

          const subRes = await api.get('/api/subjects');
          setSubjects(subRes.data);
          if (subRes.data.length > 0) setSelectedSubject(subRes.data[0].id);
        }
      } catch (err) {
        console.error('Failed to init attendance portal:', err);
        setError('Failed to download parameters from the server.');
      } finally {
        setLoading(false);
      }
    };
    initData();
  }, [user]);

  // 2. Fetch attendance sheet for selected parameters
  const loadAttendanceSheet = async (e) => {
    if (e) e.preventDefault();
    if (!selectedCourse || !selectedSemester || !selectedSubject || !selectedDate) {
      alert('Please fill all filters first.');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const response = await api.get('/api/attendance', {
        params: {
          course_id: selectedCourse,
          semester: selectedSemester,
          subject_id: selectedSubject,
          date: selectedDate
        }
      });
      setStudentsSheet(response.data.records);
      setIsMarked(response.data.marked);
      setSheetLoaded(true);
    } catch (err) {
      console.error('Error fetching roll sheet:', err);
      setError('Could not retrieve students enrollment list.');
    } finally {
      setLoading(false);
    }
  };

  // Toggle present/absent status
  const handleStatusToggle = (studentId, newStatus) => {
    setStudentsSheet(prev => 
      prev.map(student => 
        student.student_id === studentId ? { ...student, status: newStatus } : student
      )
    );
  };

  // Set all present or absent
  const handleMarkAll = (status) => {
    setStudentsSheet(prev => 
      prev.map(student => ({ ...student, status }))
    );
  };

  // 3. Save attendance logs
  const handleSaveAttendance = async () => {
    setSubmitting(true);
    setError('');
    setSuccess('');
    try {
      const payload = {
        course_id: selectedCourse,
        semester: selectedSemester,
        subject_id: selectedSubject,
        date: selectedDate,
        records: studentsSheet.map(s => ({
          student_id: s.student_id,
          status: s.status
        }))
      };
      await api.post('/api/attendance', payload);
      setSuccess('Attendance sheet updated successfully!');
      setIsMarked(true);
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      console.error('Failed to submit attendance:', err);
      setError(err.response?.data?.message || 'Failed to publish attendance log.');
    } finally {
      setSubmitting(false);
    }
  };

  // Get active subjects filtered by selected course and semester
  const getFilteredSubjects = () => {
    return subjects.filter(
      sub => sub.course_id === parseInt(selectedCourse) && sub.semester === parseInt(selectedSemester)
    );
  };

  // Dynamic dropdown auto-selection
  useEffect(() => {
    if (selectedCourse && selectedSemester && subjects.length > 0) {
      const filtered = getFilteredSubjects();
      if (filtered.length > 0) {
        setSelectedSubject(filtered[0].id);
      } else {
        setSelectedSubject('');
      }
    }
  }, [selectedCourse, selectedSemester, subjects]);

  if (loading && !sheetLoaded) return <Loading size="lg" className="min-h-[70vh]" />;

  // ----------------------------------------------------
  // WORKFLOW A: Student detailed attendance view
  // ----------------------------------------------------
  if (user.role === 'Student') {
    return (
      <div className="space-y-8 page-transition">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">My Attendance</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Review your subject-wise class presence logs.</p>
        </div>

        {error && <ErrorMessage message={error} />}

        <div className="bg-white border border-slate-100 rounded-[32px] overflow-hidden shadow-premium">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-500 text-xs font-bold uppercase tracking-wider">
                  <th className="px-6 py-4">Code</th>
                  <th className="px-6 py-4">Subject</th>
                  <th className="px-6 py-4">Instructor</th>
                  <th className="px-6 py-4 text-center">Total Sessions</th>
                  <th className="px-6 py-4 text-center">Present</th>
                  <th className="px-6 py-4 text-center">Absent</th>
                  <th className="px-6 py-4" style={{ width: '220px' }}>Percentage</th>
                  <th className="px-6 py-4 text-center">Eligibility</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-semibold text-slate-700">
                {myAttendance.length > 0 ? (
                  myAttendance.map((item, idx) => {
                    const percent = item.total > 0 ? parseFloat(((item.present / item.total) * 100).toFixed(1)) : 100;
                    const isLow = percent < 75;

                    return (
                      <tr key={idx} className="hover:bg-slate-50/40 transition-colors">
                        <td className="px-6 py-4 font-bold text-brand-600">{item.subject_code}</td>
                        <td className="px-6 py-4 text-slate-800">{item.subject_name}</td>
                        <td className="px-6 py-4 text-xs font-bold text-slate-400">{item.faculty_name}</td>
                        <td className="px-6 py-4 text-center">{item.total}</td>
                        <td className="px-6 py-4 text-center text-emerald-600">{item.present}</td>
                        <td className="px-6 py-4 text-center text-red-500">{item.absent}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${isLow ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`}
                                style={{ width: `${percent}%` }}
                              ></div>
                            </div>
                            <span className="text-xs font-bold">{percent}%</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          {isLow ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
                              <AlertTriangle className="w-3 h-3 text-red-600" /> Warning
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
                              Eligible
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="8" className="px-6 py-12 text-center text-slate-400 text-sm font-medium">
                      No attendance classes have been registered for your account yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // WORKFLOW B: Faculty / Admin Attendance Entry view
  // ----------------------------------------------------
  const filteredSubjectsList = getFilteredSubjects();

  return (
    <div className="space-y-8 page-transition">
      {/* Title bar */}
      <div>
        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Attendance Manager</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">Select class parameters to load and mark daily presence sheets.</p>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{success}</span>
        </div>
      )}

      {error && <ErrorMessage message={error} />}

      {/* Configuration filters board */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Select Class Sheet</span>
        </div>

        <form onSubmit={loadAttendanceSheet} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 items-end">
          {/* Course */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Course Program</label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            >
              {courses.map(c => (
                <option key={c.id} value={c.id}>{c.course_code}</option>
              ))}
            </select>
          </div>

          {/* Semester */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Semester</label>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                <option key={s} value={String(s)}>Semester {s}</option>
              ))}
            </select>
          </div>

          {/* Subject */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Course Subject</label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              disabled={filteredSubjectsList.length === 0}
            >
              {filteredSubjectsList.length > 0 ? (
                filteredSubjectsList.map(s => (
                  <option key={s.id} value={s.id}>{s.subject_code}</option>
                ))
              ) : (
                <option value="">No Subjects Found</option>
              )}
            </select>
          </div>

          {/* Date */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Log Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            />
          </div>

          {/* Button */}
          <button
            type="submit"
            className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-2xl transition duration-150 shadow-md shadow-brand-500/10"
          >
            Load Roll Sheet
          </button>
        </form>
      </div>

      {/* Attendance Entry Sheet */}
      {sheetLoaded && (
        <div className="bg-white border border-slate-100 rounded-[32px] p-6 shadow-premium space-y-6">
          {/* Controls bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-50 pb-4 gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Users className="w-5 h-5 text-brand-500" />
                Roll Sheet: {isMarked ? (
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                    Attendance Log Saved
                  </span>
                ) : (
                  <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                    Not Marked Yet
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 font-semibold mt-1">Date: {selectedDate} • Enrolled active students</p>
            </div>
            
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handleMarkAll('Present')}
                className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold rounded-xl border border-emerald-200/50 transition-colors"
              >
                Mark All Present
              </button>
              <button
                type="button"
                onClick={() => handleMarkAll('Absent')}
                className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl border border-red-200/50 transition-colors"
              >
                Mark All Absent
              </button>
            </div>
          </div>

          {/* Sheet table */}
          {loading ? (
            <Loading size="md" />
          ) : studentsSheet.length === 0 ? (
            <p className="text-center text-sm font-semibold text-slate-400 py-10">
              No students are currently registered in this course/semester.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <th className="pb-3">Roll No</th>
                    <th className="pb-3">Student ID</th>
                    <th className="pb-3">Student Name</th>
                    <th className="pb-3 text-center">Status Selection</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm font-semibold text-slate-700">
                  {studentsSheet.map((student, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/20">
                      <td className="py-4 text-slate-500">{student.roll_number}</td>
                      <td className="py-4 text-slate-800">{student.student_code}</td>
                      <td className="py-4 text-slate-800">
                        {student.first_name} {student.last_name}
                      </td>
                      <td className="py-4 text-center">
                        <div className="inline-flex bg-slate-100 p-1 rounded-xl border border-slate-200/40">
                          {/* Present button */}
                          <button
                            type="button"
                            onClick={() => handleStatusToggle(student.student_id, 'Present')}
                            className={`flex items-center gap-1.5 px-4 py-1.5 text-xs font-extrabold rounded-lg transition duration-150 ${
                              student.status === 'Present' 
                                ? 'bg-white text-emerald-600 shadow-sm border border-emerald-100/50' 
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Present
                          </button>
                          
                          {/* Absent button */}
                          <button
                            type="button"
                            onClick={() => handleStatusToggle(student.student_id, 'Absent')}
                            className={`flex items-center gap-1.5 px-4 py-1.5 text-xs font-extrabold rounded-lg transition duration-150 ${
                              student.status === 'Absent' 
                                ? 'bg-white text-red-500 shadow-sm border border-red-100/50' 
                                : 'text-slate-400 hover:text-slate-600'
                            }`}
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            Absent
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Submit footer */}
              <div className="flex items-center justify-end border-t border-slate-100 pt-6 mt-6">
                <button
                  type="button"
                  onClick={handleSaveAttendance}
                  className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold rounded-xl shadow-md shadow-brand-500/10 flex items-center justify-center gap-2 transition active:scale-95"
                  disabled={submitting}
                >
                  {submitting ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    'Submit Attendance Sheet'
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Attendance;
