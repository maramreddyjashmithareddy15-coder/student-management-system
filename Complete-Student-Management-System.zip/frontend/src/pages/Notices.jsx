import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { useAuth } from '../context/AuthContext';
import { Plus, Edit2, Trash2, Check, Bell, Calendar, Tag, AlertCircle } from 'lucide-react';

const Notices = () => {
  const { user } = useAuth();
  
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', target: 'All', priority: 'Normal' });
  const [fieldErrors, setFieldErrors] = useState({});

  const fetchNotices = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/api/notices');
      setNotices(response.data);
    } catch (err) {
      console.error('Failed to load notices:', err);
      setError('Could not retrieve notices list from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotices();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errors = {};
    if (!form.title.trim()) errors.title = 'Announcement title is required.';
    if (!form.description.trim()) errors.description = 'Notice content is required.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFieldErrors({});
    setForm({ title: '', description: '', target: 'All', priority: 'Normal' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (notice) => {
    setIsEditing(true);
    setEditId(notice.id);
    setFieldErrors({});
    setForm({
      title: notice.title,
      description: notice.description,
      target: notice.target || 'All',
      priority: notice.priority || 'Normal'
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (isEditing) {
        await api.put(`/api/notices/${editId}`, form);
        setSuccessMsg('Notice updated successfully.');
      } else {
        await api.post('/api/notices', form);
        setSuccessMsg('Notice posted successfully.');
      }
      setIsModalOpen(false);
      fetchNotices();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit notice error:', err);
      alert(err.response?.data?.message || 'Failed to submit form.');
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you sure you want to delete notice "${name}"?`);
    if (!confirm) return;

    try {
      await api.delete(`/api/notices/${id}`);
      setSuccessMsg('Notice removed successfully.');
      fetchNotices();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete notice error:', err);
      alert(err.response?.data?.message || 'Failed to delete notice.');
    }
  };

  if (loading && notices.length === 0) return <Loading size="lg" className="min-h-[70vh]" />;

  const headers = [
    { label: 'Published Date', render: (row) => row.created_at ? row.created_at.split('T')[0] : '' },
    { label: 'Title', key: 'title', className: 'font-bold text-slate-800' },
    { label: 'Description', key: 'description', className: 'text-xs text-slate-500 max-w-sm truncate' },
    { label: 'Audience', key: 'target', className: 'text-xs font-bold text-brand-600' },
    { 
      label: 'Priority', 
      render: (row) => (
        <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
          row.priority === 'High' ? 'text-red-700 bg-red-50 border border-red-200' :
          row.priority === 'Low' ? 'text-slate-500 bg-slate-100' : 'text-amber-700 bg-amber-50'
        }`}>
          {row.priority}
        </span>
      ) 
    },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, row.title)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete Notice"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  // Render for Admin
  if (user.role === 'Admin') {
    return (
      <div className="space-y-8 page-transition">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Notice Board Management</h1>
            <p className="text-sm text-slate-500 font-medium mt-1">Publish, edit, or delete circular announcements.</p>
          </div>
          <div>
            <button
              onClick={handleOpenAdd}
              className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Add Notice
            </button>
          </div>
        </div>

        {successMsg && (
          <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
            <Check className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="text-sm font-semibold">{successMsg}</span>
          </div>
        )}

        {error && <ErrorMessage message={error} onRetry={fetchNotices} />}

        {/* Table grid */}
        <DataTable
          headers={headers}
          data={notices}
          loading={loading}
          emptyMessage="No notices registered."
        />

        {/* Add/Edit Modal */}
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={isEditing ? 'Modify Published Notice' : 'Post New Announcement'}
          size="lg"
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Notice Title *</label>
                <input
                  type="text"
                  name="title"
                  placeholder="e.g. End Semester Exams Schedule"
                  value={form.title}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    fieldErrors.title ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {fieldErrors.title && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.title}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Announcement Body / Content *</label>
                <textarea
                  name="description"
                  rows="4"
                  placeholder="Enter details of the circular announcement..."
                  value={form.description}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    fieldErrors.description ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {fieldErrors.description && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.description}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Target Audience</label>
                  <select
                    name="target"
                    value={form.target}
                    onChange={handleChange}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                  >
                    <option value="All">All Users</option>
                    <option value="Faculty">Faculty Only</option>
                    <option value="Student">Students Only</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-500 block mb-1">Priority</label>
                  <select
                    name="priority"
                    value={form.priority}
                    onChange={handleChange}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
                  >
                    <option value="Low">Low</option>
                    <option value="Normal">Normal</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
              >
                {isEditing ? 'Save Changes' : 'Post Announcement'}
              </button>
            </div>
          </form>
        </Modal>
      </div>
    );
  }

  // Render for Students & Faculty: Card grid view
  return (
    <div className="space-y-8 page-transition">
      <div>
        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Academic Notice Board</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">Stay updated with the latest college announcements.</p>
      </div>

      {error && <ErrorMessage message={error} />}

      {notices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {notices.map((n, idx) => (
            <div key={idx} className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium flex flex-col justify-between hover:border-slate-200 hover:-translate-y-0.5 transition-all duration-200">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-[9px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                    n.priority === 'High' ? 'text-red-700 bg-red-50 border border-red-200' :
                    n.priority === 'Low' ? 'text-slate-500 bg-slate-100' : 'text-amber-700 bg-amber-50'
                  }`}>
                    {n.priority} Priority
                  </span>
                  <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold">
                    <Calendar className="w-3.5 h-3.5" />
                    {n.created_at ? n.created_at.split('T')[0] : ''}
                  </div>
                </div>
                <h4 className="text-base font-bold text-slate-850 tracking-tight mt-1">{n.title}</h4>
                <p className="text-xs text-slate-500 font-medium leading-relaxed whitespace-pre-line">{n.description}</p>
              </div>
              <div className="border-t border-slate-50 pt-4 mt-5 flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                <Tag className="w-3.5 h-3.5 text-brand-500" />
                Audience: {n.target}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white border border-slate-100 p-12 text-center rounded-[32px] shadow-premium text-slate-400">
          <Bell className="w-12 h-12 mx-auto mb-3 opacity-30 text-slate-400" />
          <p className="text-sm font-semibold">No notices published for your account today.</p>
        </div>
      )}
    </div>
  );
};

export default Notices;
