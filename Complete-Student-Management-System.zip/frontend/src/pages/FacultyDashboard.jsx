import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DashboardCard from '../components/DashboardCard';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  Library, Users, BookOpen, Calendar, Bell, 
  FileSpreadsheet, User, ArrowRight, CheckCircle2 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const FacultyDashboard = () => {
  const [data, setData] = useState(null);
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const fetchData = async () => {
    setLoading(true);
    setError('');
    try {
      const statsResponse = await api.get('/api/dashboard/stats');
      setData(statsResponse.data);

      const noticesResponse = await api.get('/api/notices');
      setNotices(noticesResponse.data.slice(0, 5)); // Keep latest 5
    } catch (err) {
      console.error('Failed to load faculty dashboard data:', err);
      setError('Could not retrieve faculty dashboard statistics from the server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return <Loading size="lg" className="min-h-[70vh]" />;
  if (error) return <ErrorMessage message={error} onRetry={fetchData} />;
  if (!data) return null;

  const { profile, stats, assignedSubjects, recentActivity } = data;

  return (
    <div className="space-y-8 page-transition">
      {/* Welcome Banner */}
      <div className="bg-slate-900 border border-slate-800 text-white p-8 rounded-[32px] shadow-2xl relative overflow-hidden">
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-brand-600/10 rounded-full blur-3xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="text-brand-400 text-xs font-bold uppercase tracking-widest bg-brand-500/10 border border-brand-500/20 px-3 py-1 rounded-xl">
              Faculty Portal
            </span>
            <h1 className="text-3xl font-extrabold text-white mt-3 tracking-tight">Welcome, {profile.name}</h1>
            <p className="text-sm text-slate-400 font-medium mt-1">
              {profile.designation} • {profile.department_name}
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/attendance')}
              className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              Mark Attendance
            </button>
            <button
              onClick={() => navigate('/marks')}
              className="px-5 py-3 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 hover:text-white font-bold rounded-2xl border border-slate-700 transition-all text-sm flex items-center gap-2"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Enter Marks
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DashboardCard
          title="Assigned Subjects"
          value={stats.totalSubjects}
          icon={Library}
          colorClass="bg-brand-500"
          description="Courses currently teaching"
        />
        <DashboardCard
          title="Students Under Supervision"
          value={stats.totalStudents}
          icon={Users}
          colorClass="bg-emerald-500"
          description="Enrolled in your subjects"
        />
      </div>

      {/* Assigned Subjects / Class Details */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left: Assigned Subjects Table */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium xl:col-span-2 flex flex-col">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-brand-500" />
            My Assigned Subjects
          </h3>
          
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                  <th className="pb-3 pr-4">Code</th>
                  <th className="pb-3 pr-4">Subject Name</th>
                  <th className="pb-3 pr-4">Course</th>
                  <th className="pb-3 pr-4 text-center">Semester</th>
                  <th className="pb-3 text-center">Credits</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm font-semibold text-slate-700">
                {assignedSubjects.length > 0 ? (
                  assignedSubjects.map((sub, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/40 transition-colors">
                      <td className="py-3.5 text-brand-600 font-bold">{sub.subject_code}</td>
                      <td className="py-3.5 pr-4 text-slate-800">{sub.subject_name}</td>
                      <td className="py-3.5 pr-4 text-xs font-bold text-slate-500">{sub.course_name}</td>
                      <td className="py-3.5 text-center">{sub.semester}</td>
                      <td className="py-3.5 text-center">
                        <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-lg text-xs font-extrabold">
                          {sub.credits}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="py-10 text-center text-slate-400 text-xs font-semibold">
                      You have not been assigned any subjects yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Notices Panel */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium flex flex-col">
          <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-500" />
            Notice Board
          </h3>
          
          <div className="space-y-4 overflow-y-auto max-h-[320px] flex-1">
            {notices.length > 0 ? (
              notices.map((n, idx) => (
                <div key={idx} className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col gap-1 hover:border-slate-200 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      n.priority === 'High' ? 'text-red-700 bg-red-50 border border-red-200' :
                      n.priority === 'Low' ? 'text-slate-500 bg-slate-100' : 'text-amber-700 bg-amber-50'
                    }`}>
                      {n.priority} Priority
                    </span>
                    <span className="text-[10px] text-slate-400 font-semibold">{n.created_at ? n.created_at.split('T')[0] : ''}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-800 mt-1">{n.title}</h4>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed truncate">{n.description}</p>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No notices available.</p>
            )}
          </div>
        </div>
      </div>

      {/* Activity Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Attendance Actions */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-4 tracking-tight flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            Recent Attendance Submissions
          </h3>
          <div className="space-y-3">
            {recentActivity.recentAttendanceMarked && recentActivity.recentAttendanceMarked.length > 0 ? (
              recentActivity.recentAttendanceMarked.map((log, idx) => {
                const percent = log.total_students > 0 ? ((log.present_count / log.total_students) * 100).toFixed(0) : '0';
                return (
                  <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
                    <div>
                      <h4 className="text-sm font-bold text-slate-800">{log.subject_name}</h4>
                      <span className="text-xs text-slate-400 font-semibold">{log.date} • {log.total_students} Students marked</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-extrabold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-xl">
                        {percent}% Present
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No attendance records submitted recently.</p>
            )}
          </div>
        </div>

        {/* Recent Grade Input Actions */}
        <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
          <h3 className="text-base font-bold text-slate-800 mb-4 tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-amber-500" />
            Recent Marks Updates
          </h3>
          <div className="space-y-3">
            {recentActivity.recentMarksEntered && recentActivity.recentMarksEntered.length > 0 ? (
              recentActivity.recentMarksEntered.map((log, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">{log.first_name} {log.last_name}</h4>
                    <span className="text-xs text-slate-400 font-semibold">{log.subject_name} • {log.exam_type}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-extrabold text-slate-800">{log.marks}/{log.max_marks}</span>
                    <span className="block text-[10px] font-bold text-slate-400 mt-0.5">Grade {log.grade}</span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-400 py-8">No marks records entered recently.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FacultyDashboard;
