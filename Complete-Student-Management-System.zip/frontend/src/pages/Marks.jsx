import React, { useState, useEffect } from 'react';
import api from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { useAuth } from '../context/AuthContext';
import { Award, FileSpreadsheet, Plus, Check, Info, Filter } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Letter Grade Helper
const getLetterGrade = (percent) => {
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B+';
  if (percent >= 60) return 'B';
  if (percent >= 50) return 'C';
  if (percent >= 40) return 'D';
  return 'F';
};

const Marks = () => {
  const { user } = useAuth();

  // Grader parameters
  const [courses, setCourses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedSemester, setSelectedSemester] = useState('1');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedExam, setSelectedExam] = useState('Internal'); // Internal, Midterm, Assignment, Practical, Final
  
  const [studentsSheet, setStudentsSheet] = useState([]);
  const [isEntered, setIsEntered] = useState(false);
  const [sheetLoaded, setSheetLoaded] = useState(false);

  // Student transcript parameters
  const [myTranscript, setMyTranscript] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // 1. Fetch startup options
  useEffect(() => {
    const initData = async () => {
      setLoading(true);
      setError('');
      try {
        if (user.role === 'Student') {
          // Fetch student self grades
          const response = await api.get('/api/marks');
          
          // Structure by subject for transcript rows
          const transcript = {};
          response.data.forEach(item => {
            if (!transcript[item.subject_id]) {
              transcript[item.subject_id] = {
                subject_name: item.subject_name,
                subject_code: item.subject_code,
                credits: item.credits,
                Internal: '-',
                Midterm: '-',
                Assignment: '-',
                Final: '-',
                Total: 0,
                MaxTotal: 0,
                Grade: '-'
              };
            }
            const val = parseFloat(item.marks);
            const maxVal = parseFloat(item.max_marks);
            
            transcript[item.subject_id][item.exam_type] = `${val}/${maxVal}`;
            transcript[item.subject_id].Total += val;
            transcript[item.subject_id].MaxTotal += maxVal;
            
            if (item.exam_type === 'Final') {
              transcript[item.subject_id].Grade = item.grade;
            }
          });
          setMyTranscript(Object.values(transcript));
        } else {
          // Fetch parameters for grader
          const courseRes = await api.get('/api/courses');
          setCourses(courseRes.data);
          if (courseRes.data.length > 0) setSelectedCourse(courseRes.data[0].id);

          const subRes = await api.get('/api/subjects');
          setSubjects(subRes.data);
          if (subRes.data.length > 0) setSelectedSubject(subRes.data[0].id);
        }
      } catch (err) {
        console.error('Failed to init marks portal:', err);
        setError('Could not retrieve metadata parameters from server.');
      } finally {
        setLoading(false);
      }
    };
    initData();
  }, [user]);

  // 2. Fetch marks sheet
  const loadMarksSheet = async (e) => {
    if (e) e.preventDefault();
    if (!selectedCourse || !selectedSemester || !selectedSubject || !selectedExam) {
      alert('Please fill all filters.');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');
    try {
      const response = await api.get('/api/marks', {
        params: {
          course_id: selectedCourse,
          semester: selectedSemester,
          subject_id: selectedSubject,
          exam_type: selectedExam
        }
      });
      setStudentsSheet(response.data.records);
      setIsEntered(response.data.entered);
      setSheetLoaded(true);
    } catch (err) {
      console.error('Failed to load marks roll sheet:', err);
      setError('Could not download marksheet grid from server.');
    } finally {
      setLoading(false);
    }
  };

  // Change student score
  const handleMarksChange = (studentId, key, val) => {
    setStudentsSheet(prev =>
      prev.map(s => {
        if (s.student_id === studentId) {
          const updated = { ...s, [key]: val };
          // Auto-calculate grade letter on change for quick visualization
          const percent = parseFloat(updated.max_marks) > 0 ? (parseFloat(updated.marks) / parseFloat(updated.max_marks)) * 100 : 0;
          updated.grade = getLetterGrade(percent);
          return updated;
        }
        return s;
      })
    );
  };

  // 3. Save marks sheet
  const handleSaveMarks = async () => {
    setSubmitting(true);
    setError('');
    setSuccess('');
    try {
      // Validate all inputs first
      for (const s of studentsSheet) {
        if (isNaN(s.marks) || s.marks < 0 || s.marks > s.max_marks) {
          throw new Error(`Invalid score for roll no ${s.roll_number}. Score must be between 0 and maximum mark (${s.max_marks}).`);
        }
      }

      const payload = {
        course_id: selectedCourse,
        semester: selectedSemester,
        subject_id: selectedSubject,
        exam_type: selectedExam,
        records: studentsSheet.map(s => ({
          student_id: s.student_id,
          marks: parseFloat(s.marks),
          max_marks: parseFloat(s.max_marks)
        }))
      };

      await api.post('/api/marks', payload);
      setSuccess('Student marks logged successfully!');
      setIsEntered(true);
      setTimeout(() => setSuccess(''), 5000);
    } catch (err) {
      console.error('Failed to submit marks sheet:', err);
      setError(err.message || 'Failed to submit student grades.');
    } finally {
      setSubmitting(false);
    }
  };

  const getFilteredSubjects = () => {
    return subjects.filter(
      sub => sub.course_id === parseInt(selectedCourse) && sub.semester === parseInt(selectedSemester)
    );
  };

  useEffect(() => {
    if (selectedCourse && selectedSemester && subjects.length > 0) {
      const filtered = getFilteredSubjects();
      if (filtered.length > 0) {
        setSelectedSubject(filtered[0].id);
      } else {
        setSelectedSubject('');
      }
    }
  }, [selectedCourse, selectedSemester, subjects]);

  if (loading && !sheetLoaded) return <Loading size="lg" className="min-h-[70vh]" />;

  // ----------------------------------------------------
  // WORKFLOW A: Student Transcript View
  // ----------------------------------------------------
  if (user.role === 'Student') {
    // Generate charts data based on transcript Final grades
    const chartData = myTranscript
      .filter(t => t.Grade !== '-')
      .map(t => {
        // Extract final grade percent e.g. "36/40" -> 90%
        const finalStr = t.Final;
        let percent = 0;
        if (finalStr && finalStr !== '-') {
          const [got, max] = finalStr.split('/').map(Number);
          percent = max > 0 ? parseFloat(((got / max) * 100).toFixed(1)) : 0;
        }
        return {
          subject: t.subject_code,
          percentage: percent
        };
      });

    return (
      <div className="space-y-8 page-transition">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Academic Grade Sheet</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Review your semester examination transcripts and grade points.</p>
        </div>

        {error && <ErrorMessage message={error} />}

        {/* Charts Performance */}
        {chartData.length > 0 && (
          <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium">
            <h3 className="text-base font-bold text-slate-800 mb-6 tracking-tight">Final Examinations Performance (%)</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} domain={[0, 100]} />
                  <Tooltip contentStyle={{ borderRadius: '16px' }} formatter={(val) => [`${val}%`, 'Final Score']} />
                  <Bar dataKey="percentage" fill="#3b70ff" radius={[8, 8, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Transcript Table */}
        <div className="bg-white border border-slate-100 rounded-[32px] overflow-hidden shadow-premium">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-100 text-slate-500 text-xs font-bold uppercase tracking-wider">
                  <th className="px-6 py-4">Subject</th>
                  <th className="px-6 py-4 text-center">Internal (20)</th>
                  <th className="px-6 py-4 text-center">Midterm (30)</th>
                  <th className="px-6 py-4 text-center">Assignment (10)</th>
                  <th className="px-6 py-4 text-center">Final Exam (40)</th>
                  <th className="px-6 py-4 text-center">Cumulative (100)</th>
                  <th className="px-6 py-4 text-center">Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-semibold text-slate-700">
                {myTranscript.length > 0 ? (
                  myTranscript.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/40 transition-colors">
                      <td className="px-6 py-4">
                        <span className="block font-bold text-slate-800">{row.subject_name}</span>
                        <span className="text-[10px] font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-md mt-1 inline-block">
                          {row.subject_code} • {row.credits} Credits
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center text-slate-500">{row.Internal}</td>
                      <td className="px-6 py-4 text-center text-slate-500">{row.Midterm}</td>
                      <td className="px-6 py-4 text-center text-slate-500">{row.Assignment}</td>
                      <td className="px-6 py-4 text-center font-bold text-slate-800">{row.Final}</td>
                      <td className="px-6 py-4 text-center font-extrabold text-brand-600">
                        {row.MaxTotal > 0 ? `${row.Total.toFixed(1)}/${row.MaxTotal.toFixed(1)}` : '0/0'}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`text-xs font-extrabold px-3 py-1 rounded-xl inline-block w-12 text-center ${
                          row.Grade === 'F' ? 'text-red-700 bg-red-50 border border-red-200' :
                          row.Grade === '-' ? 'text-slate-400 bg-slate-50' : 'text-brand-700 bg-brand-50 border border-brand-100'
                        }`}>
                          {row.Grade}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="px-6 py-12 text-center text-slate-400 text-sm font-medium">
                      No academic grade reports published for your account.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // WORKFLOW B: Faculty Grader Panel View
  // ----------------------------------------------------
  const filteredSubjectsList = getFilteredSubjects();

  return (
    <div className="space-y-8 page-transition">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Marks & Grading portal</h1>
        <p className="text-sm text-slate-500 font-medium mt-1">Record academic test results, midterms, and finals for students.</p>
      </div>

      {success && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{success}</span>
        </div>
      )}

      {error && <ErrorMessage message={error} />}

      {/* Configuration board */}
      <div className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-premium space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-50 pb-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Select Marksheet</span>
        </div>

        <form onSubmit={loadMarksSheet} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 items-end">
          {/* Course */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Course Program</label>
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            >
              {courses.map(c => (
                <option key={c.id} value={c.id}>{c.course_code}</option>
              ))}
            </select>
          </div>

          {/* Semester */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Semester</label>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                <option key={s} value={String(s)}>Semester {s}</option>
              ))}
            </select>
          </div>

          {/* Subject */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Course Subject</label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
              disabled={filteredSubjectsList.length === 0}
            >
              {filteredSubjectsList.length > 0 ? (
                filteredSubjectsList.map(s => (
                  <option key={s.id} value={s.id}>{s.subject_code}</option>
                ))
              ) : (
                <option value="">No Subjects Found</option>
              )}
            </select>
          </div>

          {/* Exam Type */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5">Exam Component</label>
            <select
              value={selectedExam}
              onChange={(e) => setSelectedExam(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-2xl outline-none text-xs font-semibold text-slate-600"
            >
              <option value="Internal">Internal Assessment (20)</option>
              <option value="Midterm">Midterm Examination (30)</option>
              <option value="Assignment">Home Assignment (10)</option>
              <option value="Practical">Laboratory / Practical (20)</option>
              <option value="Final">End Semester Examination (40)</option>
            </select>
          </div>

          {/* Load Button */}
          <button
            type="submit"
            className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-2xl transition duration-150 shadow-md shadow-brand-500/10"
          >
            Load Marksheet
          </button>
        </form>
      </div>

      {/* Grader Panel Sheet */}
      {sheetLoaded && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          {/* Left panel: Grader Table */}
          <div className="bg-white border border-slate-100 rounded-[32px] p-6 shadow-premium lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-brand-500" />
                Gradesheet Input: {selectedExam}
              </h3>
              <p className="text-xs text-slate-400 font-semibold mt-1">Enter scores in the boxes below. Max marks are editable.</p>
            </div>

            {loading ? (
              <Loading size="md" />
            ) : studentsSheet.length === 0 ? (
              <p className="text-center text-sm font-semibold text-slate-400 py-10">
                No active students registered for this course/semester.
              </p>
            ) : (
              <div className="overflow-x-auto space-y-6">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                      <th className="pb-3">Roll No</th>
                      <th className="pb-3">Student Name</th>
                      <th className="pb-3 text-center" style={{ width: '100px' }}>Score</th>
                      <th className="pb-3 text-center" style={{ width: '100px' }}>Max Score</th>
                      <th className="pb-3 text-center">Grade Letter</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 text-sm font-semibold text-slate-700">
                    {studentsSheet.map((student, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/20">
                        <td className="py-3 text-slate-500">{student.roll_number}</td>
                        <td className="py-3 text-slate-800">
                          {student.first_name} {student.last_name}
                        </td>
                        <td className="py-3 text-center">
                          <input
                            type="number"
                            min="0"
                            max={student.max_marks}
                            step="0.5"
                            value={student.marks}
                            onChange={(e) => handleMarksChange(student.student_id, 'marks', e.target.value)}
                            className="w-16 px-2 py-1 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-lg text-center font-bold text-slate-800 outline-none"
                          />
                        </td>
                        <td className="py-3 text-center">
                          <input
                            type="number"
                            min="1"
                            value={student.max_marks}
                            onChange={(e) => handleMarksChange(student.student_id, 'max_marks', e.target.value)}
                            className="w-16 px-2 py-1 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-lg text-center font-bold text-slate-500 outline-none"
                          />
                        </td>
                        <td className="py-3 text-center">
                          <span className={`text-xs font-extrabold px-2.5 py-1 rounded-xl inline-block w-10 text-center ${
                            student.grade === 'F' ? 'text-red-700 bg-red-50 border border-red-100' :
                            student.grade === '' ? 'text-slate-400 bg-slate-50' : 'text-brand-700 bg-brand-50'
                          }`}>
                            {student.grade || '-'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Submit footer */}
                <div className="flex items-center justify-end border-t border-slate-100 pt-6 mt-4">
                  <button
                    type="button"
                    onClick={handleSaveMarks}
                    className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 text-white font-bold rounded-xl shadow-md shadow-brand-500/10 flex items-center justify-center gap-2 transition active:scale-95 text-sm"
                    disabled={submitting}
                  >
                    {submitting ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      'Publish Student Grades'
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right panel: Grading Rules Help */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-[32px] text-white shadow-premium space-y-6">
            <h3 className="text-sm font-bold uppercase tracking-widest text-brand-400 flex items-center gap-2 border-b border-slate-800 pb-3">
              <Info className="w-4 h-4 text-brand-500" />
              Grading Schema Rules
            </h3>
            <p className="text-xs text-slate-400 font-medium leading-relaxed">
              Letter grades and corresponding Grade Point (GPA) rankings are computed automatically by the server on percentage scores:
            </p>
            <div className="space-y-3 font-semibold text-sm">
              <div className="flex items-center justify-between text-slate-200">
                <span>90% - 100%</span>
                <span className="text-brand-400 bg-brand-500/10 px-2 py-0.5 rounded border border-brand-500/20">Grade A+ (GPA 10)</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>80% - 89%</span>
                <span className="text-brand-400 bg-brand-500/10 px-2 py-0.5 rounded border border-brand-500/20">Grade A (GPA 9)</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>70% - 79%</span>
                <span className="text-slate-300 bg-slate-800 px-2 py-0.5 rounded">Grade B+ (GPA 8)</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>60% - 69%</span>
                <span className="text-slate-300 bg-slate-800 px-2 py-0.5 rounded">Grade B (GPA 7)</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>50% - 59%</span>
                <span className="text-slate-300 bg-slate-800 px-2 py-0.5 rounded">Grade C (GPA 6)</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>40% - 49%</span>
                <span className="text-slate-400 bg-slate-850 px-2 py-0.5 rounded">Grade D (GPA 5)</span>
              </div>
              <div className="flex items-center justify-between text-red-400">
                <span>Below 40%</span>
                <span className="text-red-400 bg-red-950/20 px-2 py-0.5 rounded border border-red-500/10">Grade F (GPA 0)</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marks;
