import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { 
  User, Award, Calendar, Library, GraduationCap, 
  Phone, Mail, MapPin, Heart, AlertTriangle, ArrowLeft, Printer 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const StudentProfile = () => {
  const { id } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();

  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('personal');

  const fetchProfile = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get(`/api/students/${id}`);
      setStudent(response.data);
    } catch (err) {
      console.error('Failed to load student details:', err);
      setError('Could not fetch detailed student profile from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [id]);

  if (loading) return <Loading size="lg" className="min-h-[70vh]" />;
  if (error) return <ErrorMessage message={error} onRetry={fetchProfile} />;
  if (!student) return null;

  // Aggregate student marks by subject for clean visualization
  const getSubjectMarksTable = () => {
    const table = {};
    
    // Seed from subjects list first to ensure all enrolled subjects appear
    student.subjectsList.forEach(sub => {
      table[sub.id] = {
        subject_name: sub.subject_name,
        subject_code: sub.subject_code,
        credits: sub.credits,
        Internal: '-',
        Midterm: '-',
        Assignment: '-',
        Final: '-',
        Total: 0,
        MaxTotal: 0,
        Grade: '-'
      };
    });

    // Populate marks records
    student.marksList.forEach(m => {
      if (!table[m.subject_id]) return; // Enrolled in subject but not seeded
      
      const val = parseFloat(m.marks);
      const maxVal = parseFloat(m.max_marks);
      
      table[m.subject_id][m.exam_type] = `${val}/${maxVal}`;
      table[m.subject_id].Total += val;
      table[m.subject_id].MaxTotal += maxVal;

      if (m.exam_type === 'Final') {
        table[m.subject_id].Grade = m.grade;
      }
    });

    return Object.values(table);
  };

  const aggregatedGrades = getSubjectMarksTable();

  // Print Profile Action
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 page-transition print-area">
      {/* Top action bar */}
      <div className="flex items-center justify-between no-print">
        <button
          onClick={() => {
            if (currentUser.role === 'Student') {
              navigate('/student-dashboard');
            } else {
              navigate('/students');
            }
          }}
          className="flex items-center gap-2 text-slate-500 hover:text-slate-800 text-sm font-bold bg-white border border-slate-200 px-4 py-2.5 rounded-2xl shadow-sm transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <button
          onClick={handlePrint}
          className="flex items-center gap-2 text-brand-600 hover:text-brand-700 text-sm font-bold bg-brand-50 border border-brand-200 px-4 py-2.5 rounded-2xl shadow-sm transition-all"
        >
          <Printer className="w-4 h-4" />
          Print Profile
        </button>
      </div>

      {/* Profile Header Card */}
      <div className="bg-white border border-slate-100 p-8 rounded-[32px] shadow-premium flex flex-col md:flex-row items-center gap-8 relative overflow-hidden print-card">
        {/* Profile Avatar (Initials block) */}
        <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-[24px] bg-brand-500 text-white font-extrabold text-4xl flex items-center justify-center shadow-lg shadow-brand-500/10 shrink-0">
          {student.first_name[0]}{student.last_name[0]}
        </div>

        <div className="text-center md:text-left flex-1 space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-center md:justify-start gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-800 tracking-tight leading-none">
              {student.first_name} {student.last_name}
            </h1>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider self-center ${
              student.status === 'Active' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
            }`}>
              {student.status}
            </span>
          </div>
          <p className="text-sm text-slate-500 font-semibold">
            Student ID: <span className="text-slate-800">{student.student_id}</span> • Roll Number: <span className="text-slate-800">{student.roll_number}</span>
          </p>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">
            {student.course_name} • Semester {student.semester}
          </p>
        </div>

        {/* Aggregate KPI blocks */}
        <div className="flex gap-4 border-t md:border-t-0 md:border-l border-slate-100 pt-6 md:pt-0 md:pl-8 shrink-0">
          <div className="text-center bg-slate-50 border border-slate-100 px-5 py-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Attendance</span>
            <span className={`text-xl font-extrabold mt-1 block ${
              student.attendancePercentage < 75 ? 'text-red-600' : 'text-emerald-600'
            }`}>
              {student.attendancePercentage}%
            </span>
          </div>
          <div className="text-center bg-slate-50 border border-slate-100 px-5 py-3 rounded-2xl">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">CGPA</span>
            <span className="text-xl font-extrabold text-brand-600 mt-1 block">
              {student.cgpa}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Menu Selector */}
      <div className="flex border-b border-slate-200 overflow-x-auto no-print">
        {[
          { id: 'personal', label: 'Personal Information', icon: User },
          { id: 'academic', label: 'Academic Details', icon: GraduationCap },
          { id: 'attendance', label: 'Attendance logs', icon: Calendar },
          { id: 'marks', label: 'Marks & Transcript', icon: Award },
          { id: 'subjects', label: 'Enrolled Subjects', icon: Library }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-4 border-b-2 font-semibold text-sm whitespace-nowrap transition-colors duration-150 ${
                activeTab === tab.id 
                  ? 'border-brand-500 text-brand-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="bg-white border border-slate-100 p-8 rounded-[32px] shadow-premium print-card">
        {/* TABS 1: Personal Info */}
        {activeTab === 'personal' && (
          <div className="space-y-6">
            <h3 className="text-base font-bold text-slate-800 border-b border-slate-100 pb-2 tracking-tight">Personal Profile</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-500 font-semibold">Gender:</span>
                  <span className="text-slate-800 font-bold">{student.gender}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-500 font-semibold">Date of Birth:</span>
                  <span className="text-slate-800 font-bold">{student.dob ? student.dob.split('T')[0] : ''}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Heart className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-500 font-semibold">Blood Group:</span>
                  <span className="text-slate-800 font-bold">{student.blood_group || 'N/A'}</span>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-slate-500 font-semibold">Address:</span>
                    <p className="text-slate-800 font-bold mt-1">{student.address || 'Address details not logged.'}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-500 font-semibold">Email ID:</span>
                  <span className="text-slate-800 font-bold">{student.email}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-500 font-semibold">Contact Phone:</span>
                  <span className="text-slate-800 font-bold">{student.phone || 'N/A'}</span>
                </div>
                
                {/* Parent details */}
                <div className="pt-4 border-t border-slate-100 mt-4 space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Parent / Guardian details</h4>
                  <p className="text-slate-700 font-semibold">Name: <span className="text-slate-800 font-bold">{student.parent_name || 'N/A'}</span></p>
                  <p className="text-slate-700 font-semibold">Phone: <span className="text-slate-800 font-bold">{student.parent_phone || 'N/A'}</span></p>
                  <p className="text-slate-700 font-semibold">Email: <span className="text-slate-800 font-bold">{student.parent_email || 'N/A'}</span></p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TABS 2: Academic Details */}
        {activeTab === 'academic' && (
          <div className="space-y-6">
            <h3 className="text-base font-bold text-slate-800 border-b border-slate-100 pb-2 tracking-tight">Academic Profile</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm font-semibold text-slate-700">
              <div className="space-y-4">
                <p>Student ID: <span className="text-slate-800 font-bold">{student.student_id}</span></p>
                <p>Roll Number: <span className="text-slate-800 font-bold">{student.roll_number}</span></p>
                <p>Department: <span className="text-slate-800 font-bold">{student.department_name}</span></p>
                <p>Degree Course: <span className="text-slate-800 font-bold">{student.course_name}</span></p>
              </div>
              <div className="space-y-4">
                <p>Enrolled Year: <span className="text-slate-800 font-bold">Year {student.year}</span></p>
                <p>Semester Enrolled: <span className="text-slate-800 font-bold">Semester {student.semester}</span></p>
                <p>Admission Date: <span className="text-slate-800 font-bold">{student.admission_date ? student.admission_date.split('T')[0] : ''}</span></p>
                <p>Status: <span className="text-slate-800 font-bold">{student.status}</span></p>
              </div>
            </div>
          </div>
        )}

        {/* TABS 3: Attendance Logs */}
        {activeTab === 'attendance' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-800 tracking-tight">Attendance Ledger</h3>
              {student.attendancePercentage < 75 && (
                <span className="flex items-center gap-1 text-[10px] font-extrabold uppercase text-red-600 bg-red-50 px-2.5 py-1 rounded-xl">
                  <AlertTriangle className="w-3.5 h-3.5" /> Deficit Alert
                </span>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <th className="pb-3">Code</th>
                    <th className="pb-3">Subject Name</th>
                    <th className="pb-3 text-center">Total classes</th>
                    <th className="pb-3 text-center">Present</th>
                    <th className="pb-3 text-center">Absent</th>
                    <th className="pb-3 pr-4" style={{ width: '180px' }}>Presence Rate</th>
                    <th className="pb-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm font-semibold text-slate-700">
                  {student.attendanceStats.length > 0 ? (
                    student.attendanceStats.map((item, idx) => {
                      const total = item.total_classes || 0;
                      const present = item.present_count || 0;
                      const percent = total > 0 ? parseFloat(((present / total) * 100).toFixed(0)) : 100;
                      const isSubLow = percent < 75;

                      return (
                        <tr key={idx} className="hover:bg-slate-50/20">
                          <td className="py-4 text-brand-600 font-bold">{item.subject_code}</td>
                          <td className="py-4 text-slate-800 pr-2">{item.subject_name}</td>
                          <td className="py-4 text-center">{total}</td>
                          <td className="py-4 text-center text-emerald-600">{present}</td>
                          <td className="py-4 text-center text-red-500">{item.absent_count || 0}</td>
                          <td className="py-4 pr-4">
                            <div className="flex items-center gap-2">
                              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full rounded-full ${isSubLow ? 'bg-red-500' : 'bg-emerald-500'}`}
                                  style={{ width: `${percent}%` }}
                                ></div>
                              </div>
                              <span className="text-xs font-bold">{percent}%</span>
                            </div>
                          </td>
                          <td className="py-4 text-center">
                            <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                              isSubLow ? 'text-red-700 bg-red-50' : 'text-emerald-700 bg-emerald-50'
                            }`}>
                              {isSubLow ? 'Deficit' : 'Good'}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan="7" className="py-8 text-center text-slate-400 text-xs">
                        No class attendance sessions logged.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TABS 4: Marks Transcript */}
        {activeTab === 'marks' && (
          <div className="space-y-6">
            <h3 className="text-base font-bold text-slate-800 border-b border-slate-100 pb-2 tracking-tight">Academic Grade Transcript</h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 text-xs font-bold uppercase tracking-wider">
                    <th className="pb-3 pr-2">Subject</th>
                    <th className="pb-3 text-center">Internal</th>
                    <th className="pb-3 text-center">Midterm</th>
                    <th className="pb-3 text-center">Assignment</th>
                    <th className="pb-3 text-center">Final</th>
                    <th className="pb-3 text-center">Total score</th>
                    <th className="pb-3 text-center">Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-sm font-semibold text-slate-700">
                  {aggregatedGrades.length > 0 ? (
                    aggregatedGrades.map((item, idx) => {
                      // If maxTotal is > 0, calculate overall percentage
                      const scoreText = item.MaxTotal > 0 ? `${item.Total.toFixed(1)}/${item.MaxTotal.toFixed(1)}` : '0/0';
                      return (
                        <tr key={idx} className="hover:bg-slate-50/20">
                          <td className="py-4 text-slate-800 pr-4">
                            <span className="block font-bold text-slate-800">{item.subject_name}</span>
                            <span className="text-[10px] font-bold text-brand-600 bg-brand-50 px-1.5 py-0.5 rounded-md mt-0.5 inline-block">
                              {item.subject_code} • {item.credits} Credits
                            </span>
                          </td>
                          <td className="py-4 text-center">{item.Internal}</td>
                          <td className="py-4 text-center">{item.Midterm}</td>
                          <td className="py-4 text-center">{item.Assignment}</td>
                          <td className="py-4 text-center font-bold text-slate-800">{item.Final}</td>
                          <td className="py-4 text-center font-extrabold text-brand-600">{scoreText}</td>
                          <td className="py-4 text-center">
                            <span className={`text-xs font-extrabold px-2.5 py-1 rounded-xl block w-10 mx-auto text-center ${
                              item.Grade === 'F' ? 'text-red-700 bg-red-50' :
                              item.Grade === '-' ? 'text-slate-400 bg-slate-50' : 'text-brand-700 bg-brand-50'
                            }`}>
                              {item.Grade}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan="7" className="py-8 text-center text-slate-400 text-xs">
                        No subject grades recorded.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TABS 5: Enrolled Subjects */}
        {activeTab === 'subjects' && (
          <div className="space-y-6">
            <h3 className="text-base font-bold text-slate-800 border-b border-slate-100 pb-2 tracking-tight">Current Course Work Subjects</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {student.subjectsList.length > 0 ? (
                student.subjectsList.map((sub, idx) => (
                  <div key={idx} className="p-5 bg-slate-50 border border-slate-100 rounded-3xl flex items-center justify-between hover:border-slate-200 transition-colors">
                    <div>
                      <span className="text-[10px] font-bold text-brand-600 uppercase tracking-widest">{sub.subject_code}</span>
                      <h4 className="text-sm font-bold text-slate-800 mt-1">{sub.subject_name}</h4>
                      <p className="text-xs text-slate-400 font-semibold mt-1">Instructor: {sub.faculty_name || 'Unassigned'}</p>
                    </div>
                    <div className="text-center bg-white border border-slate-200/60 w-12 h-12 flex flex-col justify-center items-center rounded-xl shadow-xs">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Credits</span>
                      <span className="text-sm font-extrabold text-slate-800">{sub.credits}</span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="col-span-2 text-center text-xs text-slate-400 py-10">No subjects currently assigned to this semester.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentProfile;
