import React, { useState, useEffect } from 'react';
import api from '../services/api';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import { Plus, Edit2, Trash2, Check } from 'lucide-react';

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Form states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({
    course_name: '', course_code: '', department_id: '',
    duration: '4', semesters: '8', description: '', status: 'Active'
  });
  const [fieldErrors, setFieldErrors] = useState({});

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const courseRes = await api.get('/api/courses');
      setCourses(courseRes.data);

      const deptRes = await api.get('/api/departments');
      setDepartments(deptRes.data);
    } catch (err) {
      console.error('Failed to load courses portal:', err);
      setError('Could not retrieve courses logs from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errors = {};
    if (!form.course_name.trim()) errors.course_name = 'Course name is required.';
    if (!form.course_code.trim()) errors.course_code = 'Code is required (e.g. BTech-CSE).';
    if (!form.department_id) errors.department_id = 'Department is required.';
    if (!form.duration || parseInt(form.duration) <= 0) errors.duration = 'Duration must be greater than 0.';
    if (!form.semesters || parseInt(form.semesters) <= 0) errors.semesters = 'Semesters must be greater than 0.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenAdd = () => {
    setIsEditing(false);
    setEditId(null);
    setFieldErrors({});
    setForm({
      course_name: '', course_code: '', department_id: departments[0]?.id || '',
      duration: '4', semesters: '8', description: '', status: 'Active'
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (course) => {
    setIsEditing(true);
    setEditId(course.id);
    setFieldErrors({});
    setForm({
      course_name: course.course_name,
      course_code: course.course_code,
      department_id: course.department_id || '',
      duration: String(course.duration),
      semesters: String(course.semesters),
      description: course.description || '',
      status: course.status
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      if (isEditing) {
        await api.put(`/api/courses/${editId}`, form);
        setSuccessMsg('Course program updated successfully.');
      } else {
        await api.post('/api/courses', form);
        setSuccessMsg('Course program added successfully.');
      }
      setIsModalOpen(false);
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Submit course error:', err);
      alert(err.response?.data?.message || 'Failed to submit form.');
    }
  };

  const handleDelete = async (id, name) => {
    const confirm = window.confirm(`Are you absolutely sure you want to delete course "${name}"?\nWarning: This will delete all student records and subjects registered under this course.`);
    if (!confirm) return;

    try {
      await api.delete(`/api/courses/${id}`);
      setSuccessMsg('Course deleted successfully.');
      loadData();
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (err) {
      console.error('Delete course error:', err);
      alert(err.response?.data?.message || 'Failed to delete course.');
    }
  };

  const headers = [
    { label: 'Code', key: 'course_code', className: 'font-bold text-slate-800' },
    { label: 'Course Name', key: 'course_name' },
    { label: 'Department', key: 'department_name', className: 'text-xs text-slate-500 font-bold' },
    { label: 'Duration', render: (row) => `${row.duration} Years` },
    { label: 'Semesters', render: (row) => `${row.semesters} Sems` },
    { 
      label: 'Status', 
      render: (row) => (
        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
          row.status === 'Active' ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
        }`}>
          {row.status}
        </span>
      ) 
    },
    {
      label: 'Actions',
      className: 'text-right no-print',
      render: (row) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={() => handleOpenEdit(row)}
            className="p-1.5 text-slate-400 hover:text-amber-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleDelete(row.id, row.course_name)}
            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-slate-50 rounded-lg transition-colors"
            title="Delete Course"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 page-transition">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">Course Offerings</h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Manage academic degree curriculums and lengths.</p>
        </div>
        <div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white font-bold rounded-2xl shadow-lg shadow-brand-500/20 transition-all text-sm flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Course
          </button>
        </div>
      </div>

      {/* Success Notification Bar */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-2xl flex items-center gap-3 shadow-premium">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-sm font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Table grid */}
      <DataTable
        headers={headers}
        data={courses}
        loading={loading}
        emptyMessage="No courses registered."
      />

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Modify Course Structure' : 'Create New Course'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Course Code *</label>
              <input
                type="text"
                name="course_code"
                placeholder="e.g. BTech-CSE"
                value={form.course_code}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  fieldErrors.course_code ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
                disabled={isEditing}
              />
              {fieldErrors.course_code && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.course_code}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Course Name *</label>
              <input
                type="text"
                name="course_name"
                placeholder="e.g. B.Tech Computer Science"
                value={form.course_name}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  fieldErrors.course_name ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              />
              {fieldErrors.course_name && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.course_name}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Department *</label>
              <select
                name="department_id"
                value={form.department_id}
                onChange={handleChange}
                className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                  fieldErrors.department_id ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                }`}
              >
                <option value="">Select Department</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.department_name}</option>
                ))}
              </select>
              {fieldErrors.department_id && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.department_id}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Duration (Years) *</label>
                <input
                  type="number"
                  name="duration"
                  value={form.duration}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    fieldErrors.duration ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {fieldErrors.duration && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.duration}</p>}
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500 block mb-1">Semesters *</label>
                <input
                  type="number"
                  name="semesters"
                  value={form.semesters}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-slate-50 border rounded-xl outline-none text-sm font-semibold ${
                    fieldErrors.semesters ? 'border-red-500' : 'border-slate-200 focus:border-brand-500'
                  }`}
                />
                {fieldErrors.semesters && <p className="text-[10px] text-red-500 mt-0.5 font-semibold">{fieldErrors.semesters}</p>}
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="text-xs font-bold text-slate-500 block mb-1">Description</label>
              <textarea
                name="description"
                rows="2"
                value={form.description}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-500 block mb-1">Status</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 focus:border-brand-500 rounded-xl outline-none text-sm font-semibold"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-6">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold rounded-xl transition duration-150"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-brand-500 hover:bg-brand-600 active:scale-95 text-white text-sm font-bold rounded-xl transition duration-150 shadow-md shadow-brand-500/10"
            >
              {isEditing ? 'Save Changes' : 'Create Course'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Courses;
