import api from './api';

export const login = async (email, password) => {
  const response = await api.post('/api/auth/login', { email, password });
  return response.data; // Returns { token, user: { id, username, email, role, profile } }
};

export const register = async (username, email, password, role) => {
  const response = await api.post('/api/auth/register', { username, email, password, role });
  return response.data;
};

export const getMe = async () => {
  const response = await api.get('/api/auth/me');
  return response.data; // Returns { user }
};

export const changePassword = async (currentPassword, newPassword) => {
  const response = await api.put('/api/auth/change-password', { currentPassword, newPassword });
  return response.data;
};
