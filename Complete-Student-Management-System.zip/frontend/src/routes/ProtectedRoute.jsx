import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Loading from '../components/Loading';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loading size="lg" />
      </div>
    );
  }

  // Not authenticated, redirect to login
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Role checking
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    console.warn(`Unauthorized access attempt by ${user.role} to ${location.pathname}`);
    
    // Redirect to their respective dashboards based on role
    if (user.role === 'Admin') return <Navigate to="/admin-dashboard" replace />;
    if (user.role === 'Faculty') return <Navigate to="/faculty-dashboard" replace />;
    if (user.role === 'Student') return <Navigate to="/student-dashboard" replace />;
    
    // Default safe redirect
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default ProtectedRoute;
