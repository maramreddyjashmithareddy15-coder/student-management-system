import React from 'react';

const Loading = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4',
  };

  return (
    <div className={`flex flex-col items-center justify-center p-4 ${className}`}>
      <div
        className={`${sizeClasses[size]} rounded-full border-brand-200 border-t-brand-600 animate-spin`}
        role="status"
      ></div>
      <span className="sr-only">Loading...</span>
    </div>
  );
};

export default Loading;
