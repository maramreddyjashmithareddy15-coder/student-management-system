import React from 'react';
import { AlertCircle } from 'lucide-react';

const ErrorMessage = ({ message = 'Something went wrong. Please try again.', onRetry }) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 bg-red-50 border border-red-100 rounded-2xl max-w-lg mx-auto text-center shadow-premium my-6">
      <AlertCircle className="w-12 h-12 text-red-500 mb-3" />
      <h3 className="text-lg font-semibold text-red-800 mb-1">Request Error</h3>
      <p className="text-sm text-red-600 mb-4">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-xl transition duration-150 active:scale-95"
        >
          Try Again
        </button>
      )}
    </div>
  );
};

export default ErrorMessage;
