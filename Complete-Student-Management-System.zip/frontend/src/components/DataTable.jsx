import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const DataTable = ({ 
  headers, 
  data, 
  loading, 
  pagination, 
  onPageChange,
  emptyMessage = 'No records found.'
}) => {
  return (
    <div className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-premium flex flex-col">
      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/70 border-b border-slate-100">
              {headers.map((header, index) => (
                <th 
                  key={index} 
                  className={`px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500 ${header.className || ''}`}
                >
                  {header.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading ? (
              <tr>
                <td colSpan={headers.length} className="px-6 py-10 text-center text-slate-400">
                  <div className="flex justify-center items-center gap-2">
                    <div className="w-4 h-4 border-2 border-brand-200 border-t-brand-600 rounded-full animate-spin"></div>
                    Loading data...
                  </div>
                </td>
              </tr>
            ) : data.length === 0 ? (
              <tr>
                <td colSpan={headers.length} className="px-6 py-12 text-center text-slate-400 text-sm font-medium">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              data.map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-slate-50/40 transition-colors duration-150">
                  {headers.map((header, colIndex) => (
                    <td 
                      key={colIndex} 
                      className={`px-6 py-4 text-sm text-slate-700 font-medium ${header.className || ''}`}
                    >
                      {header.render ? header.render(row, rowIndex) : row[header.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination controls */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100 bg-slate-50/30">
          <span className="text-xs text-slate-400 font-semibold uppercase">
            Page {pagination.page} of {pagination.totalPages} ({pagination.total} total items)
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPageChange(pagination.page - 1)}
              disabled={pagination.page <= 1}
              className="p-2 hover:bg-slate-100 border border-slate-200 disabled:opacity-40 disabled:hover:bg-transparent text-slate-600 rounded-xl transition duration-150"
              aria-label="Previous page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => onPageChange(pagination.page + 1)}
              disabled={pagination.page >= pagination.totalPages}
              className="p-2 hover:bg-slate-100 border border-slate-200 disabled:opacity-40 disabled:hover:bg-transparent text-slate-600 rounded-xl transition duration-150"
              aria-label="Next page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DataTable;
