import React from 'react';

const DashboardCard = ({ title, value, icon: Icon, colorClass = 'bg-brand-500', description }) => {
  return (
    <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-premium hover:shadow-glass hover:-translate-y-1 transition-all duration-300 relative overflow-hidden group">
      {/* Background radial highlight */}
      <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-500 ease-out z-0 opacity-50"></div>
      
      <div className="flex items-center justify-between relative z-10">
        <div>
          <span className="text-slate-400 text-xs font-semibold tracking-wider uppercase">{title}</span>
          <h3 className="text-3xl font-bold text-slate-800 mt-1 tracking-tight">{value}</h3>
          {description && (
            <p className="text-slate-400 text-xs mt-1 font-medium">{description}</p>
          )}
        </div>
        <div className={`p-4 rounded-2xl text-white ${colorClass} shadow-md group-hover:scale-105 transition-transform duration-300`}>
          {Icon && <Icon className="w-6 h-6" />}
        </div>
      </div>
    </div>
  );
};

export default DashboardCard;
