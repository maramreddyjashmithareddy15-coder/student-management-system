import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Users, UserCheck, Building2, BookOpen, 
  Library, CalendarCheck, FileSpreadsheet, Bell, BarChart2, User, X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Sidebar = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  if (!user) return null;

  // Navigation configurations based on role
  const menuConfig = {
    Admin: [
      { path: '/admin-dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { path: '/students', label: 'Students', icon: Users },
      { path: '/faculty', label: 'Faculty', icon: UserCheck },
      { path: '/departments', label: 'Departments', icon: Building2 },
      { path: '/courses', label: 'Courses', icon: BookOpen },
      { path: '/subjects', label: 'Subjects', icon: Library },
      { path: '/notices', label: 'Notices', icon: Bell },
      { path: '/reports', label: 'Reports', icon: BarChart2 },
      { path: '/profile', label: 'My Profile', icon: User },
    ],
    Faculty: [
      { path: '/faculty-dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { path: '/attendance', label: 'Attendance', icon: CalendarCheck },
      { path: '/marks', label: 'Enter Marks', icon: FileSpreadsheet },
      { path: '/notices', label: 'Notice Board', icon: Bell },
      { path: '/profile', label: 'My Profile', icon: User },
    ],
    Student: [
      { path: '/student-dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { path: '/attendance', label: 'My Attendance', icon: CalendarCheck },
      { path: '/marks', label: 'My Grades', icon: FileSpreadsheet },
      { path: '/notices', label: 'Notices', icon: Bell },
      { path: '/profile', label: 'My Profile', icon: User },
    ]
  };

  const menuItems = menuConfig[user.role] || [];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-900/30 backdrop-blur-xs lg:hidden no-print" 
          onClick={onClose}
        ></div>
      )}

      {/* Sidebar Panel */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-100 flex flex-col no-print
        transition-transform duration-300 lg:translate-x-0 lg:static lg:h-full lg:z-10
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Mobile Close Button */}
        <div className="flex items-center justify-end p-4 lg:hidden">
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded-xl"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Card */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mx-auto mb-3 shadow-sm">
            <User className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-800 text-sm tracking-tight">{user.username}</h3>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1 block">
            {user.role} Portal
          </span>
        </div>

        {/* Links Navigation */}
        <nav className="flex-1 px-4 py-6 overflow-y-auto space-y-1">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={index}
                to={item.path}
                onClick={onClose} // Auto close on mobile click
                className={({ isActive }) => `
                  flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-semibold tracking-wide transition-all duration-200
                  ${isActive 
                    ? 'bg-brand-500 text-white shadow-md shadow-brand-500/20 hover:bg-brand-600' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'}
                `}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </NavLink>
            );
          })}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
