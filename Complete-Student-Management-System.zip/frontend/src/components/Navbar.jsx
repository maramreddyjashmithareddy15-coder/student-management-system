import React from 'react';
import { Menu, LogOut, User as UserIcon, GraduationCap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Navbar = ({ onMenuToggle }) => {
  const { user, logoutUser } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logoutUser();
    navigate('/login');
  };

  // Get name to display based on profile or username
  const getUserName = () => {
    if (!user) return 'Guest';
    if (user.role === 'Student' && user.profile) {
      return `${user.profile.first_name} ${user.profile.last_name}`;
    }
    if (user.role === 'Faculty' && user.profile) {
      return user.profile.name;
    }
    return user.username;
  };

  return (
    <header className="bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between sticky top-0 z-30 shadow-sm no-print">
      <div className="flex items-center gap-4">
        {/* Hamburger triggers on mobile */}
        <button
          onClick={onMenuToggle}
          className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-50 rounded-xl lg:hidden transition-colors"
          aria-label="Toggle menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-brand-600">
          <GraduationCap className="w-8 h-8" />
          <span className="text-xl font-bold tracking-tight text-slate-800">CAMPUS<span className="text-brand-600 font-extrabold">LINK</span></span>
        </div>
      </div>

      {user && (
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <h4 className="text-sm font-bold text-slate-800 tracking-tight leading-none">{getUserName()}</h4>
            <span className="text-[10px] font-semibold text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full inline-block mt-1 uppercase tracking-wider">
              {user.role}
            </span>
          </div>

          {/* Profile link */}
          <button
            onClick={() => navigate('/profile')}
            className="p-2 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-xl transition-all duration-200"
            title="My Profile"
          >
            <UserIcon className="w-5 h-5" />
          </button>

          {/* Logout */}
          <button
            onClick={handleLogout}
            className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-200"
            title="Log Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      )}
    </header>
  );
};

export default Navbar;
