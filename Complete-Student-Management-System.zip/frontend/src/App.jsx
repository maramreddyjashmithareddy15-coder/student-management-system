import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './routes/ProtectedRoute';

// Layout components
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';

// Views
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import FacultyDashboard from './pages/FacultyDashboard';
import StudentDashboard from './pages/StudentDashboard';
import Students from './pages/Students';
import StudentProfile from './pages/StudentProfile';
import Faculty from './pages/Faculty';
import Departments from './pages/Departments';
import Courses from './pages/Courses';
import Subjects from './pages/Subjects';
import Attendance from './pages/Attendance';
import Marks from './pages/Marks';
import Notices from './pages/Notices';
import Reports from './pages/Reports';
import Profile from './pages/Profile';

// authenticated dashboard container layout
const DashboardLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Sidebar navigation */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main content display screen */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navbar */}
        <Navbar onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />

        {/* Dynamic page outlet */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <BrowserRouter basename={import.meta.env.BASE_URL}>
        <Routes>
          {/* Public login */}
          <Route path="/login" element={<Login />} />

          {/* Protected Portal Dashboards */}
          <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
            
            {/* Common / shared routes */}
            <Route path="/profile" element={<Profile />} />
            <Route path="/notices" element={<Notices />} />
            <Route path="/attendance" element={<Attendance />} />
            <Route path="/marks" element={<Marks />} />
            <Route path="/student-profile/:id" element={<StudentProfile />} />

            {/* Admin only views */}
            <Route 
              path="/admin-dashboard" 
              element={<ProtectedRoute allowedRoles={['Admin']}><AdminDashboard /></ProtectedRoute>} 
            />
            <Route 
              path="/students" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Students /></ProtectedRoute>} 
            />
            <Route 
              path="/faculty" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Faculty /></ProtectedRoute>} 
            />
            <Route 
              path="/departments" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Departments /></ProtectedRoute>} 
            />
            <Route 
              path="/courses" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Courses /></ProtectedRoute>} 
            />
            <Route 
              path="/subjects" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Subjects /></ProtectedRoute>} 
            />
            <Route 
              path="/reports" 
              element={<ProtectedRoute allowedRoles={['Admin']}><Reports /></ProtectedRoute>} 
            />

            {/* Faculty only views */}
            <Route 
              path="/faculty-dashboard" 
              element={<ProtectedRoute allowedRoles={['Faculty']}><FacultyDashboard /></ProtectedRoute>} 
            />

            {/* Student only views */}
            <Route 
              path="/student-dashboard" 
              element={<ProtectedRoute allowedRoles={['Student']}><StudentDashboard /></ProtectedRoute>} 
            />

          </Route>

          {/* Fallback redirects */}
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
